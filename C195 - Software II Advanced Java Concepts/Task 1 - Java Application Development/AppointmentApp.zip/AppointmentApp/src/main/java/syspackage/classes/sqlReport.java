package syspackage.classes;

/**
 * Class for object(s) 'sqlReport'. sqlReport objects are made as objects combining a string field with an int field.
 * @author Anthony Coots
 */
public class sqlReport {
    /**
     * type matching *** in dataset.
     */
    private String type;
    /**
     * count matching count in dataset.
     */
    private int count;

    /**
     * Class constructor
     * @param type - ***
     * @param count - Count
     */
    public sqlReport(String type, int count) {
        this.type = type;
        this.count = count;
    }
    /**
     * Getter for count
     * @return count of object
     */
    public int getCount() {
        return count;
    }
    /**
     * Setter for count
     * @param count count
     */
    public void setCount(int count) {
        this.count = count;
    }
    /**
     * Getter for type
     * @return type of object
     */
    public String getType() {
        return type;
    }
    /**
     * Setter for type
     * @param type type
     */
    public void setType(String type) {
        this.type = type;
    }
}
