package syspackage.dao;

import syspackage.appointmentapp.CustomersController;
import syspackage.classes.sqlCountry;
import syspackage.classes.sqlCustomer;
import syspackage.classes.sqlDivision;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;

/**
 * Class that contains SQL statements used for customer application functionality.
 * @author Anthony Coots
 */
public class customerSQL {
    /**
     * Function that adds a customer to the database.
     * @param connection JDBC connection
     * @param newCustomer customer object to be added to database.
     */
    public static void addCustomer(Connection connection, sqlCustomer newCustomer) {
        String query = "INSERT INTO customers (Customer_ID, Customer_Name, Address, Postal_Code, Phone, Create_Date, Created_By, Last_Update, " +
                "Last_Updated_By, Division_ID) " +
                "VALUES (" + "'" + newCustomer.getCustomerId() + "', "
                + "'" + newCustomer.getCustomerName() + "', "
                + "'" + newCustomer.getCustomerAddress() + "', "
                + "'" + newCustomer.getCustomerPostal() + "', "
                + "'" + newCustomer.getCustomerPhone() + "', "
                + "'" + newCustomer.getCreateDate() + "', "
                + "'" + newCustomer.getCreatedBy() + "', "
                + "'" + newCustomer.getLastUpdate() + "', "
                + "'" + newCustomer.getLastUpdatedBy() + "', "
                + "'" + newCustomer.getDivisionId() + "')";

        System.out.println("*****************************************************************************************");
        System.out.println("Insert query set.");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate(query);
        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
    }
    /**
     * Function that lists countries for combo boxes.
     * @param connection JDBC connection
     */
    public static void countries(Connection connection) {
        CustomersController.allCountries.clear();

        System.out.println("*****************************************************************************************");
        System.out.println("Clearing current list of countries if any present.");
        if (CustomersController.allCountries.size() > 0) {
            CustomersController.allCountries.clear();
        }
        System.out.println("*****************************************************************************************");

        String query = "SELECT * FROM client_schedule.countries ";

        System.out.println("*****************************************************************************************");
        System.out.println("Query set. Selecting data from 'countries' table.");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Entering try/catch sequence.");
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            System.out.println("*****************************************************************************************");
            System.out.println("Attempting query execution. ResultSet set to executeQuery call.");
            ResultSet resultSet = statement.executeQuery(query);
            System.out.println("*****************************************************************************************");

            while (resultSet.next()) {
                System.out.println("*****************************************************************************************");
                System.out.println("ResultSet mapping to new variables. Advancing row.");

                System.out.println("Variable: countryId - SQL column: 'Country_ID' at row.");
                int countryId = resultSet.getInt("Country_ID");

                System.out.println("Variable: country - SQL column: 'Country' at row.");
                String country = resultSet.getString("Country");

                System.out.println("Variable: createDate - SQL column: 'Create_Date' at row.");
                LocalDateTime createDate = resultSet.getTimestamp("Create_Date").toLocalDateTime();

                System.out.println("Variable: createdBy - SQL column: 'Created_By' at row.");
                String createdBy = resultSet.getString("Created_By");

                System.out.println("Variable: lastUpdate - SQL column: 'Last_Update' at row.");
                LocalDateTime lastUpdate = resultSet.getTimestamp("Last_Update").toLocalDateTime();

                System.out.println("Variable: lastUpdatedBy - SQL column: 'Last_Updated_By' at row.");
                String lastUpdatedBy = resultSet.getString("Last_Updated_By");

                System.out.println("Row obtained, setting to object of class 'sqlCustomer'");
                System.out.println("*****************************************************************************************");

                sqlCountry sqlCountryObj = new sqlCountry(countryId, country, createDate, createdBy, lastUpdate, lastUpdatedBy);
                CustomersController.allCountries.add(sqlCountryObj);
                System.out.println("Object 'country' created. Object is a new object of class 'sqlCountry'.");
                System.out.println("*****************************************************************************************");
            }
            System.out.println("*****************************************************************************************");
            System.out.println("Try successful. Proceeding in function call.");
            System.out.println("*****************************************************************************************");
            System.out.println("*****************************************************************************************");
            System.out.println("End of ResultSet.");
            System.out.println("*****************************************************************************************");
        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
    }
    /**
     * Function that lists divisions for a given country String.
     * @param connection JDBC connection
     * @param country to list divisions for a specified country.
     */
    public static void countryDivisions(Connection connection, String country) {
        System.out.println("*****************************************************************************************");
        System.out.println("Clearing current list of countries if any present.");
        if (CustomersController.allDivisions.size() > 0) {
            CustomersController.allDivisions.clear();
        }
        System.out.println("*****************************************************************************************");

        String query = "SELECT * FROM client_schedule.first_level_divisions WHERE country_id = "
                + "(SELECT country_id FROM client_schedule.countries WHERE country = '" + country + "')";

        System.out.println("*****************************************************************************************");
        System.out.println("Query set. Selecting data from 'first_level_divisions' table.");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Entering try/catch sequence.");
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            System.out.println("*****************************************************************************************");
            System.out.println("Attempting query execution. ResultSet set to executeQuery call.");
            ResultSet resultSet = statement.executeQuery(query);
            System.out.println("*****************************************************************************************");

            while (resultSet.next()) {
                System.out.println("*****************************************************************************************");
                System.out.println("ResultSet mapping to new variables. Advancing row.");

                System.out.println("Variable: divisionId - SQL column: 'Division_ID' at row.");
                int divisionId = resultSet.getInt("Division_ID");

                System.out.println("Variable: division - SQL column: 'Division' at row.");
                String division = resultSet.getString("Division");

                System.out.println("Variable: createDate - SQL column: 'Create_Date' at row.");
                LocalDateTime createDate = resultSet.getTimestamp("Create_Date").toLocalDateTime();

                System.out.println("Variable: createdBy - SQL column: 'Created_By' at row.");
                String createdBy = resultSet.getString("Created_By");

                System.out.println("Variable: lastUpdate - SQL column: 'Last_Update' at row.");
                LocalDateTime lastUpdate = resultSet.getTimestamp("Last_Update").toLocalDateTime();

                System.out.println("Variable: lastUpdatedBy - SQL column: 'Last_Updated_By' at row.");
                String lastUpdatedBy = resultSet.getString("Last_Updated_By");

                System.out.println("Variable: countryId - SQL column: 'Country_ID' at row.");
                int countryId = resultSet.getInt("Country_Id");

                System.out.println("Row obtained, setting to object of class 'sqlCustomer'");
                System.out.println("*****************************************************************************************");

                sqlDivision sqlDivisionObj = new sqlDivision(divisionId, division, createDate, createdBy, lastUpdate, lastUpdatedBy, countryId);
                CustomersController.allDivisions.add(sqlDivisionObj);
                System.out.println("Object 'division' created. Object is a new object of class 'sqlDivision'.");
                System.out.println("*****************************************************************************************");
            }
            System.out.println("*****************************************************************************************");
            System.out.println("Try successful. Proceeding in function call.");
            System.out.println("*****************************************************************************************");
            System.out.println("*****************************************************************************************");
            System.out.println("End of ResultSet.");
            System.out.println("*****************************************************************************************");
        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
    }
    /**
     * Function that gets a country's name from a given division ID.
     * @param connection JDBC connection
     * @param divisionId division ID required to generate dataset.
     * @return Country name as string.
     */
    public static String countryNameFromDivisionId(Connection connection, int divisionId) {
        String query = "SELECT csf.division_id, csc.country_id, csc.country\n"
                + "FROM client_schedule.first_level_divisions csf INNER JOIN client_schedule.countries csc\n"
                + "ON csf.Country_ID = csc.country_id WHERE division_Id = '" + divisionId + "'";

        System.out.println("*****************************************************************************************");
        System.out.println("Query set. Selecting data from 'countries' table.");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            System.out.println("*****************************************************************************************");
            System.out.println("Attempting query execution. ResultSet set to executeQuery call.");
            System.out.println("*****************************************************************************************");
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                System.out.println("*****************************************************************************************");
                System.out.println("ResultSet mapping to new variables. Advancing row.");
                System.out.println("*****************************************************************************************");

                System.out.println("Country found, returning.");
                return resultSet.getString("country");
            }
        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
        return null;
    }
    /**
     * Function that deletes customer from database.
     * @param connection JDBC connection
     * @param currentCustomer Chosen customer.
     */
    public static void deleteCustomer(Connection connection, sqlCustomer currentCustomer) {
        String query = "DELETE FROM client_schedule.customers WHERE customer_id = '"
                + currentCustomer.getCustomerId() + "'";

        System.out.println("*****************************************************************************************");
        System.out.println("Query set. Deleting data from 'customers' table.");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Entering try/catch sequence.");
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            System.out.println("*****************************************************************************************");
            System.out.println("Attempting query execution. ResultSet set to executeQuery call.");
            statement.executeUpdate(query);
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            System.out.println("Try successful. Proceeding in function call.");
            System.out.println("*****************************************************************************************");
            System.out.println("*****************************************************************************************");
            System.out.println("End of ResultSet.");
            System.out.println("*****************************************************************************************");

        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
    }
    /**
     * Function that returns division ID from given division String.
     * @param connection JDBC connection
     * @param division To report associated ID.
     * @return Division ID.
     */
    public static int divisionIdFromDivisionName(Connection connection, String division) {
        String query = "SELECT division_id FROM client_schedule.first_level_divisions WHERE division = '" + division + "'";

        System.out.println("*****************************************************************************************");
        System.out.println("Query set. Selecting data from 'first_level_divisions' table.");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            System.out.println("*****************************************************************************************");
            System.out.println("Attempting query execution. ResultSet set to executeQuery call.");
            System.out.println("*****************************************************************************************");
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                System.out.println("*****************************************************************************************");
                System.out.println("ResultSet mapping to new variables. Advancing row.");
                System.out.println("*****************************************************************************************");

                System.out.println("Division ID found, returning.");
                return resultSet.getInt("division_id");
            }
        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
        return 0;
    }
    /**
     * Function that returns division name from given division ID int.
     * @param connection JDBC connection
     * @param divisionId To report associate division name.
     * @return Division.
     */
    public static String divisionNameFromDivisionId(Connection connection, int divisionId) {
        String query = "SELECT division FROM client_schedule.first_level_divisions WHERE division_id = '" + divisionId + "'";

        System.out.println("*****************************************************************************************");
        System.out.println("Query set. Selecting data from 'first_level_divisions' table.");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            System.out.println("*****************************************************************************************");
            System.out.println("Attempting query execution. ResultSet set to executeQuery call.");
            System.out.println("*****************************************************************************************");
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                System.out.println("*****************************************************************************************");
                System.out.println("ResultSet mapping to new variables. Advancing row.");
                System.out.println("*****************************************************************************************");

                System.out.println("Division found, returning.");
                return resultSet.getString("division");
            }
        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
        return null;
    }
    /**
     * Function that lists divisions for combo boxes.
     * @param connection JDBC connection
     */
    public static void divisions(Connection connection) {

        System.out.println("*****************************************************************************************");
        System.out.println("Clearing current list of countries if any present.");
        if (CustomersController.allDivisions.size() > 0) {
            CustomersController.allDivisions.clear();
        }
        System.out.println("*****************************************************************************************");

        String query = "SELECT * FROM client_schedule.first_level_divisions";

        System.out.println("*****************************************************************************************");
        System.out.println("Query set. Selecting data from 'first_level_divisions' table.");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Entering try/catch sequence.");
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            System.out.println("*****************************************************************************************");
            System.out.println("Attempting query execution. ResultSet set to executeQuery call.");
            ResultSet resultSet = statement.executeQuery(query);
            System.out.println("*****************************************************************************************");

            while (resultSet.next()) {
                System.out.println("*****************************************************************************************");
                System.out.println("ResultSet mapping to new variables. Advancing row.");

                System.out.println("Variable: divisionId - SQL column: 'Division_ID' at row.");
                int divisionId = resultSet.getInt("Division_ID");

                System.out.println("Variable: division - SQL column: 'Division' at row.");
                String division = resultSet.getString("Division");

                System.out.println("Variable: createDate - SQL column: 'Create_Date' at row.");
                LocalDateTime createDate = resultSet.getTimestamp("Create_Date").toLocalDateTime();

                System.out.println("Variable: createdBy - SQL column: 'Created_By' at row.");
                String createdBy = resultSet.getString("Created_By");

                System.out.println("Variable: lastUpdate - SQL column: 'Last_Update' at row.");
                LocalDateTime lastUpdate = resultSet.getTimestamp("Last_Update").toLocalDateTime();

                System.out.println("Variable: lastUpdatedBy - SQL column: 'Last_Updated_By' at row.");
                String lastUpdatedBy = resultSet.getString("Last_Updated_By");

                System.out.println("Variable: countryId - SQL column: 'Country_ID' at row.");
                int countryId = resultSet.getInt("Country_Id");

                System.out.println("Row obtained, setting to object of class 'sqlCustomer'");
                System.out.println("*****************************************************************************************");

                sqlDivision sqlDivisionObj = new sqlDivision(divisionId, division, createDate, createdBy, lastUpdate, lastUpdatedBy,
                        countryId);
                CustomersController.allDivisions.add(sqlDivisionObj);
                System.out.println("Object 'division' created. Object is a new object of class 'sqlDivision'.");
                System.out.println("*****************************************************************************************");
            }
            System.out.println("*****************************************************************************************");
            System.out.println("Try successful. Proceeding in function call.");
            System.out.println("*****************************************************************************************");
            System.out.println("*****************************************************************************************");
            System.out.println("End of ResultSet.");
            System.out.println("*****************************************************************************************");
        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
    }
    /**
     * Function that checks if a customer has existing appointments before deleting
     * @param connection JDBC connection
     * @param selectedCustomer Customer to be deleted.
     * @return True, a customer has appointments cannot delete yet, false, customer can be deleted.
     */
    public static boolean existingAppointments(Connection connection, sqlCustomer selectedCustomer) {

        String query = "SELECT COUNT(*) AS totalAppointments FROM client_schedule.appointments WHERE customer_id = '"
                + selectedCustomer.getCustomerId() + "'";

        System.out.println("*****************************************************************************************");
        System.out.println("Query set. Selecting data from 'customers' table.");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Entering try/catch sequence.");
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            System.out.println("*****************************************************************************************");
            System.out.println("Attempting query execution. ResultSet set to executeQuery call.");
            ResultSet resultSet = statement.executeQuery(query);
            System.out.println("*****************************************************************************************");

            while (resultSet.next()) {
                System.out.println("*****************************************************************************************");
                int appointments = resultSet.getInt("totalAppointments");
                System.out.println("Customer has " + appointments + " appointments");

                if(appointments > 0) { return true; }
            }
            System.out.println("*****************************************************************************************");
            System.out.println("Try successful. Proceeding in function call.");
            System.out.println("*****************************************************************************************");
            System.out.println("*****************************************************************************************");
            System.out.println("End of ResultSet.");
            System.out.println("*****************************************************************************************");

            return false;

        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }

        return true;
    }
    /**
     * Function that generates list of customers for table view.
     * @param connection
     */
    public static void listCustomers(Connection connection) {
        System.out.println("*****************************************************************************************");
        System.out.println("Clearing current list of customers if any present.");
        if(CustomersController.allCustomers.size() > 0) {
            CustomersController.allCustomers.clear();
        }
        System.out.println("*****************************************************************************************");

        String query = "SELECT * FROM client_schedule.customers";

        System.out.println("*****************************************************************************************");
        System.out.println("Query set. Selecting data from 'customers' table.");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Entering try/catch sequence.");
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            System.out.println("*****************************************************************************************");
            System.out.println("Attempting query execution. ResultSet set to executeQuery call.");
            ResultSet resultSet = statement.executeQuery(query);
            System.out.println("*****************************************************************************************");

            while (resultSet.next()) {
                System.out.println("*****************************************************************************************");
                System.out.println("ResultSet mapping to new variables. Advancing row.");

                System.out.println("Variable: customerId - SQL column: 'Customer_ID' at row.");
                int customerId = resultSet.getInt("Customer_ID");

                System.out.println("Variable: customerName - SQL column: 'Customer_Name' at row.");
                String customerName = resultSet.getString("Customer_Name");

                System.out.println("Variable: address - SQL column: 'Address' at row.");
                String address = resultSet.getString("Address");

                System.out.println("Variable: postalCode - SQL column: 'Postal_Code' at row.");
                String postalCode = resultSet.getString("Postal_Code");

                System.out.println("Variable: phone - SQL column: 'Phone' at row.");
                String phone = resultSet.getString("Phone");

                System.out.println("Variable: createDate - SQL column: 'Create_date' at row.");
                LocalDateTime createDate = resultSet.getTimestamp("Create_date").toLocalDateTime();

                System.out.println("Variable: createdBy - SQL column: 'Created_By' at row.");
                String createdBy = resultSet.getString("Created_By");

                System.out.println("Variable: lastUpdate - SQL column: 'Last_Update' at row.");
                LocalDateTime lastUpdate = resultSet.getTimestamp("Last_Update").toLocalDateTime();

                System.out.println("Variable: lastUpdatedBy - SQL column: 'Last_Updated_By' at row.");
                String lastUpdatedBy = resultSet.getString("Last_Updated_By");

                System.out.println("Variable: divisionId - SQL column: 'Division_ID' at row.");
                int divisionId = resultSet.getInt("Division_ID");

                System.out.println("Row obtained, setting to object of class 'sqlCustomer'");
                System.out.println("*****************************************************************************************");

                System.out.println("*****************************************************************************************");
                sqlCustomer customer = new sqlCustomer(customerId, customerName, address, postalCode, phone, createDate, createdBy,
                                                        lastUpdate, lastUpdatedBy, divisionId);
                System.out.println("Object 'customer' created. Object is a new object of class 'sqlCustomer'");
                System.out.println("*****************************************************************************************");

                System.out.println("*****************************************************************************************");
                System.out.println("Adding object to 'allAppointmentsInMonth' Observablelist in sqlAppointment class...");
                CustomersController.allCustomers.add(customer);
                System.out.println("Object added.");
                System.out.println("*****************************************************************************************");

                System.out.println("*****************************************************************************************");
                System.out.println("List of customers: " + CustomersController.allCustomers);
                System.out.println("Items in 'allCustomers': " + CustomersController.allCustomers.size());
                System.out.println("*****************************************************************************************");
            }
            System.out.println("*****************************************************************************************");
            System.out.println("Try successful. Proceeding in function call.");
            System.out.println("*****************************************************************************************");
            System.out.println("*****************************************************************************************");
            System.out.println("End of ResultSet.");
            System.out.println("*****************************************************************************************");

        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
    }
    /**
     * Function that generates next available customer ID for adding a new customer.
     * @param connection JDBC connection
     * @return auto generated ID.
     */
    public static int nextAvailableCustomerId(Connection connection) {
        System.out.println("*****************************************************************************************");
        System.out.println("Creating query to select next available customer ID based on existing customers");
        System.out.println("*****************************************************************************************");

        String query = "SELECT cus.customer_id + 1 AS genCustomerId "
                + "FROM client_schedule.customers cus LEFT JOIN client_schedule.customers cus1 "
                + "ON cus1.customer_id = cus.customer_id + 1 "
                + "WHERE cus1.customer_id IS NULL "
                + "ORDER BY cus.customer_id "
                + "LIMIT 0, 1";

        System.out.println("*****************************************************************************************");
        System.out.println("Query set. Selecting data from 'customers' table.");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Entering try/catch sequence.");
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            System.out.println("*****************************************************************************************");
            System.out.println("Attempting query execution. ResultSet set to executeQuery call.");
            ResultSet resultSet = statement.executeQuery(query);
            System.out.println("*****************************************************************************************");

            while (resultSet.next()) {
                System.out.println("*****************************************************************************************");
                System.out.println("ResultSet mapping to new variables. Advancing row.");

                System.out.println("Variable: customerId - SQL column: 'genCustomerId' at row.");
                int customerId = resultSet.getInt("genCustomerId");
                System.out.println("*****************************************************************************************");

                System.out.println("*****************************************************************************************");
                System.out.println("Try successful. Proceeding in function call.");
                System.out.println("*****************************************************************************************");
                return customerId;
            }
            System.out.println("*****************************************************************************************");
            System.out.println("End of ResultSet.");
            System.out.println("*****************************************************************************************");


        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
        return 0;
    }
    /**
     * Function that generates a country from a given division ID for combo box.
     * @param connection JDBC connection
     * @param divisionId Division ID for country.
     */
    public static void singleCountries(Connection connection, int divisionId) {
        System.out.println("*****************************************************************************************");
        System.out.println("Clearing current list of countries if any present.");
        if (CustomersController.allCountries.size() > 0) {
            CustomersController.allCountries.clear();
        }
        System.out.println("*****************************************************************************************");

        String query = "SELECT * FROM client_schedule.countries WHERE country_id = "
                + "(SELECT country_id FROM client_schedule.first_level_divisions WHERE Division_ID = '"
                + divisionId + "')";

        System.out.println("*****************************************************************************************");
        System.out.println("Query set. Selecting data from 'countries' table.");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Entering try/catch sequence.");
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            System.out.println("*****************************************************************************************");
            System.out.println("Attempting query execution. ResultSet set to executeQuery call.");
            ResultSet resultSet = statement.executeQuery(query);
            System.out.println("*****************************************************************************************");

            while (resultSet.next()) {
                System.out.println("*****************************************************************************************");
                System.out.println("ResultSet mapping to new variables. Advancing row.");

                System.out.println("Variable: countryId - SQL column: 'Country_ID' at row.");
                int countryId = resultSet.getInt("Country_ID");

                System.out.println("Variable: country - SQL column: 'Country' at row.");
                String country = resultSet.getString("Country");

                System.out.println("Variable: createDate - SQL column: 'Create_Date' at row.");
                LocalDateTime createDate = resultSet.getTimestamp("Create_Date").toLocalDateTime();

                System.out.println("Variable: createdBy - SQL column: 'Created_By' at row.");
                String createdBy = resultSet.getString("Created_By");

                System.out.println("Variable: lastUpdate - SQL column: 'Last_Update' at row.");
                LocalDateTime lastUpdate = resultSet.getTimestamp("Last_Update").toLocalDateTime();

                System.out.println("Variable: lastUpdatedBy - SQL column: 'Last_Updated_By' at row.");
                String lastUpdatedBy = resultSet.getString("Last_Updated_By");

                System.out.println("Row obtained, setting to object of class 'sqlCustomer'");
                System.out.println("*****************************************************************************************");

                sqlCountry sqlCountryObj = new sqlCountry(countryId, country, createDate, createdBy, lastUpdate, lastUpdatedBy);
                CustomersController.allCountries.add(sqlCountryObj);
                System.out.println("Object 'country' created. Object is a new object of class 'sqlCountry'.");
                System.out.println("*****************************************************************************************");
            }
            System.out.println("*****************************************************************************************");
            System.out.println("Try successful. Proceeding in function call.");
            System.out.println("*****************************************************************************************");
            System.out.println("*****************************************************************************************");
            System.out.println("End of ResultSet.");
            System.out.println("*****************************************************************************************");
        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
    }
    /**
     * Function that updates a customer in the database.
     * @param connection JDBC connection
     * @param customerId - Customer_ID
     * @param name - Customer_Name
     * @param address - Address
     * @param postalCode - Postal_Code
     * @param phone - Phone
     * @param createDate - Create_Date
     * @param createdBy - Created_By
     * @param lastUpdate - Last_Update
     * @param lastUpdatedBy - Last_Updated_By
     * @param divisionId - Division_ID
     * @throws SQLException Thrown if query cannot execute properly.
     */
    public static void updateCustomer(Connection connection, int customerId, String name, String address, String postalCode,
                                      String phone, LocalDateTime createDate, String createdBy, LocalDateTime lastUpdate,
                                      String lastUpdatedBy, int divisionId) throws SQLException {
        System.out.println("\n****************************************************");
        System.out.println("Attempting to update 'Appointments' table...");
        System.out.println("\nQuery:\n");

        String query = "UPDATE customers SET "
                + "Customer_Name = '" + name + "', "
                + "Address = '" + address + "', "
                + "Postal_Code = '" + postalCode + "', "
                + "Phone = '" + phone + "', "
                + "Create_Date = '" + createDate + "', "
                + "Created_By = '" + createdBy + "', "
                + "Last_Update = '" + lastUpdate + "', "
                + "Last_Updated_By = '" + lastUpdatedBy + "', "
                + "Division_ID = '" + divisionId + "' "
                + "WHERE Customer_ID = '" + customerId + "'";


        System.out.println(query);
        System.out.println("\nComparing result set...");
        System.out.print("Result: ");

        try (Statement statement = connection.createStatement()) { statement.executeUpdate(query); }
        catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
    }
}
