package syspackage.appointmentapp;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import syspackage.classes.*;
import syspackage.dao.appointmentSQL;
import syspackage.helper.JDBC;

import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

/**
 * Class that controls the logic for the form that adds appointments to database.
 * @author Anthony Coots
 */
public class AddAppointmentController implements Initializable {
    /**
     * FXML variable combo box in form for contact selection.
     */
    @FXML
    private ComboBox<String> contactCombo;
    /**
     * FXML variable combo box in form for customer selection.
     */
    @FXML
    private ComboBox<String> customerCombo;
    /**
     * FXML variable combo box in form for location selection.
     */
    @FXML
    private ComboBox<String> locationCombo;
    /**
     * FXML variable combo box in form for user selection.
     */
    @FXML
    private ComboBox<String> userCombo;
    /**
     * FXML variable text in form to display specification text.
     */
    @FXML
    private Text startText;
    /**
     * FXML variable text in form to display specification text.
     */
    @FXML
    private Text endText;
    /**
     * FXML variable text in form to display current login username.
     */
    @FXML
    private Text usernameText;
    /**
     * FXML variable text field in form to display auto generated appointment ID.
     */
    @FXML
    private TextField appointmentIdField;
    /**
     * FXML variable text field in form for title declaration.
     */
    @FXML
    private TextField titleField;
    /**
     * FXML variable text field in form for description declaration.
     */
    @FXML
    private TextField descriptionField;
    /**
     * FXML variable text field in form for start declaration.
     */
    @FXML
    private TextField startField;
    /**
     * FXML variable text field in form for end declaration.
     */
    @FXML
    private TextField endField;
    /**
     * FXML variable text field in form for type declaration.
     */
    @FXML
    private TextField typeField;
    /**
     * Class variable to declare start time once translated to database time (UTC).
     */
    private static LocalDateTime dbStartTime;
    /**
     * Class variable to declare end time once translated to database time (UTC).
     */
    private static LocalDateTime dbEndTime;
    /**
     * Class variable to flag if a time range is out of business hours.
     */
    private static boolean outOfBounds = false;
    /**
     * Class variable list made for reiteration to set combo box selections for each box.
     */
    public ObservableList<String> allStrings = FXCollections.observableArrayList();

    /**
     * Function that initializes the add appointment form.
     * @param url path location.
     * @param resourceBundle source through resources.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        System.out.println("*****************************************************************************************");
        System.out.println("*****************************************************************************************");
        System.out.println("Initializing AddAppointmentController.");
        System.out.println("*****************************************************************************************");
        System.out.println("*****************************************************************************************");
        System.out.println();

        System.out.println("*****************************************************************************************");
        System.out.println("Calling listLocations to list all locations in locationCombo comboBox.");
        listLocations();
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Calling listContacts to list all contacts in contactCombo comboBox.");
        listContacts();
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Calling listCustomers to list all customers in customerCombo comboBox.");
        listCustomers();
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Calling listUserIds to list all user_id in userCombo comboBox.");
        System.out.println("*****************************************************************************************");
        listUserIds();

        System.out.println("*****************************************************************************************");
        System.out.println("Setting usernameText display for current user.");
        usernameText.setText("User: " + LoginController.getCurrentUser().getUsername());
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Setting appointmentIdField textField to show auto-generated id (setAppointmentId()).");
        int autoGeneratedAppointmentId = appointmentSQL.nextAvailableAppId(JDBC.connection);
        appointmentIdField.setText(String.valueOf(autoGeneratedAppointmentId));
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Setting start and end text to ask for time entry in local time zone.");
        startText.setText("Please enter in local time: [" + ZoneId.systemDefault() + "]");
        endText.setText("Please enter in local time: [" + ZoneId.systemDefault() + "]");
        System.out.println("*****************************************************************************************");
    }

    /**
     * Function that lists all options for user combo box.
     */
    private void listUserIds() {
        try {
            System.out.println("*****************************************************************************************");
            System.out.println("Opening connection for userCombo comboBox.");
            System.out.println("*****************************************************************************************");
            appointmentSQL.users(JDBC.connection);

            for(sqlUser user : AppointmentsController.allUsers) {
                System.out.println("*****************************************************************************************");
                System.out.println("Adding string location to temporary list.");
                allStrings.add(String.valueOf(user.getUserId())); }
            System.out.println("*****************************************************************************************");
        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
        System.out.println("*****************************************************************************************");
        userCombo.setItems(allStrings);
        System.out.println("Set userCombo comboBox with all resultSet contact IDs.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        allStrings = FXCollections.observableArrayList();
        System.out.println("Temporary list cleared.");
        System.out.println("*****************************************************************************************");
    }
    /**
     * Function that lists all options for customer combo box.
     */
    private void listCustomers() {
        try {
        System.out.println("*****************************************************************************************");
        System.out.println("Opening connection for customerCombo comboBox.");
        System.out.println("*****************************************************************************************");
        appointmentSQL.customers(JDBC.connection);

        for(sqlCustomer customer : AppointmentsController.allCustomers) {
            System.out.println("*****************************************************************************************");
            System.out.println("Adding string location to temporary list.");
            allStrings.add(String.valueOf(customer.getCustomerId())); }
        System.out.println("*****************************************************************************************");
    } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
    }
        System.out.println("*****************************************************************************************");
        customerCombo.setItems(allStrings);
        System.out.println("Set customerCombo comboBox with all resultSet contact IDs.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        allStrings = FXCollections.observableArrayList();
        System.out.println("Temporary list cleared.");
        System.out.println("*****************************************************************************************");
}
    /**
     * Function that lists all options for contact combo box.
     */
    private void listContacts() {
        try {
            System.out.println("*****************************************************************************************");
            System.out.println("Opening connection for contactCombo comboBox.");
            System.out.println("*****************************************************************************************");
            appointmentSQL.contacts(JDBC.connection);

            for(sqlContact contact : AppointmentsController.allContacts) {
                System.out.println("*****************************************************************************************");
                System.out.println("Adding string location to temporary list.");
                allStrings.add(String.valueOf(contact.getContactName())); }
            System.out.println("*****************************************************************************************");
        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
        System.out.println("*****************************************************************************************");
        contactCombo.setItems(allStrings);
        System.out.println("Set contactCombo comboBox with all resultSet contact IDs.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        allStrings = FXCollections.observableArrayList();
        System.out.println("Temporary list cleared.");
        System.out.println("*****************************************************************************************");
    }
    /**
     * Function that lists all options for location combo box.
     */
    private void listLocations() {
        try {
            System.out.println(AppointmentsController.allLocations);

            System.out.println("*****************************************************************************************");
            System.out.println("Opening connection for locationsCombo comboBox.");
            System.out.println("*****************************************************************************************");
            appointmentSQL.locations(JDBC.connection);

            for(sqlLocation locations : AppointmentsController.allLocations) {
                System.out.println("*****************************************************************************************");
                System.out.println("Adding string location to temporary list: " + locations.getLocation());
                allStrings.add(locations.getLocation()); }
                System.out.println("*****************************************************************************************");
        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
        System.out.println("*****************************************************************************************");
        locationCombo.setItems(allStrings);
        System.out.println("Set locationCombo comboBox with all resultSet locations.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        allStrings = FXCollections.observableArrayList();
        System.out.println("Temporary list cleared.");
        System.out.println("*****************************************************************************************");
    }
    /**
     * Function that checks if the customer ID combo box is valid. If combo box is empty, the combo box is not valid.
     * @return True if not empty, false otherwise.
     */
    private boolean checkCIdField() {
        System.out.println("*****************************************************************************************");
        System.out.println("Checking customerCombo comboBox for selection.");
        System.out.println("*****************************************************************************************");

        return customerCombo.getSelectionModel().getSelectedItem() != null;
    }
    /**
     * Function that checks if the user ID combo box is valid. If combo box is empty, the combo box is not valid.
     * @return True if not empty, false otherwise.
     */
    private boolean checkUIdField() {
        System.out.println("*****************************************************************************************");
        System.out.println("Checking userCombo comboBox for selection.");
        System.out.println("*****************************************************************************************");
        return customerCombo.getSelectionModel().getSelectedItem() != null;
    }
    /**
     * Function that checks if the title field is valid. If title field is empty, the field is not valid.
     * @return True if not empty, false otherwise.
     */
    private boolean checkTitleField() {
        System.out.println("*****************************************************************************************");
        System.out.println("Checking titleField TextField for input.");
        System.out.println("*****************************************************************************************");
        return !titleField.getText().trim().isEmpty();
    }
    /**
     * Function that checks if the description field is valid. If description field is empty, the field is not valid.
     * @return True if not empty, false otherwise.
     */
    private boolean checkDescriptionField() {
        System.out.println("*****************************************************************************************");
        System.out.println("Checking descriptionField TextField for input.");
        System.out.println("*****************************************************************************************");
        return !descriptionField.getText().trim().isEmpty();
    }
    /**
     * Function that checks if the location combo box is valid. If combo box is empty, the combo box is not valid.
     * @return True if not empty, false otherwise.
     */
    private boolean checkLocationField() {
        System.out.println("*****************************************************************************************");
        System.out.println("Checking locationCombo comboBox for selection.");
        System.out.println("*****************************************************************************************");
        return locationCombo.getSelectionModel().getSelectedItem() != null;
    }
    /**
     * Function that checks if the contact combo box is valid. If combo box is empty, the combo box is not valid.
     * @return True if not empty, false otherwise.
     */
    private boolean checkContactField() {
        System.out.println("*****************************************************************************************");
        System.out.println("Checking contactCombo comboBox for selection.");
        System.out.println("*****************************************************************************************");
        return contactCombo.getSelectionModel().getSelectedItem() != null;
    }
    /**
     * Function that checks if the start field is valid.
     * @return True if valid, false otherwise.
     */
    private boolean checkStartField() {
        System.out.println("*****************************************************************************************");
        System.out.println("Checking startField TextField for input.");
        System.out.println("*****************************************************************************************");

        try {
            System.out.println("*****************************************************************************************");
            DateTimeFormatter formatCheck = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            System.out.println("Format expected 'yyyy-MM-dd HH:mm:ss'");
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            System.out.println("Parsing input for format");
            LocalDateTime startInput = LocalDateTime.parse(startField.getText(), formatCheck);
            System.out.println("Start field validated. Returning true.");
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            System.out.println("Converting input start datetime to database datetime.");
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            System.out.println("input datetime: " + startInput);
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            LocalTime localStartTime = startInput.toLocalTime();
            System.out.println("Local start time: " + localStartTime);
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            LocalDate localStartDate = startInput.toLocalDate();
            System.out.println("Local start date: " + localStartDate);
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            int localStartTimeInSeconds = localStartTime.toSecondOfDay();
            System.out.println("Local start time in seconds: " + localStartTimeInSeconds);
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            int timeDifference = (ZoneId.of(String.valueOf(ZoneId.systemDefault())).getRules().getOffset(Instant.now())).getTotalSeconds() * -1;
            System.out.println("Local to database time difference, in seconds: " + timeDifference);
            System.out.println("*****************************************************************************************");

            int dbStartTimeInSeconds = localStartTimeInSeconds + timeDifference;
            System.out.println("Database start time in seconds: " + dbStartTimeInSeconds);

            LocalDate dbStartDate = localStartDate;

            System.out.print("Is database start time the day before? ");
            if(dbStartTimeInSeconds < 0) {
                System.out.println("Yes.");
                dbStartDate = localStartDate.minusDays(1);
                dbStartTimeInSeconds += 86400;
            }
            else { System.out.println("No."); }

            System.out.print("Is database start time the day after? ");
            if(dbStartTimeInSeconds >= 86400) {
                System.out.println("Yes.");
                dbStartDate = localStartDate.plusDays(1);
                dbStartTimeInSeconds -= 86400;
            }
            else { System.out.println("No."); }

            LocalTime dbStartTime = LocalTime.ofSecondOfDay(dbStartTimeInSeconds);

            System.out.println("Database date: " + dbStartDate);
            System.out.println("Database datetime: " + dbStartDate + " " + dbStartTime);

            System.out.println("Taking database datetime back to format.");
            startInput = LocalDateTime.of(dbStartDate, dbStartTime);
            System.out.println("Database datetime: " + startInput);

            System.out.println("*****************************************************************************************");
            System.out.println("Checking if start time is within business hours.");
            if(!TimeTranslation.isDbInEt(startInput)) {
                return false;
            }
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            setDbStartTime(startInput);
            System.out.println("Set DbStartTime.");
            System.out.println("*****************************************************************************************");

            return true;
        } catch (Exception e) {
            System.out.println("*****************************************************************************************");
            System.out.println("Invalid input. In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
            return false;
        }
    }
    private boolean checkStartNew() {
        System.out.println("*****************************************************************************************");
        System.out.println("Checking startField TextField for input.");
        System.out.println("*****************************************************************************************");

        try {
            System.out.println("*****************************************************************************************");
            String startInput = startField.getText();
            System.out.println("Grabbed from startField: " + startInput);
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            Timestamp startInputTimeStamp = Timestamp.valueOf(startInput);
            System.out.println("Timestamp startInputTimeStamp set to: " + startInputTimeStamp);
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            String fieldInUTC = TimeTranslation.localToUtc(String.valueOf(startInputTimeStamp));
            System.out.println("String fieldInUtc set to: " + fieldInUTC);
            System.out.println("*****************************************************************************************");

            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

            if(TimeTranslation.checkBusinessHours(fieldInUTC)) {
                System.out.println("*****************************************************************************************");
                setDbStartTime(LocalDateTime.parse(fieldInUTC, dateTimeFormatter));
                System.out.println("setDbStartTime: " + LocalDateTime.parse(fieldInUTC, dateTimeFormatter));
                System.out.println("*****************************************************************************************");
                System.out.println("Database start set to: " + getDbStartTime());
                System.out.println("*****************************************************************************************");
                return true;
            }
            else {
                boundsAlert();
                return false;
            }
        } catch (Exception e) {
            System.out.println("*****************************************************************************************");
            System.out.println("Invalid input. In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
            return false;
        }
    }
    /**
     * Function that checks if the end field is valid.
     * @return True if valid, false otherwise.
     */
    private boolean checkEndField() {
        System.out.println("*****************************************************************************************");
        System.out.println("Checking endField TextField for input.");
        System.out.println("*****************************************************************************************");

        try {
            String endInput = endField.getText();
            Timestamp endInputTimeStamp = Timestamp.valueOf(endInput);
            String fieldInUTC = TimeTranslation.localToUtc(String.valueOf(endInputTimeStamp));
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

            if(TimeTranslation.checkBusinessHours(fieldInUTC)) {
                setDbEndTime(LocalDateTime.parse(fieldInUTC, dateTimeFormatter));
                System.out.println("Database end set to: " + getDbEndTime());
                return true;
            }
            else {
                boundsAlert();
                return false; }
        } catch (Exception e) {
            System.out.println("*****************************************************************************************");
            System.out.println("Invalid input. In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
            return false;
        }
    }
    /**
     * Function that verifies that the start input is before the end input. Displays error if false.
     * @return true if start before end, otherwise false.
     */
    private boolean checkStartAfterEnd() {
        if(getDbStartTime().isAfter(getDbEndTime())) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Time Error");
            alert.setContentText("Cannot add appointment, start after end.");
            alert.showAndWait();
            return false;
        }
        return true;
    }
    /**
     * Function that checks if the type field is valid. If type field is empty, the field is not valid.
     * @return True if not empty, false otherwise.
     */
    private boolean checkTypeField() {
        return !typeField.getText().trim().isEmpty();
    }

    /**
     * Function that checks all fields for proper input then responds accordingly, I.E., if fails, scene stays, else proceed.
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (Load new).
     */
    public void saveButtonClicked(ActionEvent actionEvent) throws IOException {
        System.out.println("*****************************************************************************************");
        System.out.println("Checking if all TextFields and ComboBox's have a valid input/selection.");
        System.out.println("*****************************************************************************************");
        if(checkTitleField() && checkDescriptionField() && checkLocationField() && checkContactField()
                && checkTypeField() && checkCIdField() && checkUIdField()) {
            System.out.println("*****************************************************************************************");
            System.out.println("All TextFields and ComboBox's are valid. Checking start time and end time.");
            System.out.println("*****************************************************************************************");
            if (checkStartNew() && checkEndField()) {
                System.out.println("*****************************************************************************************");
                System.out.println("Start and end times are valid. Checking if start is before end.");
                System.out.println("*****************************************************************************************");
                if (checkStartAfterEnd() && checkIsDbInRange(getDbStartTime(), getDbEndTime())) {
                    System.out.println("*****************************************************************************************");
                    System.out.println("Start is before end. Adding appointment to database.");
                    System.out.println("*****************************************************************************************");

                    System.out.println("*****************************************************************************************");
                    int appointmentId = Integer.parseInt(appointmentIdField.getText());
                    System.out.println("Variable appointmentId set to value of field input.");
                    System.out.println("*****************************************************************************************");

                    System.out.println("*****************************************************************************************");
                    String title = titleField.getText();
                    System.out.println("Variable title set to value of field input.");
                    System.out.println("*****************************************************************************************");

                    System.out.println("*****************************************************************************************");
                    String description = descriptionField.getText();
                    System.out.println("Variable description set to value of field input.");
                    System.out.println("*****************************************************************************************");

                    System.out.println("*****************************************************************************************");
                    String location = locationCombo.getSelectionModel().getSelectedItem();
                    System.out.println("Variable location set to value of box selection.");
                    System.out.println("*****************************************************************************************");

                    System.out.println("*****************************************************************************************");
                    String contact = contactCombo.getSelectionModel().getSelectedItem();
                    System.out.println("Variable contact set to value of box selection.");
                    int contactId = appointmentSQL.contactIdFromContactName(JDBC.connection, contact);
                    System.out.println("Variable contactId retrieved from sql via contact string.");
                    System.out.println("*****************************************************************************************");

                    System.out.println("*****************************************************************************************");
                    String type = typeField.getText();
                    System.out.println("Variable type set to value of field input.");
                    System.out.println("*****************************************************************************************");

                    System.out.println("*****************************************************************************************");
                    LocalDateTime start = getDbStartTime();
                    System.out.println("IN FIELD: " + start);
                    System.out.println("Variable start set to value of field converted input.");
                    System.out.println("*****************************************************************************************");

                    System.out.println("*****************************************************************************************");
                    LocalDateTime end = getDbEndTime();
                    System.out.println("Variable end set to value of field converted input.");
                    System.out.println("*****************************************************************************************");

                    System.out.println("*****************************************************************************************");
                    int customerId = Integer.parseInt(customerCombo.getSelectionModel().getSelectedItem());
                    System.out.println("Variable customerId set to value of box selection.");
                    System.out.println("*****************************************************************************************");

                    System.out.println("*****************************************************************************************");
                    int userId = Integer.parseInt(userCombo.getSelectionModel().getSelectedItem());
                    System.out.println("Variable userId set to value of box selection.");
                    System.out.println("*****************************************************************************************");

                    System.out.println("*****************************************************************************************");
                    System.out.println("Checking for time conflict among existing appointments.");
                    System.out.println("*****************************************************************************************");

                    if (appointmentSQL.timeConflict(JDBC.connection, start, end, userId) == 0) {
                        System.out.println("*****************************************************************************************");
                        System.out.println("No overlapping appointments");
                        System.out.println("*****************************************************************************************");

                        try {
                            System.out.println("*****************************************************************************************");
                            System.out.println("Adding appointment.");
                            System.out.println("*****************************************************************************************");

                            sqlAppointment newAppointment = new sqlAppointment(appointmentId, title, description, location,
                                    type, start, end, TimeTranslation.getUtc(), LoginController.getCurrentUser().getUsername(),
                                    TimeTranslation.getUtc(), LoginController.getCurrentUser().getUsername(), customerId, userId, contactId);

                            System.out.println("save: " + newAppointment.getStart());

                            appointmentSQL.addAppointment(JDBC.connection, newAppointment);

                            System.out.println("*****************************************************************************************");
                            System.out.println("Appointment added to database.");
                            System.out.println("*****************************************************************************************");

                            System.out.println("*****************************************************************************************");
                            Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
                            stage.close();
                            System.out.println("Stage closed.");
                            System.out.println("*****************************************************************************************");

                            System.out.println("*****************************************************************************************");
                            System.out.println("Returning to appointment screen.");
                            backToView(new Stage());
                            System.out.println(start + " after add.");
                            System.out.println("*****************************************************************************************");

                        } catch (SQLException e) {
                            System.out.println("*****************************************************************************************");
                            System.out.println("In try/catch, caught: ");
                            System.out.println(e.getMessage());
                            System.out.println("*****************************************************************************************");
                        }
                    } else { overlapAlert(); }
                } else {
                    if (isOutOfBounds()) { boundsAlert(); }
                    else { timeAlert(); }
                }
            } else {
                if (isOutOfBounds()) { boundsAlert(); }
                else { timeAlert(); }
            }
        } else { alert(); }
    }

    /**
     * Function that checks if the database time post translation from local, is in range of business hours (ET).
     * @param startInput Database start time.
     * @param endInput Database end time.
     * @return True if in range, false if not.
     */
    private boolean checkIsDbInRange(LocalDateTime startInput, LocalDateTime endInput) {
        System.out.println("*****************************************************************************************");
        System.out.println("Converting database start and end datetime to ET datetime.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Start input datetime: " + startInput);
        System.out.println("End input datetime: " + endInput);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        LocalTime dbStartTime = startInput.toLocalTime();
        System.out.println("Database start time: " + dbStartTime);
        LocalTime dbEndTime = endInput.toLocalTime();
        System.out.println("Database start time: " + dbEndTime);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        LocalDate dbStartDate = startInput.toLocalDate();
        System.out.println("Database start date: " + dbStartDate);
        LocalDate dbEndDate = endInput.toLocalDate();
        System.out.println("Database end date: " + dbEndDate);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        int dbStartTimeInSeconds = dbStartTime.toSecondOfDay();
        System.out.println("Database start time in seconds: " + dbStartTimeInSeconds);
        int dbEndTimeInSeconds = dbEndTime.toSecondOfDay();
        System.out.println("Database end time in seconds: " + dbEndTimeInSeconds);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        int timeDifference = (ZoneId.of(String.valueOf(ZoneId.of("US/Eastern"))).getRules().getOffset(Instant.now())).getTotalSeconds();
        System.out.println("UTC to ET time difference, in seconds: " + timeDifference);
        System.out.println("*****************************************************************************************");

        int localStartTimeInSeconds = dbStartTimeInSeconds + timeDifference;
        System.out.println("ET start time in seconds: " + localStartTimeInSeconds);
        int localEndTimeInSeconds = dbEndTimeInSeconds + timeDifference;
        System.out.println("ET end time in seconds: " + localEndTimeInSeconds);

        LocalDate localStartDate = dbStartDate;
        LocalDate localEndDate = dbEndDate;


        System.out.print("Is ET start time the day before? ");
        if(localStartTimeInSeconds < 0) {
            System.out.println("Yes.");
            localStartDate = dbStartDate.minusDays(1);
            localStartTimeInSeconds += 86400;
        }
        else { System.out.println("No."); }

        System.out.print("Is ET start time the day after? ");
        if(localStartTimeInSeconds >= 86400) {
            System.out.println("Yes.");
            localStartDate = dbStartDate.plusDays(1);
            localStartTimeInSeconds -= 86400;
        }
        else { System.out.println("No."); }

        System.out.print("Is ET end time the day before? ");
        if(localEndTimeInSeconds < 0) {
            System.out.println("Yes.");
            localEndDate = dbEndDate.minusDays(1);
            localEndTimeInSeconds += 86400;
        }
        else { System.out.println("No."); }

        System.out.print("Is ET end time the day after? ");
        if(localEndTimeInSeconds >= 86400) {
            System.out.println("Yes.");
            localEndDate = dbEndDate.plusDays(1);
            localEndTimeInSeconds -= 86400;
        }
        else { System.out.println("No."); }

        System.out.println("*****************************************************************************************");
        System.out.println("Declaring localStartTime to show time of day taking in integer of seconds.");
        LocalTime localStartTime = LocalTime.ofSecondOfDay(localStartTimeInSeconds);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Declaring localEndTime to show time of day taking in integer of seconds.");
        LocalTime localEndTime = LocalTime.ofSecondOfDay(localEndTimeInSeconds);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("ET start date: " + localStartDate);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("ET start datetime: " + localStartDate + " " + localStartTime);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("ET end date: " + localEndDate);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("ET end datetime: " + localEndDate + " " + localEndTime);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Taking ET start datetime back to format.");
        startInput = LocalDateTime.of(localStartDate, localStartTime);
        System.out.println("ET start datetime: " + startInput);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Taking ET end datetime back to format.");
        endInput = LocalDateTime.of(localEndDate, localEndTime);
        System.out.println("ET end datetime: " + endInput);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Checking if dates are same.");
        System.out.println("Using comparison tool '.equals()', the dates are not stored in same memory location.");
        System.out.println("*****************************************************************************************");

        if(localStartDate.toString().equals(localEndDate.toString())) {
            System.out.println("*****************************************************************************************");
            System.out.println("Appointment time is valid. Both time fields are in business hours requirements.");
            System.out.println("*****************************************************************************************");
            return true;
        }
        else {
            System.out.println("*****************************************************************************************");
            System.out.println("Appointment time is invalid. One or both time fields are outside of business hours.");
            System.out.println("*****************************************************************************************");
            AddAppointmentController.outOfBounds = true;
            return false;
        }
    }
    /**
     * Function that returns to scene before current.
     * @param stage sets new stage.
     * @throws IOException FXMLLoader (Load new).
     */
    private void backToView(Stage stage) throws IOException {
        System.out.print("Getting resource for FXML 'Appointments.fxml'.");

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Appointments.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1080, 720);
        stage.setTitle("Appointments");
        stage.setScene(scene);
        stage.show();
    }
    /**
     * Function that displays alert for invalid fields.
     */
    public void alert() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Entry Error");
        alert.setContentText("Cannot add appointment without valid fields.");
        alert.showAndWait();
    }

    /**
     * Function that displays alert if time field specifically is invalid.
     */
    public void timeAlert() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Time Error");
        alert.setContentText("Time field invalid.");
        alert.showAndWait();
    }

    /**
     * Function that displays alert if times are outside of business hours (ET).
     */
    public void boundsAlert() {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Time Error");
            alert.setContentText("Time entered is out of business hours (8 A.M. - 10 P.M. ET)");
            alert.showAndWait();
        }

    /**
     * Function that displays alert if there is an existing appointment in time selected.
     */
    private void overlapAlert() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Time Error");
        alert.setContentText("Appointment already exists in this time.");
        alert.showAndWait();
    }

    /**
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (Load new).
     */
    public void cancelButtonClicked(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        stage.close();
        backToView(new Stage());
    }

    /**
     * Getter for dbStartTime variable.
     * @return dbStartTime.
     */
    public static LocalDateTime getDbStartTime() {
        return dbStartTime;
    }
    /**
     * Setter for dbStartTime variable.
     */
    public void setDbStartTime(LocalDateTime dbStartTime) {
        AddAppointmentController.dbStartTime = dbStartTime;
    }
    /**
     * Getter for dbEndTime variable.
     * @return dbStartTime.
     */
    public static LocalDateTime getDbEndTime() {
        return dbEndTime;
    }
    /**
     * Getter for dbEndTime variable.
     */
    public void setDbEndTime(LocalDateTime dbEndTime) {
        AddAppointmentController.dbEndTime = dbEndTime;
    }

    /**
     * Getter for outOfBounds variable.
     * @return outOfBounds.
     */
    public static boolean isOutOfBounds() {
        return outOfBounds;
    }

    /**
     * Setter for outOfBounds variable
     * @param outOfBounds takes boolean to set boolean.
     */
    public static void setOutOfBounds(boolean outOfBounds) {
        AddAppointmentController.outOfBounds = outOfBounds;
    }
}
