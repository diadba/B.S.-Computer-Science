package syspackage.classes;

/**
 * Class for object(s) 'sqlLocation'. sqlLocation objects are made as objects combining countryId, divisionId, and location.
 * @author Anthony Coots
 */
public class sqlLocation {
    /**
     * countryId matching Country_ID in dataset.
     */
    private int countryId;
    /**
     * divisionId matching Division_ID in dataset.
     */
    private int divisionId;
    /**
     * location matching location in dataset.
     */
    private String location;

    /**
     * Class constructor
     * @param countryId - Country_ID
     * @param divisionId - Division_ID
     * @param location - Location
     */
    public sqlLocation(int countryId, int divisionId, String location) {
        this.countryId = countryId;
        this.divisionId = divisionId;
        this.location = location;
    }
    /**
     * Getter for countryId
     * @return countryId of object
     */
    public int getCountryId() {
        return countryId;
    }
    /**
     * Setter for countryId
     * @param countryId countryId
     */
    public void setCountryId(int countryId) {
        this.countryId = countryId;
    }
    /**
     * Getter for divisionId
     * @return divisionId of object
     */
    public int getDivisionId() {
        return divisionId;
    }
    /**
     * Setter for divisionId
     * @param divisionId divisionId
     */
    public void setDivisionId(int divisionId) {
        this.divisionId = divisionId;
    }
    /**
     * Getter for location
     * @return location of object
     */
    public String getLocation() {
        return location;
    }
    /**
     * Setter for location
     * @param location location
     */
    public void setLocation(String location) {
        this.location = location;
    }
}
