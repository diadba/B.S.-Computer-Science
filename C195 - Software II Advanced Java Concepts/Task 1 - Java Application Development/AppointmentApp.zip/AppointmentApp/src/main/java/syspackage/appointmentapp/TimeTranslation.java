package syspackage.appointmentapp;

import java.sql.Timestamp;
import java.time.*;
import java.time.format.DateTimeFormatter;

/**
 * Class that makes use of given times and does appropriate translation.
 */
public class TimeTranslation {
    /**
     * Function that given the current time translates to UTC for database submission.
     * @return NOW() in UTC.
     */
    public static LocalDateTime getUtc() {
        System.out.println("*****************************************************************************************");
        System.out.println("Converting local now system time to UTC.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        LocalDateTime localCurr = LocalDateTime.now();
        LocalDate localDate = localCurr.toLocalDate();
        LocalTime localTime = localCurr.toLocalTime();
        System.out.println("Local date: " + localDate);
        System.out.println("Local time: " + localTime);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Converting local now to database datetime.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        int localCurrTimeInSeconds = localTime.toSecondOfDay();
        System.out.println("Local end time in seconds: " + localCurrTimeInSeconds);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        int timeDifference = (ZoneId.of(String.valueOf(ZoneId.systemDefault())).getRules().getOffset(Instant.now())).getTotalSeconds() * -1;
        System.out.println("Local to database time difference, in seconds: " + timeDifference);
        System.out.println("*****************************************************************************************");

        int dbTimeInSeconds = localCurrTimeInSeconds + timeDifference;
        System.out.println("Database end time in seconds: " + dbTimeInSeconds);

        LocalDate dbDate = localDate;

        System.out.print("Is database end time the day before? ");
        if(dbTimeInSeconds < 0) {
            System.out.println("Yes.");
            dbDate = localDate.minusDays(1);
            dbTimeInSeconds += 86400;
        }
        else { System.out.println("No."); }

        System.out.print("Is database end time the day after? ");
        if(dbTimeInSeconds >= 86400) {
            System.out.println("Yes.");
            dbDate = localDate.plusDays(1);
            dbTimeInSeconds -= 86400;
        }
        else { System.out.println("No."); }

        LocalTime dbTime = LocalTime.ofSecondOfDay(dbTimeInSeconds);

        System.out.println("Database date: " + dbDate);
        System.out.println("Database datetime: " + dbDate + " " + dbTime);

        System.out.println("Taking database datetime back to format.");
        LocalDateTime dbDateTime = LocalDateTime.of(dbDate, dbTime);
        System.out.println("Database datetime: " + dbDateTime);

        return dbDateTime;
    }

    /**
     * Function that checks if a given time (UTC) is in business hours of ET.
     * @param dateTimeInput time in database.
     * @return True if between 08:00 A.M. - 10:00 P.M. ET.
     */
    public static boolean isDbInEt(LocalDateTime dateTimeInput) {
        System.out.println("*****************************************************************************************");
        System.out.println("Converting database datetime to ET datetime.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Database datetime: " + dateTimeInput);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        LocalTime dbTime = dateTimeInput.toLocalTime();
        System.out.println("Database time: " + dbTime);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        LocalDate dbDate = dateTimeInput.toLocalDate();
        System.out.println("Database date: " + dbDate);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        int dbTimeInSeconds = dbTime.toSecondOfDay();
        System.out.println("Database time in seconds: " + dbTimeInSeconds);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        int timeDifference = (ZoneId.of(String.valueOf(ZoneId.of("US/Eastern"))).getRules().getOffset(Instant.now())).getTotalSeconds();
        System.out.println("UTC to ET time difference, in seconds: " + timeDifference);
        System.out.println("*****************************************************************************************");

        int etStartTimeInSeconds = dbTimeInSeconds + timeDifference;
        System.out.println("ET time in seconds: " + etStartTimeInSeconds);

        LocalDate etDate = dbDate;

        System.out.print("Is ET time the day before? ");
        if(etStartTimeInSeconds < 0) {
            System.out.println("Yes.");
            etDate = dbDate.minusDays(1);
            etStartTimeInSeconds += 86400;
        }
        else { System.out.println("No."); }

        System.out.print("Is ET time the day after? ");
        if(etStartTimeInSeconds >= 86400) {
            System.out.println("Yes.");
            etDate = dbDate.plusDays(1);
            etStartTimeInSeconds -= 86400;
        }
        else { System.out.println("No."); }

        LocalTime etTime = LocalTime.ofSecondOfDay(etStartTimeInSeconds);

        System.out.println("ET date: " + etDate);
        System.out.println("ET datetime: " + etDate + " " + etTime);

        System.out.println("Taking ET datetime back to format.");
        dateTimeInput = LocalDateTime.of(etDate, etTime);
        System.out.println("ET datetime: " + dateTimeInput);

        LocalDateTime etOpen = LocalDateTime.of(etDate, LocalTime.of(8,0,0));
        LocalDateTime etClose = LocalDateTime.of(etDate, LocalTime.of(22,0,0));

        if(dateTimeInput.isBefore(etOpen)) {
            System.out.println("*****************************************************************************************");
            System.out.println("Eastern time from input: " + dateTimeInput + " is before " + etOpen);
            System.out.println("Field invalid.");
            AddAppointmentController.setOutOfBounds(true);
            UpdateAppointmentController.setOutOfBounds(true);
            System.out.println("*****************************************************************************************");
            return false;
        }
        else if(dateTimeInput.isAfter(etClose)) {
            System.out.println("*****************************************************************************************");
            System.out.println("Eastern time from input: " + dateTimeInput + " is after " + etClose);
            System.out.println("Field invalid.");
            System.out.println("*****************************************************************************************");
            AddAppointmentController.setOutOfBounds(true);
            UpdateAppointmentController.setOutOfBounds(true);
            return false;
        }
        else { return true; }
    }
    public static String localToUtc(String dateTime) {
        System.out.println(dateTime + " in.");
        System.out.println("*****************************************************************************************");
        Timestamp localTimeStamp = Timestamp.valueOf(String.valueOf(dateTime));
        System.out.println("localTimeStamp: " + localTimeStamp);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        LocalDateTime ofLocalDateTime = localTimeStamp.toLocalDateTime();
        System.out.println("ofLocalDateTime: " + ofLocalDateTime);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        ZoneId localZoneId = ZoneId.of(ZoneId.systemDefault().toString());
        ZonedDateTime systemDateTime = ofLocalDateTime.atZone(localZoneId);
        System.out.println("systemDateTime: " + systemDateTime);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        ZoneId utcZoneId = ZoneId.of("UTC");
        ZonedDateTime utcDateTime = systemDateTime.withZoneSameInstant(utcZoneId);
        System.out.println("utcDateTime: " + utcDateTime);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        LocalDateTime translatedUtc = utcDateTime.toLocalDateTime();
        System.out.println("utcFormatted : " + translatedUtc);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        String utcFormatted = translatedUtc.format(DateTimeFormatter.ofPattern("yyy-MM-dd HH:mm:ss"));
        System.out.println("Formatted for return.");
        System.out.println("*****************************************************************************************");

        System.out.println(utcFormatted + " out.");

        return utcFormatted;
    }
    public static String utcToLocal(String dateTime) {
        System.out.println("*****************************************************************************************");
        Timestamp utcTimeStamp = Timestamp.valueOf(String.valueOf(dateTime));
        System.out.println("utcTimeStamp: " + utcTimeStamp);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        LocalDateTime ofUtcDateTime = utcTimeStamp.toLocalDateTime();
        System.out.println("ofUtcDateTime: " + ofUtcDateTime);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        ZoneId utcZoneId = ZoneId.of("UTC");
        ZonedDateTime utcDateTime = ofUtcDateTime.atZone(utcZoneId);
        System.out.println("utcDateTime: " + utcDateTime);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        ZoneId localZoneId = ZoneId.of(ZoneId.systemDefault().getId());
        ZonedDateTime localDateTime = utcDateTime.withZoneSameInstant(localZoneId);
        System.out.println("localDateTime: " + localDateTime);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        LocalDateTime translatedLocal = localDateTime.toLocalDateTime();
        System.out.println("localFormatted : " + translatedLocal);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        String localFormatted = translatedLocal.format(DateTimeFormatter.ofPattern("yyy-MM-dd HH:mm:ss"));
        System.out.println("Formatted for return.");
        System.out.println("*****************************************************************************************");

        System.out.println("From utcToLocal: " + localFormatted);

        return localFormatted;
    }
    public static boolean checkBusinessHours(String dateTime) {
        System.out.println("*****************************************************************************************");
        Timestamp dbTimeStamp = Timestamp.valueOf(String.valueOf(dateTime));
        System.out.println("dbTimeStamp: " + dbTimeStamp);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        LocalDateTime ofDbDateTime = dbTimeStamp.toLocalDateTime();
        System.out.println("ofDbDateTime: " + ofDbDateTime);
        System.out.println("*****************************************************************************************");


        System.out.println("*****************************************************************************************");
        ZoneId dbZoneId = ZoneId.of("UTC");
        ZonedDateTime dbDateTime = ofDbDateTime.atZone(dbZoneId);
        System.out.println("dbDateTime: " + dbDateTime);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        ZoneId easternZoneId = ZoneId.of("US/Eastern");
        ZonedDateTime easternDateTime = dbDateTime.withZoneSameInstant(easternZoneId);
        System.out.println("easternDateTime: " + easternDateTime);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        LocalDateTime translatedEastern = easternDateTime.toLocalDateTime();
        System.out.println("easternFormatted : " + translatedEastern);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        String easternFormatted = translatedEastern.format(DateTimeFormatter.ofPattern("yyy-MM-dd HH:mm:ss"));
        System.out.println("Formatted for return.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("*****************************************************************************************");
        System.out.println("*****************************************************************************************");
        System.out.println("Checking time respective to date.");

        LocalDateTime etOpen = LocalDateTime.of(translatedEastern.toLocalDate(), LocalTime.of(8,0,0));
        LocalDateTime etClose = LocalDateTime.of(translatedEastern.toLocalDate(), LocalTime.of(22,0,0));

        if(translatedEastern.toLocalDate().isEqual(ofDbDateTime.toLocalDate())) {
            if(easternDateTime.toLocalTime().isBefore(LocalTime.of(8,0,0))) {
                System.out.println("*****************************************************************************************");
                System.out.println("Database date: " + ofDbDateTime.toLocalDate());
                System.out.println("Database time: " + ofDbDateTime.toLocalTime());
                System.out.println("Eastern date: " + translatedEastern.toLocalDate());
                System.out.println("Eastern time: " + translatedEastern.toLocalTime());
                System.out.println("Business opens at 08:00:00. Database to Eastern time: " + easternFormatted);
                System.out.println("*****************************************************************************************");
                System.out.println("Time not within hours.");
                return false;
            }
            else if(translatedEastern.toLocalTime().isAfter(LocalTime.of(22,0,0))) {
                System.out.println("*****************************************************************************************");
                System.out.println("Database date: " + ofDbDateTime.toLocalDate());
                System.out.println("Database time: " + ofDbDateTime.toLocalTime());
                System.out.println("Eastern date: " + translatedEastern.toLocalDate());
                System.out.println("Eastern time: " + translatedEastern.toLocalTime());
                System.out.println("Business closes at 22:00:00. Database to Eastern time: " + easternFormatted);
                System.out.println("*****************************************************************************************");
                System.out.println("Time not within hours.");
                return false;
            }
        }
        else if(translatedEastern.toLocalDate().plusDays(1).isEqual(ofDbDateTime.toLocalDate())) {
            if(easternDateTime.toLocalTime().isBefore(LocalTime.of(8,0,0))) {
                System.out.println("*****************************************************************************************");
                System.out.println("Database date: " + ofDbDateTime.toLocalDate());
                System.out.println("Database time: " + ofDbDateTime.toLocalTime());
                System.out.println("Eastern date: " + translatedEastern.toLocalDate());
                System.out.println("Eastern time: " + translatedEastern.toLocalTime());
                System.out.println("Business opens at 08:00:00. Database to Eastern time: " + easternFormatted);
                System.out.println("*****************************************************************************************");
                System.out.println("Time not within hours.");
                return false;
            }
            else if(translatedEastern.toLocalTime().isAfter(LocalTime.of(22,0,0))) {
                System.out.println("*****************************************************************************************");
                System.out.println("Database date: " + ofDbDateTime.toLocalDate());
                System.out.println("Database time: " + ofDbDateTime.toLocalTime());
                System.out.println("Eastern date: " + translatedEastern.toLocalDate());
                System.out.println("Eastern time: " + translatedEastern.toLocalTime());
                System.out.println("Business closes at 22:00:00. Database to Eastern time: " + easternFormatted);
                System.out.println("*****************************************************************************************");
                System.out.println("Time not within hours.");
                return false;
            }
        }
        System.out.println("Time within hours.");
        return true;
    }
}
