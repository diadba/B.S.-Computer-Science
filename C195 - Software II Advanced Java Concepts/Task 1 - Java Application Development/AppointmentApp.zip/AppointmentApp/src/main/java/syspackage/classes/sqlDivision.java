package syspackage.classes;

import java.time.LocalDateTime;

/**
 * Class for object(s) 'sqlDivision'. sqlDivision objects are made as objects reflecting the 'first_level_divisions' table
 * in database.
 * @author Anthony Coots
 */
public class sqlDivision {
    /**
     * divisionId matching Division_ID in table.
     */
    private int divisionId;
    /**
     * division matching Division in table.
     */
    private String division;
    /**
     * createDate matching Create_Date in table.
     */
    private LocalDateTime createDate;
    /**
     * createdBy matching Created_By in table.
     */
    private String createdBy;
    /**
     * lastUpdate matching Last_Update in table.
     */
    private LocalDateTime lastUpdate;
    /**
     * lastUpdatedBy matching Last_Updated_By in table.
     */
    private String lastUpdatedBy;
    /**
     * countryId matching Country_ID in table.
     */
    private int countryId;

    /**
     * Class constructor
     * @param divisionId - Division_ID
     * @param division - Division
     * @param createDate - Create_Date
     * @param createdBy - Created_By
     * @param lastUpdate - Last_Update
     * @param lastUpdatedBy - Last_Updated_By
     * @param countryId - Country_ID
     */
    public sqlDivision(int divisionId, String division, LocalDateTime createDate, String createdBy, LocalDateTime lastUpdate,
                       String lastUpdatedBy, int countryId) {
        this.divisionId = divisionId;
        this.division = division;
        this.createDate = createDate;
        this.createdBy = createdBy;
        this.lastUpdate = lastUpdate;
        this.lastUpdatedBy = lastUpdatedBy;
        this.countryId = countryId;
    }
    /**
     * Getter for divisionId
     * @return divisionId of object
     */
    public int getDivisionId() {
        return divisionId;
    }
    /**
     * Setter for divisionId
     * @param divisionId divisionId
     */
    public void setDivisionId(int divisionId) {
        this.divisionId = divisionId;
    }
    /**
     * Getter for division
     * @return division of object
     */
    public String getDivision() {
        return division;
    }
    /**
     * Setter for division
     * @param division division
     */
    public void setDivision(String division) {
        this.division = division;
    }
    /**
     * Getter for createDate
     * @return createDate of object
     */
    public LocalDateTime getCreateDate() {
        return createDate;
    }
    /**
     * Setter for createDate
     * @param createDate createDate
     */
    public void setCreateDate(LocalDateTime createDate) {
        this.createDate = createDate;
    }
    /**
     * Getter for createdBy
     * @return createdBy of object
     */
    public String getCreatedBy() {
        return createdBy;
    }
    /**
     * Setter for createdBy
     * @param createdBy createdBy
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }
    /**
     * Getter for lastUpdate
     * @return lastUpdate of object
     */

    public LocalDateTime getLastUpdate() {
        return lastUpdate;
    }
    /**
     * Setter for lastUpdate
     * @param lastUpdate lastUpdate
     */
    public void setLastUpdate(LocalDateTime lastUpdate) {
        this.lastUpdate = lastUpdate;
    }
    /**
     * Getter for lastUpdatedBy
     * @return lastUpdatedBy of object
     */
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }
    /**
     * Setter for lastUpdatedBy
     * @param lastUpdatedBy lastUpdatedBy
     */
    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }
    /**
     * Getter for countryId
     * @return countryId of object
     */
    public int getCountryId() {
        return countryId;
    }
    /**
     * Setter for countryId
     * @param countryId countryId
     */
    public void setCountryId(int countryId) {
        this.countryId = countryId;
    }
}
