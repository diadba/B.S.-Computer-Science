package syspackage.classes;

import java.time.LocalDateTime;

/**
 * Class for object(s) 'sqlCustomer'. sqlCustomer objects are made as objects reflecting the 'customers' table
 * in database.
 * @author Anthony Coots
 */
public class sqlCustomer {
    /**
     * customerId matching Customer_ID in table.
     */
    private int customerId;
    /**
     * customerName matching Customer_Name in table.
     */
    private String customerName;
    /**
     * customerAddress matching Address in table.
     */
    private String customerAddress;
    /**
     * customerPostal matching Postal_Code in table.
     */
    private String customerPostal;
    /**
     * customerPhone matching Phone in table.
     */
    private String customerPhone;
    /**
     * createDate matching Create_Date in table.
     */
    private LocalDateTime createDate;
    /**
     * createdBy matching Created_By in table.
     */
    private String createdBy;
    /**
     * lastUpdate matching Last_Update in table.
     */
    private LocalDateTime lastUpdate;
    /**
     * lastUpdatedBy matching Last_Updated_By in table.
     */
    private String lastUpdatedBy;
    /**
     * fullAddress for table view listing.
     */
    private String fullAddress;
    /**
     * divisionId matching division_ID in table.
     */
    private int divisionId;

    /**
     * Class constructor
     * @param customerId - Customer_ID
     * @param customerName - Customer_Name
     * @param customerAddress - Address
     * @param customerPostal - Postal_Code
     * @param customerPhone - Phone
     * @param createDate - Create_Date
     * @param createdBy - Created_By
     * @param lastUpdate - Last_Update
     * @param lastUpdatedBy - Last_Updated_By
     * @param divisionId - Division_ID
     */
    public sqlCustomer(int customerId, String customerName, String customerAddress, String customerPostal, String customerPhone,
                       LocalDateTime createDate, String createdBy, LocalDateTime lastUpdate,  String lastUpdatedBy, int divisionId) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.customerAddress = customerAddress;
        this.customerPostal = customerPostal;
        this.customerPhone = customerPhone;
        this.createDate = createDate;
        this.createdBy = createdBy;
        this.lastUpdate = lastUpdate;
        this.lastUpdatedBy = lastUpdatedBy;
        this.divisionId = divisionId;
    }
    /**
     * Getter for customerId
     * @return customerId of object
     */
    public int getCustomerId() {
        return customerId;
    }
    /**
     * Setter for customerId
     * @param customerId customerId
     */
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }
    /**
     * Getter for customerName
     * @return customerName of object
     */
    public String getCustomerName() {
        return customerName;
    }
    /**
     * Setter for customerName
     * @param customerName customerName
     */
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }
    /**
     * Getter for customerAddress
     * @return customerAddress of object
     */
    public String getCustomerAddress() {
        return customerAddress;
    }
    /**
     * Setter for customerAddress
     * @param customerAddress customerAddress
     */
    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }
    /**
     * Getter for customerPostal
     * @return customerPostal of object
     */
    public String getCustomerPostal() {
        return customerPostal;
    }
    /**
     * Setter for customerPostal
     * @param customerPostal customerPostal
     */
    public void setCustomerPostal(String customerPostal) {
        this.customerPostal = customerPostal;
    }
    /**
     * Getter for customerPhone
     * @return customerPhone of object
     */
    public String getCustomerPhone() {
        return customerPhone;
    }
    /**
     * Setter for customerPhone
     * @param customerPhone customerPhone
     */
    public void setCustomerPhone(String customerPhone) {
        this.customerPhone = customerPhone;
    }
    /**
     * Getter for createDate
     * @return createDate of object
     */
    public LocalDateTime getCreateDate() {
        return createDate;
    }
    /**
     * Setter for createDate
     * @param createDate createDate
     */
    public void setCreateDate(LocalDateTime createDate) {
        this.createDate = createDate;
    }
    /**
     * Getter for createdBy
     * @return createdBy of object
     */
    public String getCreatedBy() {
        return createdBy;
    }
    /**
     * Setter for createdBy
     * @param createdBy createdBy
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }
    /**
     * Getter for lastUpdate
     * @return lastUpdate of object
     */

    public LocalDateTime getLastUpdate() {
        return lastUpdate;
    }
    /**
     * Setter for lastUpdate
     * @param lastUpdate lastUpdate
     */
    public void setLastUpdate(LocalDateTime lastUpdate) {
        this.lastUpdate = lastUpdate;
    }
    /**
     * Getter for lastUpdatedBy
     * @return lastUpdatedBy of object
     */
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }
    /**
     * Setter for lastUpdatedBy
     * @param lastUpdatedBy lastUpdatedBy
     */
    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }
    /**
     * Getter for divisionId
     * @return divisionId of object
     */
    public int getDivisionId() {
        return divisionId;
    }
    /**
     * Setter for divisionId
     * @param divisionId divisionId
     */
    public void setDivisionId(int divisionId) {
        this.divisionId = divisionId;
    }
    /**
     * Getter for fullAddress
     * @return lastUpdatedBy of object
     */
    public String getFullAddress() {
        return fullAddress;
    }
    /**
     * Setter for fullAddress
     * @param fullAddress fullAddress
     */
    public void setFullAddress(String fullAddress) {
        this.fullAddress = fullAddress;
    }
}
