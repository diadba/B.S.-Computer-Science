package syspackage.appointmentapp;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import syspackage.classes.sqlAppointment;
import syspackage.classes.sqlContact;
import syspackage.classes.sqlReport;
import syspackage.dao.appointmentSQL;
import syspackage.dao.reportSQL;
import syspackage.helper.JDBC;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.ResourceBundle;

/**
 * Class that controls the logic for the form that shows reports.
 * @author Anthony Coots
 */
public class ReportsController implements Initializable {
    /**
     * FXML variable combo box in form for contact selection.
     */
    @FXML
    private ComboBox<String> contactCombo;
    /**
     * FXML variable table view for displaying month | count view.
     */
    @FXML
    private TableView<sqlReport> monthView;
    /**
     * FXML variable table view for displaying type | count view.
     */
    @FXML
    private TableView<sqlReport> typeView;
    /**
     * FXML variable table view for a contacts schedule.
     */
    @FXML
    private TableView<sqlAppointment> contactScheduleView;
    /**
     * FXML variable table view for a location | count view. (For additional report).
     */
    @FXML
    private TableView<sqlReport> locationOfCustomersView;
    /**
     * FXML variable table column for column in contact table view that holds appointment IDs.
     */
    @FXML
    private TableColumn<sqlAppointment, Integer> appointmentIdField;
    /**
     * FXML variable table column for column in contact table view that holds appointment title.
     */
    @FXML
    private TableColumn<sqlAppointment, String> titleField;
    /**
     * FXML variable table column for column in contact table view that holds appointment description.
     */
    @FXML
    private TableColumn<sqlAppointment, String> descriptionField;
    /**
     * FXML variable table column for column in contact table view that holds appointment start.
     */
    @FXML
    private TableColumn<sqlAppointment, LocalDateTime> startField;
    /**
     * FXML variable table column for column in contact table view that holds appointment end.
     */
    @FXML
    private TableColumn<sqlAppointment, LocalDateTime> endField;
    /**
     * FXML variable table column for column in contact table view that holds appointment customer IDs.
     */
    @FXML
    private TableColumn<sqlAppointment, Integer> customerIdField;
    /**
     * FXML variable table column for column in month table view that holds appointment month name.
     */
    @FXML
    private TableColumn<sqlReport, String> month;
    /**
     * FXML variable table column for column in month table view that holds appointment month total.
     */
    @FXML
    private TableColumn<sqlReport, Integer> total;
    /**
     * FXML variable table column for column in type table view that holds appointment type name.
     */
    @FXML
    private TableColumn<sqlReport, String> type;
    /**
     * FXML variable table column for column in type table view that holds appointment type total.
     */
    @FXML
    private TableColumn<sqlReport, Integer> totalType;
    /**
     * FXML variable table column for column in location table view that holds appointment location name.
     */
    @FXML
    private TableColumn<sqlReport, String> location;
    /**
     * FXML variable table column for column in month table view that holds appointment location total.
     */
    @FXML
    private TableColumn<sqlReport, Integer> customerTotal;
    /**
     * List made for all appointments types.
     */
    public static ObservableList<sqlReport> allTypes = FXCollections.observableArrayList();
    /**
     * List made for all appointments.
     */
    public static ObservableList<sqlAppointment> allAppointments = FXCollections.observableArrayList();
    /**
     * List made for reiteration to set combo box selections.
     */
    public static ObservableList<String> allStrings = FXCollections.observableArrayList();

    /**
     * Function that initializes the scene, populating all reports.
     * @param url path location.
     * @param resourceBundle source through resources.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        reportSQL.setMonthTable(JDBC.connection);
        setMonthTable();
        allTypes = FXCollections.observableArrayList();

        reportSQL.setTypeTable(JDBC.connection);
        setTypeTable();
        allTypes = FXCollections.observableArrayList();

        listContacts();

        contactCombo.valueProperty().addListener((
                (observableValue, s, t1) -> {
                    String selectedContact = String.valueOf(contactCombo.getSelectionModel().getSelectedItem());
                    int contactId = appointmentSQL.contactIdFromContactName(JDBC.connection, selectedContact);
                    appointmentSQL.appointmentsByContact(JDBC.connection, contactId);
                    setContactScheduleView();
                }));
        allTypes = FXCollections.observableArrayList();

        reportSQL.setLocationsTable(JDBC.connection);
        setLocationsTable();
    }
    /**
     * Function that sets all locations table (additional report).
     */
    public void setLocationsTable() {
        locationOfCustomersView.setItems(allTypes);
        location.setCellValueFactory(new PropertyValueFactory<>("type"));
        customerTotal.setCellValueFactory(new PropertyValueFactory<>("count"));
    }
    /**
     * Function that sets month | count table.
     */
    public void setMonthTable() {
        monthView.setItems(allTypes);
        month.setCellValueFactory(new PropertyValueFactory<>("type"));
        total.setCellValueFactory(new PropertyValueFactory<>("count"));
    }
    /**
     * Function that sets type | count table.
     */
    public void setTypeTable() {
        typeView.setItems(allTypes);
        type.setCellValueFactory(new PropertyValueFactory<>("type"));
        totalType.setCellValueFactory(new PropertyValueFactory<>("count"));
    }
    /**
     * Function that sets contact's schedule table.
     */
    public void setContactScheduleView() {
        contactScheduleView.setItems(allAppointments);
        appointmentIdField.setCellValueFactory(new PropertyValueFactory<>("appointmentId"));
        titleField.setCellValueFactory(new PropertyValueFactory<>("title"));
        descriptionField.setCellValueFactory(new PropertyValueFactory<>("description"));
        startField.setCellValueFactory(new PropertyValueFactory<>("start"));
        endField.setCellValueFactory(new PropertyValueFactory<>("end"));
        customerIdField.setCellValueFactory(new PropertyValueFactory<>("customerId"));
    }
    /**
     * Function that sets contact combo box.
     */
    private void listContacts() {
        try {
            System.out.println("*****************************************************************************************");
            System.out.println("Opening connection for contactCombo comboBox.");
            System.out.println("*****************************************************************************************");
            appointmentSQL.contacts(JDBC.connection);

            for(sqlContact contact : AppointmentsController.allContacts) {
                System.out.println("*****************************************************************************************");
                System.out.println("Adding string location to temporary list.");
                allStrings.add(String.valueOf(contact.getContactName()));
                System.out.println(contact.getContactName());
            }
            System.out.println("*****************************************************************************************");
        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
        System.out.println("*****************************************************************************************");
        contactCombo.setItems(allStrings);
        System.out.println("Set contactCombo comboBox with all resultSet contact IDs.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        allStrings = FXCollections.observableArrayList();
        System.out.println("Temporary list cleared.");
        System.out.println("*****************************************************************************************");
    }
    /**
     * Function that returns to mainscreen upon return button clicked.
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (Load new).
     */
    public void returnButtonClicked(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        stage.close();
        mainscreen(new Stage());
    }
    /**
     * Function that sets new stage for mainscreen.
     * @param stage sets new stage
     * @throws IOException FXMLLoader (Load new).
     */
    private void mainscreen(Stage stage) throws IOException {
        System.out.println("*****************************************************************************************");
        System.out.println("Getting resource for FXML 'Mainscreen.fxml'.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Loading new stage.");
        System.out.println("*****************************************************************************************");

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Mainscreen.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1080, 720);
        stage.setTitle("Appointments");
        stage.setScene(scene);
        stage.show();
    }
}
