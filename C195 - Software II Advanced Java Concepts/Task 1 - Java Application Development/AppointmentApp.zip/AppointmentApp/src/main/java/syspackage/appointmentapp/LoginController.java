package syspackage.appointmentapp;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import syspackage.classes.sqlUser;
import syspackage.dao.loginSQL;
import syspackage.helper.JDBC;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.ZoneId;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * Class that controls the logic for the login scene.
 * @author Anthony Coots
 */
public class LoginController implements Initializable {
    /**
     * FXML variable button for attempting to log in.
     */
    @FXML
    private Button loginButton;
    /**
     * FXML variable label for notifying user of a failed login attempt.
     */
    @FXML
    private Label failedLogin;
    /**
     * FXML variable label for displaying a users zone id.
     */
    @FXML
    private Label timeZone;
    /**
     * FXML variable text for showing login field.
     */
    @FXML
    private Text loginText;
    /**
     * FXML variable text for showing password field.
     */
    @FXML
    private Text passwordText;
    /**
     * FXML variable text for showing username field.
     */
    @FXML
    private Text usernameText;
    /**
     * FXML variable text field for taking a username.
     */
    @FXML
    private TextField usernameField;
    /**
     * FXML variable text field for taking a password.
     */
    @FXML
    private TextField passwordField;
    /**
     * Variable of 'sqlUser' class to set current customer that has logged in.
     */
    private static sqlUser currentUser;

    /**
     * Function that initializes the login form.
     * @param url path location.
     * @param resourceBundle source through resources.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        System.out.println("*****************************************************************************************");
        System.out.println("*****************************************************************************************");
        System.out.println("Initializing LoginController.");
        System.out.println("*****************************************************************************************");
        System.out.println("*****************************************************************************************");
        System.out.println();

        System.out.println("*****************************************************************************************");
        System.out.println("Getting user locale. Locale.getDefault() gets the locale of the JVM instance.");
        Locale locale = Locale.getDefault(); // Locale.FRANCE;
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Setting JVM default to locale found.");
        Locale.setDefault(locale);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Setting resource bundle based on locale default.");
        System.out.println();
        System.out.println("REQUIREMENT 1: 'automatically translates error control messages into English or French");
        System.out.println("based on the user's computer language setting to translate all the text, labels, buttons,");
        System.out.println("and errors on the form.'");
        System.out.println();
        System.out.println("NOTE: Translation requirements are only found for log-in form.");
        System.out.println();
        resourceBundle = ResourceBundle.getBundle("syspackage/appointmentapp/language", Locale.getDefault());
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Locale set via Locale.setDefault(locale): " + locale);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Setting variable 'zoneId' to ZoneId.systemDefault()");
        ZoneId zoneId = ZoneId.systemDefault();
        System.out.println("Variable zoneId: " + zoneId);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Setting text in form to variable 'zoneId'.");
        timeZone.setText("[" + zoneId + "]");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Setting text based on Locale.getDefault(). Languages can be found in 'resources' folder.");

        usernameText.setText(resourceBundle.getString("username"));
        System.out.println("usernameText set: " + usernameText.getText());

        passwordText.setText(resourceBundle.getString("password"));
        System.out.println("passwordText set: " + passwordText.getText());

        loginText.setText(resourceBundle.getString("login"));
        System.out.println("loginText set: " + loginText.getText());

        loginButton.setText(resourceBundle.getString("login"));
        System.out.println("loginButton set: " + loginButton.getText());
        System.out.println("*****************************************************************************************");
    }

    /**
     * Function for attempting to log in (move to the next screen in application).
     * @param actionEvent required for action load.
     * @throws Exception FXMLLoader (Load new).
     */
    @FXML
    private void attemptLoginClicked(ActionEvent actionEvent) throws Exception {
        ResourceBundle resourceBundle = ResourceBundle.getBundle("syspackage/appointmentapp/language", Locale.getDefault());

        System.out.println("*****************************************************************************************");
        System.out.println("Attempting login.");
        System.out.println("*****************************************************************************************");

        if(loginSQL.viewTable(JDBC.connection, usernameField.getText(), passwordField.getText())) {
            System.out.println("*****************************************************************************************");
            System.out.println("User validation is successful.");
            System.out.println("Username: " + usernameField.getText());
            System.out.println("Password: " + passwordField.getText());
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            System.out.println("Closing login screen.");
            System.out.println("*****************************************************************************************");

            Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
            stage.close();

            System.out.println("*****************************************************************************************");
            System.out.println("Launching menu. Calling launchMenu function.");
            launchMenu(new Stage());
            System.out.println("*****************************************************************************************");

        }
        else {
            System.out.println("*****************************************************************************************");
            System.out.println("Unsuccessful login attempt.");
            System.out.println("Username: " + usernameField.getText());
            System.out.println("Password: " + passwordField.getText());
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            System.out.println("Alerting user.");

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(resourceBundle.getString("errorTitle"));
            alert.setContentText(resourceBundle.getString("invalidCredentials"));
            alert.showAndWait();

            System.out.println();
            System.out.println("REQUIREMENT 1: 'automatically translates error control messages into English or French");
            System.out.println("based on the user's computer language setting.'");
            System.out.println();
            System.out.println("NOTE: Handled with Locale.getDefault().");
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            System.out.println("Displaying error to login form.");
            failedLogin.setText(resourceBundle.getString("invalidCredentials"));
            System.out.println("*****************************************************************************************");
            writeToFile(usernameField.getText(), passwordField.getText(), "fail");
        }
        


    }

    /**
     * Function that takes user text field, password text field, and success or failed login status and writes to file in
     * root directory called 'login_activity.txt'.
     * @param user user text field input.
     * @param pass password text field input.
     * @param validation string if the login attempt succeeded or failed.
     */
    private void writeToFile(String user, String pass, String validation) {
        try {
            System.out.println(new java.io.File(".").getCanonicalPath());
            if(Files.notExists(Path.of("login_activity.txt"))) {
                Files.createFile(Path.of("login_activity.txt"));
            }
            FileWriter fileWriter = new FileWriter("login_activity.txt", true);
            PrintWriter printWriter = new PrintWriter(fileWriter);
            printWriter.append("*****************************************************************************************\n");
            printWriter.append("Attempted login:\n");
            printWriter.append("User: ").append(user).append("\n");
            printWriter.append("Password: ").append(pass).append("\n");
            printWriter.append("Time (UTC): ").append(TimeTranslation.getUtc().toString()).append("\n");
            printWriter.append("[Pass/Fail]: ").append(validation).append("\n");
            printWriter.append("*****************************************************************************************\n");
            printWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }

    /**
     * Function that launches menu upon login success.
     * @param stage sets new stage.
     * @throws IOException FXMLLoader (Load new).
     */
    private void launchMenu(Stage stage) throws IOException {
        writeToFile(usernameField.getText(), passwordField.getText(), "pass");
        System.out.println("*****************************************************************************************");
        System.out.println("Getting resource for FXML 'Mainscreen.fxml'.");
        System.out.println("*****************************************************************************************");

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Mainscreen.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1080, 720);
        stage.setTitle("C195 Application.");
        stage.setScene(scene);
        stage.show();

        System.out.println("*****************************************************************************************");
        System.out.println("Showing stage.");
        System.out.println("*****************************************************************************************");
    }

    /**
     * Getter for currentUser variable.
     * @return currentUser
     */
    public static sqlUser getCurrentUser() {
        return currentUser;
    }

    /**
     * Setter for currentUser variable.
     * @param currentUser currentUser
     */
    public static void setCurrentUser(sqlUser currentUser) {
        LoginController.currentUser = currentUser;
    }
}