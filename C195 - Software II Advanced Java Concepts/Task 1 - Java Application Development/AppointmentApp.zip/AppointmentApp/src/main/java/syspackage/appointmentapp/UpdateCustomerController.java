package syspackage.appointmentapp;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import syspackage.classes.sqlCountry;
import syspackage.classes.sqlDivision;
import syspackage.dao.customerSQL;
import syspackage.helper.JDBC;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.*;
import java.util.ResourceBundle;

/**
 * Class that controls the logic for the form that updates customers to database.
 * @author Anthony Coots
 */
public class UpdateCustomerController implements Initializable {
    /**
     * FXML variable combo box in form for country selection.
     */
    @FXML
    private ComboBox<String> countryCombo;
    /**
     * FXML variable combo box in form for division selection.
     */
    @FXML
    private ComboBox<String> divisionCombo;
    /**
     * FXML variable text in form to display current login username.
     */
    @FXML
    private Text usernameText;
    /**
     * FXML variable text field in form to display auto generated customer ID.
     */
    @FXML
    private TextField customerIdField;
    /**
     * FXML variable text field in form for name declaration.
     */
    @FXML
    private TextField nameField;
    /**
     * FXML variable text field in form for address declaration.
     */
    @FXML
    private TextField addressField;
    /**
     * FXML variable text field in form for postal code declaration.
     */
    @FXML
    private TextField postalField;
    /**
     * FXML variable text field in form for phone declaration.
     */
    @FXML
    private TextField phoneField;
    /**
     * List made for reiteration to set combo box selections. I.E., allStrings may be set with country names to then set
     * the combo box for countries.
     */
    public ObservableList<String> allStrings = FXCollections.observableArrayList();

    /**
     * @param url path location.
     * @param resourceBundle source through resources.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        System.out.println("*****************************************************************************************");
        System.out.println("*****************************************************************************************");
        System.out.println("Initializing UpdateAppointmentController.");
        System.out.println("*****************************************************************************************");
        System.out.println("*****************************************************************************************");
        System.out.println();

        System.out.println("*****************************************************************************************");
        System.out.println();
        System.out.println("REQUIREMENT 2: - 'Customer IDs are auto-generated, and first-level division");
        System.out.println("(i.e., states, provinces) and country data are collected using separate combo boxes.'");
        System.out.println();
        System.out.println(" - 'When updating a customer, the customer data auto-populates in the form.'");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Setting customerIdField textField to show current customer id.");
        customerIdField.setText(String.valueOf(CustomersController.getCurrentCustomer().getCustomerId()));
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Setting nameField textField to show current customer name.");
        nameField.setText(CustomersController.getCurrentCustomer().getCustomerName());
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Setting addressField textField to show current customer address.");
        addressField.setText(CustomersController.getCurrentCustomer().getCustomerAddress());
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Displaying current appointment customer selection.");
        listDivisions();
        int customerDivisionId = CustomersController.getCurrentCustomer().getDivisionId();
        String customerDivision = customerSQL.divisionNameFromDivisionId(JDBC.connection, customerDivisionId);
        divisionCombo.setValue(customerDivision);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Displaying current appointment user selection.");
        listCountries();
        String customerCountry = customerSQL.countryNameFromDivisionId(JDBC.connection, customerDivisionId);
        countryCombo.setValue(customerCountry);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Setting usernameText display for current user.");
        usernameText.setText("User: " + LoginController.getCurrentUser().getUsername());
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Setting postalField textField to show current customer postal.");
        postalField.setText(CustomersController.getCurrentCustomer().getCustomerPostal());
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Setting phoneField textField to show current customer phone.");
        phoneField.setText(CustomersController.getCurrentCustomer().getCustomerPhone());
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("All fields displayed.");
        System.out.println("*****************************************************************************************");

        // Lambda.
        divisionCombo.valueProperty().addListener((
                (observableValue, s, t1) -> listSingleCountry(customerSQL.divisionIdFromDivisionName(JDBC.connection, divisionCombo.getSelectionModel().getSelectedItem()))));

    }
    /**
     * Function that calls a dao function, to list a single country based on divisionId, to later be displayed as the
     * only relative option in a combo box.
     * @param divisionId ID of division found in division_id columns of database tables.
     */
    private void listSingleCountry(int divisionId) {
        System.out.println("*****************************************************************************************");
        System.out.println("Opening connection for countryCombo comboBox.");
        System.out.println("*****************************************************************************************");

        customerSQL.singleCountries(JDBC.connection, divisionId);

        for(sqlCountry countryObj : CustomersController.allCountries) {
            System.out.println("*****************************************************************************************");
            System.out.println("Adding string location to temporary list: " + countryObj.getCountry());
            allStrings.add(countryObj.getCountry());
        }
        System.out.println("*****************************************************************************************");
        System.out.println("*****************************************************************************************");
        countryCombo.setItems(allStrings);
        System.out.println("Set countryCombo comboBox with all resultSet locations.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        allStrings = FXCollections.observableArrayList();
        System.out.println("Temporary list cleared.");
        System.out.println("*****************************************************************************************");
    }
    /**
     * Function that list all countries set into the allCountries observable list.
     */
    private void listCountries() {

        System.out.println("*****************************************************************************************");
        System.out.println("Opening connection for countryCombo comboBox.");
        System.out.println("*****************************************************************************************");

        customerSQL.countries(JDBC.connection);

        for(sqlCountry countryObj : CustomersController.allCountries) {
            System.out.println("*****************************************************************************************");
            System.out.println("Adding string location to temporary list: " + countryObj.getCountry());
            allStrings.add(countryObj.getCountry());
        }
        System.out.println("*****************************************************************************************");
        System.out.println("*****************************************************************************************");
        countryCombo.setItems(allStrings);
        System.out.println("Set countryCombo comboBox with all resultSet locations.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        allStrings = FXCollections.observableArrayList();
        System.out.println("Temporary list cleared.");
        System.out.println("*****************************************************************************************");

    }
    /**
     * Function that lists all divisions set into the allDivisions observable list.
     */
    private void listDivisions() {
        System.out.println(CustomersController.allDivisions);

        System.out.println("*****************************************************************************************");
        System.out.println("Opening connection for divisionCombo comboBox.");
        System.out.println("*****************************************************************************************");
        customerSQL.divisions(JDBC.connection);

        for(sqlDivision divisionObj : CustomersController.allDivisions) {
            System.out.println("*****************************************************************************************");
            System.out.println("Adding string location to temporary list: " + divisionObj.getDivision());
            allStrings.add(divisionObj.getDivision());
        }
        System.out.println("*****************************************************************************************");
        System.out.println("*****************************************************************************************");
        divisionCombo.setItems(allStrings);
        System.out.println("Set divisionCombo comboBox with all resultSet locations.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        allStrings = FXCollections.observableArrayList();
        System.out.println("Temporary list cleared.");
        System.out.println("*****************************************************************************************");
    }
    /**
     * Function that checks all fields for proper input then responds accordingly, I.E., if fails, scene stays, else proceed.
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (Load new).
     */
    public void saveButtonClicked(ActionEvent actionEvent) throws IOException {
        System.out.println("*****************************************************************************************");
        System.out.println("Checking if all TextFields and ComboBox's have a valid input/selection.");
        System.out.println("*****************************************************************************************");
        if (checkNameField() && checkAddressField() && checkPostalField() && checkPhoneField() && checkCountryBox() && checkDivisionBox()) {
            System.out.println("*****************************************************************************************");
            System.out.println("All TextFields and ComboBox's are valid. Checking start time and end time.");
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            int customerId = CustomersController.getCurrentCustomer().getCustomerId();
            System.out.println("Variable customerId set to value of field input.");
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            String name = nameField.getText();
            System.out.println("Variable name set to value of field input.");
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            String address = addressField.getText();
            System.out.println("Variable address set to value of field input.");
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            String postalCode = postalField.getText();
            System.out.println("Variable postalCode set to value of box selection.");
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            String phone = phoneField.getText();
            System.out.println("Variable phone set to value of box selection.");
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            LocalDateTime createDate = CustomersController.getCurrentCustomer().getCreateDate();
            System.out.println("Variable createDate set to value in database.");
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            String createdBy = CustomersController.getCurrentCustomer().getCreatedBy();
            System.out.println("Variable createdBy set to value in database.");
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            LocalDateTime lastUpdate = TimeTranslation.getUtc();
            System.out.println("Variable lastUpdate set to UTC time.");
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            String lastUpdatedBy = LoginController.getCurrentUser().getUsername();
            System.out.println("Variable lastUpdatedBy set to current user.");
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            String division = divisionCombo.getSelectionModel().getSelectedItem();
            int divisionId = customerSQL.divisionIdFromDivisionName(JDBC.connection, division);
            System.out.println("Variable countryId retrieved from sql via contact string.");
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            System.out.println("Updating customer.");
            System.out.println("*****************************************************************************************");

            try {
                customerSQL.updateCustomer(JDBC.connection, customerId, name, address, postalCode, phone, createDate, createdBy,
                                        lastUpdate, lastUpdatedBy, divisionId);
            } catch (SQLException e) {
                System.out.println("*****************************************************************************************");
                System.out.println("In try/catch, caught: ");
                System.out.println(e.getMessage());
                System.out.println("*****************************************************************************************");
            }

            System.out.println("*****************************************************************************************");
            System.out.println("Customer updated.");
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
            stage.close();
            System.out.println("Stage closed.");
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            System.out.println("Returning to appointment screen.");
            backToView(new Stage());
            System.out.println("*****************************************************************************************");
        } else {
            alert();
        }
    }
    /**
     * Function that returns to scene before current.
     * @param stage sets new stage.
     * @throws IOException FXMLLoader (Load new).
     */
    public void backToView(Stage stage) throws IOException {
        System.out.print("Getting resource for FXML 'Customers.fxml'.");

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Customers.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1080, 720);
        stage.setTitle("Appointments");
        stage.setScene(scene);
        stage.show();
    }
    /**
     * Function that checks if the name field is valid. If name field is empty, the field is not valid.
     * @return True if not empty, false otherwise.
     */
    private boolean checkNameField() {
        System.out.println("*****************************************************************************************");
        System.out.println("Checking nameField TextField for input.");
        System.out.println("*****************************************************************************************");
        return !nameField.getText().trim().isEmpty();
    }
    /**
     * Function that checks if the address field is valid. If address field is empty, the field is not valid.
     * @return True if not empty, false otherwise.
     */
    private boolean checkAddressField() {
        System.out.println("*****************************************************************************************");
        System.out.println("Checking addressField TextField for input.");
        System.out.println("*****************************************************************************************");
        return !addressField.getText().trim().isEmpty();
    }
    /**
     * Function that checks if the postal field is valid. If postal field is empty, the field is not valid.
     * @return True if not empty, false otherwise.
     */
    private boolean checkPostalField() {
        System.out.println("*****************************************************************************************");
        System.out.println("Checking postalField TextField for input.");
        System.out.println("*****************************************************************************************");
        return !postalField.getText().trim().isEmpty();
    }
    /**
     * Function that checks if the phone field is valid. If phone field is empty, the field is not valid.
     * @return True if not empty, false otherwise.
     */
    private boolean checkPhoneField() {
        System.out.println("*****************************************************************************************");
        System.out.println("Checking phoneField TextField for input.");
        System.out.println("*****************************************************************************************");
        return !phoneField.getText().trim().isEmpty();
    }
    /**
     * Function that checks if the country combo box is valid. If combo box is empty, the combo box is not valid.
     * @return True if not empty, false otherwise.
     */
    private boolean checkCountryBox() {
        System.out.println("*****************************************************************************************");
        System.out.println("Checking countryCombo comboBox for input.");
        System.out.println("*****************************************************************************************");
        return countryCombo.getSelectionModel().getSelectedItem() != null;
    }
    /**
     * Function that checks if the division combo box is valid. If combo box is empty, the combo box is not valid.
     * @return True if not empty, false otherwise.
     */
    private boolean checkDivisionBox() {
        System.out.println("*****************************************************************************************");
        System.out.println("Checking divisionCombo comboBox for input.");
        System.out.println("*****************************************************************************************");
        return divisionCombo.getSelectionModel().getSelectedItem() != null;
    }
    /**
     * Function that displays alert for invalid fields.
     */
    public void alert() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Entry Error");
        alert.setContentText("Cannot add appointment without valid fields.");
        alert.showAndWait();
    }
    /**
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (Load new).
     */
    public void cancelButtonClicked(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        stage.close();

        backToView(new Stage());
    }
}
