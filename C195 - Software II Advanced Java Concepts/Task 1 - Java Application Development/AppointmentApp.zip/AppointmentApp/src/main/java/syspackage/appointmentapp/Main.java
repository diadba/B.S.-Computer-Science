package syspackage.appointmentapp;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import syspackage.helper.JDBC;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.TimeZone;

/**
 * Class that extends application. Main.
 * @author Anthony Coots
 */
public class Main extends Application {
    /**
     * Function that starts the application stage.
     * @param stage sets new stage.
     * @throws IOException FXMLLoader (Load new).
     */
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Login.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1080, 720);
        stage.setTitle("Appointment App Logon");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Main function of program.
     * @param args required args.
     */
    public static void main(String[] args) {
        System.out.println("\n*****************************************************************************************");
        System.out.println("Attempting to establish connection...");
        System.out.print("Result: ");
        JDBC.openConnection();
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Listing all time zones:");
        String[] id = TimeZone.getAvailableIDs();
        for (String s : id) {
            System.out.println(s);
        }
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("System default: " + TimeZone.getDefault());
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Setting time zone to local time zone.");
      //  TimeZone.setDefault(TimeZone.getTimeZone("America/Denver"));
      //  System.out.println("System set: " + TimeZone.getDefault());
        System.out.println("*****************************************************************************************");

        Timestamp timestampNow = Timestamp.valueOf(LocalDateTime.now());

        System.out.println("*****************************************************************************************");
        TimeTranslation.localToUtc(String.valueOf(timestampNow));
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println(TimeTranslation.localToUtc(String.valueOf(timestampNow)));
        System.out.println("*****************************************************************************************");

        launch();

        System.out.println("\n*****************************************************************************************");
        System.out.println("Attempting to close connection...");
        System.out.print("Result: ");
        JDBC.closeConnection();
        System.out.println("*****************************************************************************************");
    }
}