package syspackage.dao;

import syspackage.appointmentapp.ReportsController;
import syspackage.classes.sqlReport;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Class that contains SQL statements used for reports application functionality.
 * @author Anthony Coots
 */
public class reportSQL {
    /**
     * Function that sets the additional report table list.
     * @param connection JDBC connection
     */
    public static void setLocationsTable(Connection connection) {
        System.out.println("*****************************************************************************************");
        System.out.println("Query:");
        String query = "SELECT csf.Division, COUNT(csf.Division) AS count "
                     + "FROM client_schedule.customers csc INNER JOIN client_schedule.first_level_divisions csf "
                     + "ON csc.Division_ID = csf.Division_ID "
                     + "GROUP BY csf.Division ";

        System.out.println("*****************************************************************************************");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                System.out.println("*****************************************************************************************");
                String division = resultSet.getString("Division");
                System.out.println("Variable 'Division' - SQL column: 'division' set to: " + division + ".");

                int count = resultSet.getInt("count");
                System.out.println("Variable: 'count' - SQL column: 'count' set to: " + count + ".");

                sqlReport reportObj = new sqlReport(division, count);
                ReportsController.allTypes.add(reportObj);
                System.out.println("*****************************************************************************************");
                System.out.println(reportObj.getType());
            }
        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
    }
    /**
     * Function that sets the month | count table list.
     * @param connection JDBC connection
     */
    public static void setMonthTable(Connection connection) {
        ReportsController.allTypes.clear();
        System.out.println("*****************************************************************************************");
        System.out.println("Query:");
        String query = " SELECT DATE_FORMAT(start, '%M') AS Month, COUNT(start) AS count "
                + " FROM client_schedule.appointments "
                + " GROUP BY Month "
                + " ORDER BY Month ";

        System.out.println("*****************************************************************************************");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                System.out.println("*****************************************************************************************");
                String month = resultSet.getString("Month");
                System.out.println("Variable 'month' - SQL column: 'month' set to: " + month + ".");

                int count = resultSet.getInt("count");
                System.out.println("Variable: 'count' - SQL column: 'count' set to: " + count + ".");

                sqlReport reportObj = new sqlReport(month, count);
                ReportsController.allTypes.add(reportObj);
                System.out.println("*****************************************************************************************");
            }
        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
    }
    /**
     * Function that sets the type | count table list.
     * @param connection
     */
    public static void setTypeTable(Connection connection) {
        ReportsController.allTypes.clear();
        System.out.println("*****************************************************************************************");
        System.out.println("Query:");
        String query = " SELECT Type, COUNT(Type) as Count "
                    +  " FROM client_schedule.appointments "
                    +  " GROUP BY Type ";

        System.out.println("*****************************************************************************************");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                System.out.println("*****************************************************************************************");
                String type = resultSet.getString("Type");
                System.out.println("Variable 'type' - SQL column: 'month' set to: " + type + ".");

                int count = resultSet.getInt("Count");
                System.out.println("Variable: 'count' - SQL column: 'count' set to: " + count + ".");

                sqlReport reportObj = new sqlReport(type, count);
                ReportsController.allTypes.add(reportObj);
                System.out.println("*****************************************************************************************");
            }
        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
    }
}
