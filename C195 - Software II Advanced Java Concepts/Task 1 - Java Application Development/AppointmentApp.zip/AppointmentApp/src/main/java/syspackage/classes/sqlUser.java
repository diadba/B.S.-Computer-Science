package syspackage.classes;

import java.time.LocalDateTime;

/**
 * Class for object(s) 'sqlUser'. sqlUser objects are made as objects reflecting the 'users' table
 * in database.
 * @author Anthony Coots
 */
public class sqlUser {
    /**
     * userId matching User_ID in table.
     */
    private int userId;
    /**
     * username matching User_Name in table.
     */
    private String username;
    /**
     * password matching Password in table.
     */
    private String password;
    /**
     * createDate matching Create_Date in table.
     */
    private LocalDateTime createDate;
    /**
     * createdBy matching Created_By in table.
     */
    private String createdBy;
    /**
     * lastUpdate matching Last_Update in table.
     */
    private LocalDateTime lastUpdate;
    /**
     * lastUpdatedBy matching Last_Updated_By in table.
     */
    private String lastUpdatedBy;

    /**
     * Class constructor
     * @param userId - User_ID
     * @param username - User_Name
     * @param password - Password
     * @param createDate - Create_Date
     * @param createdBy - Created_By
     * @param lastUpdate - Last_Update
     * @param lastUpdatedBy - Last_Updated_By
     */
    public sqlUser(int userId, String username, String password, LocalDateTime createDate, String createdBy,
                   LocalDateTime lastUpdate, String lastUpdatedBy) {
        this.userId = userId;
        this.username = username;
        this.password = password;
        this.createDate = createDate;
        this.createdBy = createdBy;
        this.lastUpdate = lastUpdate;
        this.lastUpdatedBy = lastUpdatedBy;
    }
    /**
     * Getter for userId
     * @return userId of object
     */
    public int getUserId() {
        return userId;
    }
    /**
     * Setter for userId
     * @param userId userId
     */
    public void setUserId(int userId) {
        this.userId = userId;
    }
    /**
     * Getter for username
     * @return username of object
     */
    public String getUsername() {
        return username;
    }
    /**
     * Setter for username
     * @param username username
     */
    public void setUsername(String username) {
        this.username = username;
    }
    /**
     * Getter for password
     * @return password of object
     */
    public String getPassword() {
        return password;
    }
    /**
     * Setter for password
     * @param password password
     */
    public void setPassword(String password) {
        this.password = password;
    }
    /**
     * Getter for createDate
     * @return createDate of object
     */
    public LocalDateTime getCreateDate() {
        return createDate;
    }
    /**
     * Setter for createDate
     * @param createDate createDate
     */
    public void setCreateDate(LocalDateTime createDate) {
        this.createDate = createDate;
    }
    /**
     * Getter for createdBy
     * @return createdBy of object
     */
    public String getCreatedBy() {
        return createdBy;
    }
    /**
     * Setter for createdBy
     * @param createdBy createdBy
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }
    /**
     * Getter for lastUpdate
     * @return lastUpdate of object
     */

    public LocalDateTime getLastUpdate() {
        return lastUpdate;
    }
    /**
     * Setter for lastUpdate
     * @param lastUpdate lastUpdate
     */
    public void setLastUpdate(LocalDateTime lastUpdate) {
        this.lastUpdate = lastUpdate;
    }
    /**
     * Getter for lastUpdatedBy
     * @return lastUpdatedBy of object
     */
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }
    /**
     * Setter for lastUpdatedBy
     * @param lastUpdatedBy lastUpdatedBy
     */
    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }
}



