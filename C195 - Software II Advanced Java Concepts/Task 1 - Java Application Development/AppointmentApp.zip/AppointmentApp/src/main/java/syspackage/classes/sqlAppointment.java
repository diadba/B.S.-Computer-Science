package syspackage.classes;

import java.time.LocalDateTime;

/**
 * Class for object(s) 'sqlAppointment'. sqlAppointment objects are made as objects reflecting the 'appointments' table
 * in database.
 * @author Anthony Coots
 */
public class sqlAppointment {
    /**
     * appointmentId matching Appointment_ID in table.
     */
    private int appointmentId;
    /**
     * title matching Title in table.
     */
    private String title;
    /**
     * description matching Description in table.
     */
    private String description;
    /**
     * location matching Location in table.
     */
    private String location;
    /**
     * type matching Type in table.
     */
    private String type;
    /**
     * start matching Start in table.
     */
    private LocalDateTime start;
    /**
     * end matching End in table.
     */
    private LocalDateTime end;
    /**
     * createDate matching Create_Date in table.
     */
    private LocalDateTime createDate;
    /**
     * createdBy matching Created_By in table.
     */
    private String createdBy;
    /**
     * lastUpdate matching Last_Update in table.
     */
    private LocalDateTime lastUpdate;
    /**
     * lastUpdatedBy matching Last_Updated_By in table.
     */
    private String lastUpdatedBy;
    /**
     * customerId matching Customer_ID in table.
     */
    private int customerId;
    /**
     * userId matching User_ID in table.
     */
    private int userId;
    /**
     * contactId matching Contact_ID in table.
     */
    private int contactId;

    /**
     * Class constructor.
     * @param appointmentId - Appointment_ID
     * @param title - Title
     * @param description - Description
     * @param location - Location
     * @param type - Type
     * @param start - Start
     * @param end - End
     * @param createDate - Create_Date
     * @param createdBy - Created_By
     * @param lastUpdate - Last_Update
     * @param lastUpdatedBy - Last_Updated_By
     * @param customerId - Customer_ID
     * @param userId - User_ID
     * @param contactId - Contact_ID
     */
    public sqlAppointment(int appointmentId, String title, String description, String location, String type, LocalDateTime start,
                          LocalDateTime end, LocalDateTime createDate, String createdBy, LocalDateTime lastUpdate, String lastUpdatedBy,
                          int customerId, int userId, int contactId) {
        this.appointmentId = appointmentId;
        this.title = title;
        this.description = description;
        this.location = location;
        this.type = type;
        this.start = start;
        this.end = end;
        this.createDate = createDate;
        this.createdBy = createdBy;
        this.lastUpdate = lastUpdate;
        this.lastUpdatedBy = lastUpdatedBy;
        this.customerId = customerId;
        this.userId = userId;
        this.contactId = contactId;
    }

    /**
     * Getter for appointmentId
     * @return appointmentId of object
     */
    public int getAppointmentId() {
        return appointmentId;
    }

    /**
     * Setter for appointmentId
     * @param appointmentId appointmentId
     */
    public void setAppointmentId(int appointmentId) {
        this.appointmentId = appointmentId;
    }
    /**
     * Getter for title
     * @return title of object
     */
    public String getTitle() {
        return title;
    }
    /**
     * Setter for title
     * @param title title
     */
    public void setTitle(String title) {
        this.title = title;
    }
    /**
     * Getter for description
     * @return description of object
     */
    public String getDescription() {
        return description;
    }
    /**
     * Setter for description
     * @param description description
     */
    public void setDescription(String description) {
        this.description = description;
    }
    /**
     * Getter for location
     * @return location of object
     */
    public String getLocation() {
        return location;
    }
    /**
     * Setter for location
     * @param location location
     */
    public void setLocation(String location) {
        this.location = location;
    }
    /**
     * Getter for type
     * @return type of object
     */
    public String getType() {
        return type;
    }
    /**
     * Setter for type
     * @param type type
     */
    public void setType(String type) {
        this.type = type;
    }
    /**
     * Getter for start
     * @return start of object
     */
    public LocalDateTime getStart() {
        return start;
    }
    /**
     * Setter for start
     * @param start start
     */
    public void setStart(LocalDateTime start) {
        this.start = start;
    }
    /**
     * Getter for end
     * @return end of object
     */
    public LocalDateTime getEnd() {
        return end;
    }
    /**
     * Setter for end
     * @param end end
     */
    public void setEnd(LocalDateTime end) {
        this.end = end;
    }
    /**
     * Getter for createDate
     * @return createDate of object
     */
    public LocalDateTime getCreateDate() {
        return createDate;
    }
    /**
     * Setter for createDate
     * @param createDate createDate
     */
    public void setCreateDate(LocalDateTime createDate) {
        this.createDate = createDate;
    }
    /**
     * Getter for createdBy
     * @return createdBy of object
     */
    public String getCreatedBy() {
        return createdBy;
    }
    /**
     * Setter for createdBy
     * @param createdBy createdBy
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }
    /**
     * Getter for lastUpdate
     * @return lastUpdate of object
     */
    public LocalDateTime getLastUpdate() {
        return lastUpdate;
    }
    /**
     * Setter for lastUpdate
     * @param lastUpdate lastUpdate
     */
    public void setLastUpdate(LocalDateTime lastUpdate) {
        this.lastUpdate = lastUpdate;
    }
    /**
     * Getter for lastUpdatedBy
     * @return lastUpdatedBy of object
     */
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }
    /**
     * Setter for lastUpdatedBy
     * @param lastUpdatedBy lastUpdatedBy
     */
    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }
    /**
     * Getter for customerId
     * @return customerId of object
     */
    public int getCustomerId() {
        return customerId;
    }
    /**
     * Setter for customerId
     * @param customerId customerId
     */
    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }
    /**
     * Getter for userId
     * @return userId of object
     */
    public int getUserId() {
        return userId;
    }
    /**
     * Setter for userId
     * @param userId userId
     */
    public void setUserId(int userId) {
        this.userId = userId;
    }
    /**
     * Getter for contactId
     * @return contactId of object
     */
    public int getContactId() {
        return contactId;
    }
    /**
     * Setter for contactId
     * @param contactId contactId
     */
    public void setContactId(int contactId) {
        this.contactId = contactId;
    }
}
