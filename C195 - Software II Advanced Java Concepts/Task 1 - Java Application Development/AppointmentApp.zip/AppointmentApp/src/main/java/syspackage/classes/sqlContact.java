package syspackage.classes;

/**
 * Class for object(s) 'sqlContact'. sqlContact objects are made as objects reflecting the 'contacts' table
 * in database.
 * @author Anthony Coots
 */
public class sqlContact {
    /**
     * contactId matching Contact_ID in table.
     */
    private int contactId;
    /**
     * contactName matching Contact_Name.
     */
    private String contactName;
    /**
     * email matching Email.
     */
    private String email;

    /**
     * Class constructor
     * @param contactId - Contact_ID
     * @param contactName - Contact_Name
     * @param email - Email
     */
    public sqlContact(int contactId, String contactName, String email) {
        this.contactId = contactId;
        this.contactName = contactName;
        this.email = email;
    }
    /**
     * Getter for contactId
     * @return contactId of object
     */
    public int getContactId() {
        return contactId;
    }
    /**
     * Setter for contactId
     * @param contactId contactId
     */
    public void setContactId(int contactId) {
        this.contactId = contactId;
    }
    /**
     * Getter for contactName
     * @return contactName of object
     */
    public String getContactName() {
        return contactName;
    }
    /**
     * Setter for contactName
     * @param contactName contactName
     */
    public void setContactName(String contactName) {
        this.contactName = contactName;
    }
    /**
     * Getter for email
     * @return email of object
     */
    public String getEmail() {
        return email;
    }
    /**
     * Setter for email
     * @param email email
     */
    public void setEmail(String email) {
        this.email = email;
    }
}
