package syspackage.dao;

import syspackage.appointmentapp.AppointmentsController;
import syspackage.appointmentapp.LoginController;
import syspackage.appointmentapp.ReportsController;
import syspackage.appointmentapp.TimeTranslation;
import syspackage.classes.*;

import java.sql.*;
import java.time.*;
import java.time.format.DateTimeFormatter;

/**
 * Class that contains SQL statements used for appointment application functionality.
 * @author Anthony Coots
 */
public class appointmentSQL {
    /**
     * Function that adds an appointment to the database.
     * @param connection JDBC connection
     * @param appointment sqlAppointment object.
     * @throws SQLException Thrown if query cannot execute properly.
     */
    public static void addAppointment(Connection connection, sqlAppointment appointment) throws SQLException {
        System.out.println(appointment.getStart() + " before add.");
        String query = "INSERT INTO appointments (Appointment_ID, Title, Description, Location, Type, Start, End, " +
                "Create_Date, Created_By, Last_Update, Last_Updated_By, Customer_ID, User_ID, Contact_ID) " +
                "VALUES (" + "'" + appointment.getAppointmentId() + "', "
                + "'" + appointment.getTitle() + "', "
                + "'" + appointment.getDescription() + "', "
                + "'" + appointment.getLocation() + "', "
                + "'" + appointment.getType() + "', "
                + "'" + appointment.getStart() + "', "
                + "'" + appointment.getEnd() + "', "
                + "'" + appointment.getCreateDate() + "', "
                + "'" + appointment.getCreatedBy() + "', "
                + "'" + appointment.getLastUpdate() + "', "
                + "'" + appointment.getLastUpdatedBy() + "', "
                + "'" + appointment.getCustomerId() + "', "
                + "'" + appointment.getUserId() + "', "
                + "'" + appointment.getContactId() + "')";

        System.out.println("*****************************************************************************************");
        System.out.println("Insert query set.");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate(query);
        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
    }
    /**
     * Function that lists appointments by contact (id).
     * @param connection JDBC connection
     * @param contactId Passed for to generate set for specific contact. Seen in reports.
     */
    public static void appointmentsByContact(Connection connection, int contactId) {
        System.out.println("*****************************************************************************************");
        System.out.println("Clearing current list of appointments in month if any present.");
        if(ReportsController.allAppointments.size() > 0) {
            ReportsController.allAppointments.clear();
        }
        System.out.println("*****************************************************************************************");

        String query = "SELECT * \nFROM client_schedule.appointments "
                     + "WHERE contact_id = '" + contactId + "' ";


        System.out.println("*****************************************************************************************");
        System.out.println("Query set. Selecting data from 'appointments' table matching the login user id.");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Entering try/catch sequence.");
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            System.out.println("*****************************************************************************************");
            System.out.println("Attempting query execution. ResultSet set to executeQuery call.");
            ResultSet resultSet = statement.executeQuery(query);
            System.out.println("*****************************************************************************************");

            while (resultSet.next()) {
                System.out.println("*****************************************************************************************");
                System.out.println("ResultSet mapping to new variables. Advancing row.");

                System.out.println("Variable: appointmentId - SQL column: 'Appointment_ID' at row.");
                int appointmentId = resultSet.getInt("Appointment_ID");

                System.out.println("Variable: title - SQL column: 'Title' at row.");
                String title = resultSet.getString("Title");

                System.out.println("Variable: description - SQL column: 'Description' at row.");
                String description = resultSet.getString("Description");

                System.out.println("Variable: location - SQL column: 'Location' at row.");
                String location = resultSet.getString("Location");

                System.out.println("Variable: type - SQL column: 'Type' at row.");
                String type = resultSet.getString("Type");

                System.out.println("Variable: start - SQL column: 'Start' at row.");
                LocalDateTime start = resultSet.getTimestamp("Start").toLocalDateTime();

                System.out.println("*****************************************************************************************");
                System.out.println("Converting database start datetime to local start datetime.");
                System.out.println("Local datetime: " + start);

                LocalTime dbStartTime = start.toLocalTime();
                System.out.println("Database start time: " + dbStartTime);

                LocalDate dbStartDate = start.toLocalDate();
                System.out.println("Database start date: " + dbStartDate);

                int dbStartTimeInSeconds = dbStartTime.toSecondOfDay();
                System.out.println("Database start time in seconds: " + dbStartTimeInSeconds);

                int timeDifference = (ZoneId.of(String.valueOf(ZoneId.systemDefault())).getRules().getOffset(Instant.now())).getTotalSeconds();
                System.out.println("Database to local time difference, in seconds: " + timeDifference);

                int localStartTimeInSeconds = dbStartTimeInSeconds + timeDifference;
                System.out.println("Local start time in seconds: " + localStartTimeInSeconds);

                LocalDate localStartDate = dbStartDate;

                System.out.print("Is local start time the day before? ");
                if(localStartTimeInSeconds < 0) {
                    System.out.println("Yes.");
                    localStartDate = dbStartDate.minusDays(1);
                    localStartTimeInSeconds += 86400;
                }
                else { System.out.println("No."); }

                System.out.print("Is local start time the day after? ");
                if(localStartTimeInSeconds >= 86400) {
                    System.out.println("Yes.");
                    localStartDate = dbStartDate.plusDays(1);
                    localStartTimeInSeconds -= 86400;
                }
                else { System.out.println("No."); }

                LocalTime localStartTime = LocalTime.ofSecondOfDay(localStartTimeInSeconds);

                System.out.println("Local date: " + dbStartDate);
                System.out.println("Local datetime: " + localStartDate + " " + localStartTime);

                System.out.println("Taking local datetime back to format.");
                start = LocalDateTime.of(localStartDate, localStartTime);
                System.out.println("Local datetime: " + start);

                System.out.println("*****************************************************************************************");

                System.out.println("Variable: end - SQL column: 'End' at row.");
                LocalDateTime end = resultSet.getTimestamp("End").toLocalDateTime();

                System.out.println("*****************************************************************************************");
                System.out.println("Converting database end datetime to local start datetime.");
                System.out.println("Local datetime: " + end);

                LocalTime dbEndTime = end.toLocalTime();
                System.out.println("Database end time: " + dbEndTime);

                LocalDate dbEndDate = end.toLocalDate();
                System.out.println("Database end date: " + dbEndDate);

                int dbEndTimeInSeconds = dbEndTime.toSecondOfDay();
                System.out.println("Database end time in seconds: " + dbEndTimeInSeconds);

                int localEndTimeInSeconds = dbEndTimeInSeconds + timeDifference;
                System.out.println("Local end time in seconds: " + localEndTimeInSeconds);

                LocalDate localEndDate = dbEndDate;

                System.out.print("Is local end time the day before? ");
                if(localEndTimeInSeconds < 0) {
                    System.out.println("Yes.");
                    localEndDate = dbEndDate.minusDays(1);
                    localEndTimeInSeconds += 86400;
                }
                else { System.out.println("No."); }

                System.out.print("Is local end time the day after? ");
                if(localEndTimeInSeconds >= 86400) {
                    System.out.println("Yes.");
                    localEndDate = dbEndDate.plusDays(1);
                    localEndTimeInSeconds -= 86400;
                }
                else { System.out.println("No."); }

                LocalTime localEndTime = LocalTime.ofSecondOfDay(localEndTimeInSeconds);

                System.out.println("Local date: " + dbEndDate);
                System.out.println("Local datetime: " + localEndDate + " " + localEndTime);

                System.out.println("Taking local datetime back to format.");
                end = LocalDateTime.of(localEndDate, localEndTime);
                System.out.println("Local datetime: " + end);

                System.out.println("*****************************************************************************************");

                System.out.println("Variable: createDate - SQL column: 'Create_date' at row.");
                LocalDateTime createDate = resultSet.getTimestamp("Create_date").toLocalDateTime();

                System.out.println("Variable: createdBy - SQL column: 'Created_By' at row.");
                String createdBy = resultSet.getString("Created_By");

                System.out.println("Variable: lastUpdate - SQL column: 'Last_Update' at row.");
                LocalDateTime lastUpdate = resultSet.getTimestamp("Last_Update").toLocalDateTime();

                System.out.println("Variable: lastUpdatedBy - SQL column: 'Last_Updated_By' at row.");
                String lastUpdatedBy = resultSet.getString("Last_Updated_By");

                System.out.println("Variable: customerId - SQL column: 'Customer_ID' at row.");
                int customerId = resultSet.getInt("Customer_ID");

                System.out.println("Variable: userId - SQL column: 'User_ID' at row.");
                int userId = resultSet.getInt("User_ID");

                System.out.println("Variable: contactId - SQL column: 'Contact_ID' at row.");
                contactId = resultSet.getInt("Contact_ID");

                System.out.println("Row obtained, setting to object of class 'sqlAppointment'");
                System.out.println("*****************************************************************************************");

                System.out.println("*****************************************************************************************");
                sqlAppointment appointment = new sqlAppointment(appointmentId, title, description, location, type, start,
                        end, createDate, createdBy, lastUpdate, lastUpdatedBy, customerId, userId, contactId);
                System.out.println("Object 'appointment' created. Object is a new object of class 'sqlAppointment'");
                System.out.println("*****************************************************************************************");

                System.out.println("*****************************************************************************************");
                System.out.println("Adding object to 'allAppointments' Observablelist.");
                ReportsController.allAppointments.add(appointment);
                System.out.println("Object added.");
                System.out.println("*****************************************************************************************");
            }
            System.out.println("*****************************************************************************************");
            System.out.println("Try successful. Proceeding in function call.");
            System.out.println("*****************************************************************************************");
            System.out.println("*****************************************************************************************");
            System.out.println("End of ResultSet.");
            System.out.println("*****************************************************************************************");

        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
    }
    /**
     * Function that lists appointments within the month.
     * @param connection JDBC connection
     */
    public static void appointmentsByMonth(Connection connection) {
        System.out.println("*****************************************************************************************");
        System.out.println("Clearing current list of appointments in month if any present.");
        if(AppointmentsController.allAppointmentsInMonth.size() > 0) {
            AppointmentsController.allAppointmentsInMonth.clear();
        }
        System.out.println("*****************************************************************************************");

        String queryMain  = "SELECT * \nFROM client_schedule.appointments \n";
        String queryWhere = "WHERE user_id = '" + LoginController.getCurrentUser().getUserId() + "' ";
        String queryAnd   = "AND start BETWEEN (SELECT DATE_SUB(CURDATE(), INTERVAL DAYOFMONTH(NOW())-1 DAY)) "
                + "AND (SELECT DATE_SUB(LAST_DAY(DATE_ADD(NOW(), INTERVAL 1 MONTH)), "
                + "INTERVAL DAY(LAST_DAY(DATE_ADD(NOW(), INTERVAL 1 MONTH)))-1 DAY))";
        String query = queryMain + queryWhere + queryAnd;

        System.out.println("*****************************************************************************************");
        System.out.println("Query set. Selecting data from 'appointments' table matching the login user id.");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Entering try/catch sequence.");
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            System.out.println("*****************************************************************************************");
            System.out.println("Attempting query execution. ResultSet set to executeQuery call.");
            ResultSet resultSet = statement.executeQuery(query);
            System.out.println("*****************************************************************************************");

            while (resultSet.next()) {
                System.out.println("*****************************************************************************************");
                System.out.println("ResultSet mapping to new variables. Advancing row.");

                System.out.println("Variable: appointmentId - SQL column: 'Appointment_ID' at row.");
                int appointmentId = resultSet.getInt("Appointment_ID");

                System.out.println("Variable: title - SQL column: 'Title' at row.");
                String title = resultSet.getString("Title");

                System.out.println("Variable: description - SQL column: 'Description' at row.");
                String description = resultSet.getString("Description");

                System.out.println("Variable: location - SQL column: 'Location' at row.");
                String location = resultSet.getString("Location");

                System.out.println("Variable: type - SQL column: 'Type' at row.");
                String type = resultSet.getString("Type");

                System.out.println("Variable: start - SQL column: 'Start' at row.");
                LocalDateTime start = resultSet.getTimestamp("Start").toLocalDateTime();
                System.out.println(start + " start.");

                System.out.println("Variable: end - SQL column: 'End' at row.");
                LocalDateTime end = resultSet.getTimestamp("End").toLocalDateTime();

                System.out.println("Variable: createDate - SQL column: 'Create_date' at row.");
                LocalDateTime createDate = resultSet.getTimestamp("Create_date").toLocalDateTime();

                System.out.println("Variable: createdBy - SQL column: 'Created_By' at row.");
                String createdBy = resultSet.getString("Created_By");

                System.out.println("Variable: lastUpdate - SQL column: 'Last_Update' at row.");
                LocalDateTime lastUpdate = resultSet.getTimestamp("Last_Update").toLocalDateTime();

                System.out.println("Variable: lastUpdatedBy - SQL column: 'Last_Updated_By' at row.");
                String lastUpdatedBy = resultSet.getString("Last_Updated_By");

                System.out.println("Variable: customerId - SQL column: 'Customer_ID' at row.");
                int customerId = resultSet.getInt("Customer_ID");

                System.out.println("Variable: userId - SQL column: 'User_ID' at row.");
                int userId = resultSet.getInt("User_ID");

                System.out.println("Variable: contactId - SQL column: 'Contact_ID' at row.");
                int contactId = resultSet.getInt("Contact_ID");

                System.out.println("Row obtained, setting to object of class 'sqlAppointment'");
                System.out.println("*****************************************************************************************");

                System.out.println("*****************************************************************************************");
                sqlAppointment appointment = new sqlAppointment(appointmentId, title, description, location, type, start,
                        end, createDate, createdBy, lastUpdate, lastUpdatedBy, customerId, userId, contactId);
                System.out.println("Object 'appointment' created. Object is a new object of class 'sqlAppointment'");
                System.out.println("*****************************************************************************************");

                System.out.println("*****************************************************************************************");
                System.out.println("Adding object to 'allAppointmentsInMonth' Observablelist in sqlAppointment class...");
                AppointmentsController.addAppointment(AppointmentsController.getMonthList(), appointment);
                System.out.println("Object added.");
                System.out.println("*****************************************************************************************");

                System.out.println("*****************************************************************************************");
                System.out.println("List of appointments 'allAppointmentsInMonth': " + AppointmentsController.getMonthList());
                System.out.println("Items in 'allAppointmentsInMonth': " + AppointmentsController.allAppointmentsInMonth.size());
                System.out.println("*****************************************************************************************");
            }
            System.out.println("*****************************************************************************************");
            System.out.println("Try successful. Proceeding in function call.");
            System.out.println("*****************************************************************************************");
            System.out.println("*****************************************************************************************");
            System.out.println("End of ResultSet.");
            System.out.println("*****************************************************************************************");

        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
    }
    /**
     * Function that lists appointments within the week.
     * @param connection JDBC connection
     */
    public static void appointmentsByWeek(Connection connection) {
        System.out.println("*****************************************************************************************");
        System.out.println("Clearing current list of appointments in week if any present.");
        if(AppointmentsController.allAppointmentsInWeek.size() > 0) {
            AppointmentsController.allAppointmentsInWeek.clear();
        }
        System.out.println("*****************************************************************************************");

        String queryMain = "SELECT * \nFROM client_schedule.appointments \n";
        String queryWhere = "WHERE user_id = '" + LoginController.getCurrentUser().getUserId() + "' ";
        String queryAnd = "AND start BETWEEN (SELECT DATE_SUB(CURDATE(), INTERVAL DAYOFWEEK(NOW())-1 DAY)) AND (SELECT DATE(NOW() + INTERVAL (8 - DAYOFWEEK(NOW())) DAY))";
        String query = queryMain + queryWhere + queryAnd;

        System.out.println("*****************************************************************************************");
        System.out.println("Query set. Selecting data from 'appointments' table matching the login user id.");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Entering try/catch sequence.");
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            System.out.println("*****************************************************************************************");
            System.out.println("Attempting query execution. ResultSet set to executeQuery call.");
            ResultSet resultSet = statement.executeQuery(query);
            System.out.println("*****************************************************************************************");

            while (resultSet.next()) {
                System.out.println("*****************************************************************************************");
                System.out.println("ResultSet mapping to new variables. Advancing row.");

                System.out.println("Variable: appointmentId - SQL column: 'Appointment_ID' at row.");
                int appointmentId = resultSet.getInt("Appointment_ID");

                System.out.println("Variable: title - SQL column: 'Title' at row.");
                String title = resultSet.getString("Title");

                System.out.println("Variable: description - SQL column: 'Description' at row.");
                String description = resultSet.getString("Description");

                System.out.println("Variable: location - SQL column: 'Location' at row.");
                String location = resultSet.getString("Location");

                System.out.println("Variable: type - SQL column: 'Type' at row.");
                String type = resultSet.getString("Type");

                System.out.println("Variable: start - SQL column: 'Start' at row.");
                LocalDateTime start = resultSet.getTimestamp("Start").toLocalDateTime();
                System.out.println("From resultSet: " + start);

                System.out.println("*****************************************************************************************");
                Timestamp startInputTimeStamp = Timestamp.valueOf(start);
                System.out.println("Timestamp startInputTimeStamp set to: " + startInputTimeStamp);
                System.out.println("*****************************************************************************************");

                System.out.println("*****************************************************************************************");
                String fieldInLocal = TimeTranslation.utcToLocal(String.valueOf(startInputTimeStamp));
                System.out.println("String fieldInLocal set to: " + fieldInLocal);
                System.out.println("*****************************************************************************************");

                start = LocalDateTime.parse(fieldInLocal, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
                System.out.println("Post declaration: " + start);

                System.out.println("Variable: end - SQL column: 'End' at row.");
                LocalDateTime end = resultSet.getTimestamp("End").toLocalDateTime();

                System.out.println("*****************************************************************************************");
                Timestamp endInputTimeStamp = Timestamp.valueOf(end);
                System.out.println("Timestamp endInputTimeStamp set to: " + endInputTimeStamp);
                System.out.println("*****************************************************************************************");

                System.out.println("*****************************************************************************************");
                fieldInLocal = TimeTranslation.utcToLocal(String.valueOf(startInputTimeStamp));
                System.out.println("String fieldInLocal set to: " + fieldInLocal);
                System.out.println("*****************************************************************************************");

                end = LocalDateTime.parse(fieldInLocal, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
                System.out.println("Variable: createDateDb - SQL column: 'Create_date' at row.");
                LocalDateTime createDateDb = resultSet.getTimestamp("Create_date").toLocalDateTime();

                System.out.println("Variable: createdBy - SQL column: 'Created_By' at row.");
                String createdBy = resultSet.getString("Created_By");

                System.out.println("Variable: lastUpdate - SQL column: 'Last_Update' at row.");
                LocalDateTime lastUpdate = resultSet.getTimestamp("Last_Update").toLocalDateTime();

                System.out.println("Variable: lastUpdatedBy - SQL column: 'Last_Updated_By' at row.");
                String lastUpdatedBy = resultSet.getString("Last_Updated_By");

                System.out.println("Variable: customerId - SQL column: 'Customer_ID' at row.");
                int customerId = resultSet.getInt("Customer_ID");

                System.out.println("Variable: userId - SQL column: 'User_ID' at row.");
                int userId = resultSet.getInt("User_ID");

                System.out.println("Variable: contactId - SQL column: 'Contact_ID' at row.");
                int contactId = resultSet.getInt("Contact_ID");

                System.out.println("Row obtained, setting to object of class 'sqlAppointment'");
                System.out.println("*****************************************************************************************");

                System.out.println("*****************************************************************************************");
                sqlAppointment appointment = new sqlAppointment(appointmentId, title, description, location, type, start,
                        end, createDateDb, createdBy, lastUpdate, lastUpdatedBy, customerId, userId, contactId);
                System.out.println("Appointment start/end: " + start + "/" + end);
                System.out.println("Object 'appointment' created. Object is a new object of class 'sqlAppointment'");
                System.out.println("*****************************************************************************************");

                System.out.println("*****************************************************************************************");
                System.out.println("Adding object to 'allAppointmentsInWeek' Observablelist in sqlAppointment class...");
                AppointmentsController.addAppointment(AppointmentsController.getWeekList(), appointment);
                System.out.println("Object added.");
                System.out.println("*****************************************************************************************");

                System.out.println("*****************************************************************************************");
                System.out.println("List of appointments 'allAppointmentsInWeek': " + AppointmentsController.getWeekList());
                System.out.println("Items in 'allAppointmentsInWeek': " + AppointmentsController.allAppointmentsInWeek.size());
                System.out.println("*****************************************************************************************");

                System.out.println("*****************************************************************************************");
                System.out.println("Try successful. Proceeding in function call.");
                System.out.println("*****************************************************************************************");
            }
            System.out.println("*****************************************************************************************");
            System.out.println("End of ResultSet.");
            System.out.println("*****************************************************************************************");

        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("****************************************************");
        }
    }
    /**
     * Function that generates list of appointments within 15 minutes of current time converted to UTC.
     * @param connection JDBC connection
     */
    public static void checkForAppointments(Connection connection) {
        String query = "SELECT * "
                     + "FROM client_schedule.appointments "
                     + "WHERE user_id = " + LoginController.getCurrentUser().getUserId()
                     + " AND Start BETWEEN UTC_TIMESTAMP AND UTC_TIMESTAMP + INTERVAL 15 minute ";

        System.out.println("*****************************************************************************************");
        System.out.println("Query set. Selecting data from 'appointments' table.");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            System.out.println("*****************************************************************************************");
            System.out.println("Attempting query execution. ResultSet set to executeQuery call.");
            ResultSet resultSet = statement.executeQuery(query);
            System.out.println("*****************************************************************************************");

            while (resultSet.next()) {
                System.out.println("*****************************************************************************************");
                System.out.println("ResultSet mapping to new variables. Advancing row.");

                System.out.println("Variable: appointmentId - SQL column: 'Appointment_ID' at row.");
                int appointmentId = resultSet.getInt("Appointment_ID");

                System.out.println("Variable: title - SQL column: 'Title' at row.");
                String title = resultSet.getString("Title");

                System.out.println("Variable: description - SQL column: 'Description' at row.");
                String description = resultSet.getString("Description");

                System.out.println("Variable: location - SQL column: 'Location' at row.");
                String location = resultSet.getString("Location");

                System.out.println("Variable: type - SQL column: 'Type' at row.");
                String type = resultSet.getString("Type");

                System.out.println("Variable: start - SQL column: 'Start' at row.");
                LocalDateTime start = resultSet.getTimestamp("Start").toLocalDateTime();

                System.out.println("Variable: end - SQL column: 'End' at row.");
                LocalDateTime end = resultSet.getTimestamp("End").toLocalDateTime();

                System.out.println("*****************************************************************************************");

                System.out.println("Variable: createDate - SQL column: 'Create_date' at row.");
                LocalDateTime createDate = resultSet.getTimestamp("Create_date").toLocalDateTime();

                System.out.println("Variable: createdBy - SQL column: 'Created_By' at row.");
                String createdBy = resultSet.getString("Created_By");

                System.out.println("Variable: lastUpdate - SQL column: 'Last_Update' at row.");
                LocalDateTime lastUpdate = resultSet.getTimestamp("Last_Update").toLocalDateTime();

                System.out.println("Variable: lastUpdatedBy - SQL column: 'Last_Updated_By' at row.");
                String lastUpdatedBy = resultSet.getString("Last_Updated_By");

                System.out.println("Variable: customerId - SQL column: 'Customer_ID' at row.");
                int customerId = resultSet.getInt("Customer_ID");

                System.out.println("Variable: userId - SQL column: 'User_ID' at row.");
                int userId = resultSet.getInt("User_ID");

                System.out.println("Variable: contactId - SQL column: 'Contact_ID' at row.");
                int contactId = resultSet.getInt("Contact_ID");

                System.out.println("Row obtained, setting to object of class 'sqlAppointment'");
                System.out.println("*****************************************************************************************");

                System.out.println("*****************************************************************************************");
                sqlAppointment appointment = new sqlAppointment(appointmentId, title, description, location, type, start,
                        end, createDate, createdBy, lastUpdate, lastUpdatedBy, customerId, userId, contactId);
                System.out.println("Object 'appointment' created. Object is a new object of class 'sqlAppointment'");
                System.out.println("*****************************************************************************************");

                System.out.println("*****************************************************************************************");
                System.out.println("Adding object to 'allAppointmentsInMonth' Observablelist in sqlAppointment class...");
                AppointmentsController.addAppointment(AppointmentsController.getMonthList(), appointment);
                System.out.println("Object added.");
                System.out.println("*****************************************************************************************");

                System.out.println("*****************************************************************************************");
                System.out.println("List of appointments 'allAppointmentsInMonth': " + AppointmentsController.getMonthList());
                System.out.println("Items in 'allAppointmentsInMonth': " + AppointmentsController.allAppointmentsInMonth.size());
                System.out.println("*****************************************************************************************");
            }
            System.out.println("*****************************************************************************************");
            System.out.println("Try successful. Proceeding in function call.");
            System.out.println("*****************************************************************************************");
            System.out.println("*****************************************************************************************");
            System.out.println("End of ResultSet.");
            System.out.println("*****************************************************************************************");

        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
    }
    /**
     * Function that returns a contact id from contact name (String).
     * @param connection JDBC connection
     * @param contact Name of country
     * @return Contact ID returned
     */
    public static int contactIdFromContactName(Connection connection, String contact) {
        String query = "SELECT contact_id FROM client_schedule.contacts WHERE contact_name = '" + contact + "'";

        System.out.println("*****************************************************************************************");
        System.out.println("Query set. Selecting data from 'contacts' table.");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            System.out.println("*****************************************************************************************");
            System.out.println("Attempting query execution. ResultSet set to executeQuery call.");
            System.out.println("*****************************************************************************************");
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                System.out.println("*****************************************************************************************");
                System.out.println("ResultSet mapping to new variables. Advancing row.");
                System.out.println("*****************************************************************************************");

                System.out.println("Contact ID found, returning.");
                return resultSet.getInt("contact_id");
            }
        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
        return 0;
    }
    /**
     * Function that lists contacts for combo boxes.
     * @param connection JDBC connection
     * @throws SQLException Thrown if query cannot execute properly.
     */
    public static void contacts(Connection connection) throws SQLException {

        System.out.println("*****************************************************************************************");
        System.out.println("Clearing current list of contacts if any present.");
        if (AppointmentsController.allContacts.size() > 0) {
            AppointmentsController.allContacts.clear();
        }
        System.out.println("*****************************************************************************************");

        String query = "SELECT * FROM client_schedule.contacts";

        System.out.println("*****************************************************************************************");
        System.out.println("Query set. Selecting data from 'contacts'.");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Entering try/catch sequence.");
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            System.out.println("*****************************************************************************************");
            System.out.println("Attempting query execution. ResultSet set to executeQuery call.");
            ResultSet resultSet = statement.executeQuery(query);
            System.out.println("*****************************************************************************************");

            while (resultSet.next()) {
                System.out.println("*****************************************************************************************");
                System.out.println("ResultSet mapping to new variables. Advancing row.");

                System.out.println("Variable: contactId - SQL column: 'Contact_ID' at row.");
                int contactId = resultSet.getInt("contact_id");

                System.out.println("Variable: contactName - SQL column: 'Contact_Name' at row.");
                String contactName = resultSet.getString("contact_name");

                System.out.println("Variable: contactEmail - SQL column: 'Email' at row.");
                String contactEmail = resultSet.getString("email");

                System.out.println("Row obtained, setting to object of class 'sqlContact'");
                System.out.println("*****************************************************************************************");

                sqlContact sqlContactObj = new sqlContact(contactId, contactName, contactEmail);
                AppointmentsController.allContacts.add(sqlContactObj);
                System.out.println("Object 'contact' created. Object is a new object of class 'sqlContact'.");
                System.out.println("*****************************************************************************************");
            }
            System.out.println("*****************************************************************************************");
            System.out.println("Try successful. Proceeding in function call.");
            System.out.println("*****************************************************************************************");
            System.out.println("*****************************************************************************************");
            System.out.println("End of ResultSet.");
            System.out.println("*****************************************************************************************");
        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
    }
    /**
     * Function that lists customers for combo boxes.
     * @param connection JDBC connection
     * @throws SQLException Thrown if query cannot execute properly.
     */
    public static void customers(Connection connection) throws SQLException {

        System.out.println("*****************************************************************************************");
        System.out.println("Clearing current list of customers if any present.");
        if (AppointmentsController.allCustomers.size() > 0) {
            AppointmentsController.allCustomers.clear();
        }
        System.out.println("*****************************************************************************************");

        String query = "SELECT * FROM client_schedule.customers";

        System.out.println("*****************************************************************************************");
        System.out.println("Query set. Selecting data from 'customers' table.");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Entering try/catch sequence.");
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            System.out.println("*****************************************************************************************");
            System.out.println("Attempting query execution. ResultSet set to executeQuery call.");
            ResultSet resultSet = statement.executeQuery(query);
            System.out.println("*****************************************************************************************");

            while (resultSet.next()) {
                System.out.println("*****************************************************************************************");
                System.out.println("ResultSet mapping to new variables. Advancing row.");

                System.out.println("Variable: customerId - SQL column: 'Customer_ID' at row.");
                int customerId = resultSet.getInt("customer_id");

                System.out.println("Variable: customerName - SQL column: 'Customer_Name' at row.");
                String customerName = resultSet.getString("Customer_Name");

                System.out.println("Variable: customerAddress - SQL column: 'Address' at row.");
                String customerAddress = resultSet.getString("Address");

                System.out.println("Variable: customerPostal - SQL column: 'Postal_Code' at row.");
                String customerPostal = resultSet.getString("Postal_Code");

                System.out.println("Variable: customerPhone - SQL column: 'Phone' at row.");
                String customerPhone = resultSet.getString("Phone");

                System.out.println("Variable: createDate - SQL column: 'Create_Date' at row.");
                LocalDateTime createDate = resultSet.getTimestamp("Create_Date").toLocalDateTime();

                System.out.println("Variable: createDate - SQL column: 'Created_By' at row.");
                String createdBy = resultSet.getString("Created_By");

                System.out.println("Variable: lastUpdate - SQL column: 'Last_Update' at row.");
                LocalDateTime lastUpdate = resultSet.getTimestamp("Last_Update").toLocalDateTime();

                System.out.println("Variable: lastUpdatedBy - SQL column: 'Last_Updated_By' at row.");
                String lastUpdatedBy = resultSet.getString("Last_Updated_By");

                System.out.println("Variable: divisionId - SQL column: 'Division_ID' at row.");
                int divisionId = resultSet.getInt("Division_ID");


                System.out.println("Row obtained, setting to object of class 'sqlCustomer'");
                System.out.println("*****************************************************************************************");

                sqlCustomer sqlCustomerObj = new sqlCustomer(customerId, customerName, customerAddress, customerPostal,
                        customerPhone, createDate, createdBy, lastUpdate, lastUpdatedBy, divisionId);
                AppointmentsController.allCustomers.add(sqlCustomerObj);
                System.out.println("Object 'customer' created. Object is a new object of class 'sqlCustomer'.");
                System.out.println("*****************************************************************************************");
            }
            System.out.println("*****************************************************************************************");
            System.out.println("Try successful. Proceeding in function call.");
            System.out.println("*****************************************************************************************");
            System.out.println("*****************************************************************************************");
            System.out.println("End of ResultSet.");
            System.out.println("*****************************************************************************************");
        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
    }
    /**
     * Function that deletes a selected appointment from database.
     * @param connection JDBC connection
     * @param appointment Appointment to be deleted.
     * @throws SQLException Thrown if query cannot execute properly.
     */
    public static void deleteSelected(Connection connection, sqlAppointment appointment) throws SQLException {
        sqlAppointment parallelAppointmentToRemove = null;

        for (sqlAppointment checkApp : AppointmentsController.allAppointmentsInWeek) {
            if(checkApp.getAppointmentId() == appointment.getAppointmentId()) {
                parallelAppointmentToRemove = checkApp;
            }
        }
        for (sqlAppointment checkApp : AppointmentsController.allAppointmentsInMonth) {
            if(checkApp.getAppointmentId() == appointment.getAppointmentId()) {
                parallelAppointmentToRemove = checkApp;
            }
        }

        System.out.println("*****************************************************************************************");
        System.out.println("Appointment selected for delete: " + appointment);
        int appListId = appointment.getAppointmentId();
        System.out.println("Appointment id: " + appListId);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        String query = "DELETE FROM client_schedule.appointments \nWHERE appointment_id = '" + appListId + "'\n";
        System.out.println("Query built, deleting appointment " + appointment.getAppointmentId() + " from database.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Query:");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        if(AppointmentsController.allAppointmentsInMonth.contains(parallelAppointmentToRemove)) {
            System.out.println("*****************************************************************************************");
            System.out.println(AppointmentsController.allAppointmentsInMonth);
            System.out.println("'allAppointmentsInMonth contains object with similar ID: " + parallelAppointmentToRemove);
            System.out.println("Removing this appointment.");
            AppointmentsController.allAppointmentsInMonth.remove(parallelAppointmentToRemove);
            System.out.println("Appointment removed from both lists in AppointmentController.");
            System.out.println("'allAppointmentsInMonth': " + AppointmentsController.allAppointmentsInMonth);
            System.out.println("*****************************************************************************************");
        }

        // different objects are made for each list, need to search for object by appointment id, remove individually.


        if(AppointmentsController.allAppointmentsInWeek.contains(parallelAppointmentToRemove)) {
            System.out.println("*****************************************************************************************");
            System.out.println(AppointmentsController.allAppointmentsInWeek);
            System.out.println("'allAppointmentsInWeek contains object with similar ID: " + parallelAppointmentToRemove);
            System.out.println("Removing this appointment.");
            AppointmentsController.allAppointmentsInWeek.remove(parallelAppointmentToRemove);
            System.out.println("Appointment removed from both lists in AppointmentController.");
            System.out.println("'allAppointmentsInWeek': " + AppointmentsController.allAppointmentsInWeek);
            System.out.println("*****************************************************************************************");
        }


        System.out.println("*****************************************************************************************");
        System.out.println("Entering try/catch sequence.");
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            System.out.println("*****************************************************************************************");
            System.out.println("Attempting query execution. Updating database to remove appointment.");
            statement.executeUpdate(query);
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            System.out.println("Appointment with ID " + appointment.getAppointmentId() + " deleted from database.");
            System.out.println("*****************************************************************************************");
        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("****************************************************");
        }
    }
    /**
     * Function that lists locations for combo boxes.
     * @param connection JDBC connection
     * @throws SQLException Thrown if query cannot execute properly.
     */
    public static void locations(Connection connection) throws SQLException {

        System.out.println("*****************************************************************************************");
        System.out.println("Clearing current list of locations if any present.");
        if (AppointmentsController.allLocations.size() > 0) {
            AppointmentsController.allLocations.clear();
        }
        System.out.println("*****************************************************************************************");

        String query = "SELECT csc.country_ID, cfl.Division_ID, CONCAT(cfl.Division, \", \", csc.country) AS Location "
                + "FROM client_schedule.countries csc INNER JOIN client_schedule.first_level_divisions cfl "
                + "ON csc.country_ID = cfl.country_ID";

        System.out.println("*****************************************************************************************");
        System.out.println("Query set. Selecting data from 'appointments' table matching the login user id.");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Entering try/catch sequence.");
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            System.out.println("*****************************************************************************************");
            System.out.println("Attempting query execution. ResultSet set to executeQuery call.");
            ResultSet resultSet = statement.executeQuery(query);
            System.out.println("*****************************************************************************************");

            while (resultSet.next()) {
                System.out.println("*****************************************************************************************");
                System.out.println("ResultSet mapping to new variables. Advancing row.");

                System.out.println("Variable: countryId - SQL column: 'country_id' at row.");
                int countryId = resultSet.getInt("country_id");

                System.out.println("Variable: divisionId - SQL column: 'division_id' at row.");
                int divisionId = resultSet.getInt("division_id");

                System.out.println("Variable: location - SQL column: 'location' at row.");
                String location = resultSet.getString("location");

                System.out.println("Row obtained, setting to object of class 'sqlLocation'");
                System.out.println("*****************************************************************************************");

                sqlLocation sqlLocationObj = new sqlLocation(countryId, divisionId, location);
                AppointmentsController.allLocations.add(sqlLocationObj);
                System.out.println("Object 'location' created. Object is a new object of class 'sqlLocation'.");
                System.out.println("*****************************************************************************************");
            }
            System.out.println("*****************************************************************************************");
            System.out.println("Try successful. Proceeding in function call.");
            System.out.println("*****************************************************************************************");
            System.out.println("*****************************************************************************************");
            System.out.println("End of ResultSet.");
            System.out.println("*****************************************************************************************");
        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
    }
    /**
     * Function that generates the next available appointment id for auto generation.
     * @param connection JDBC connection
     * @return appointmentId to be used.
     */
    public static int nextAvailableAppId(Connection connection) {
        System.out.println("*****************************************************************************************");
        System.out.println("Creating query to select next available appointment ID based on existing appointments");
        System.out.println("*****************************************************************************************");

        String query = """
                SELECT app.appointment_id + 1 AS genAppointmentId\s
                FROM client_schedule.appointments app LEFT JOIN client_schedule.appointments app1 ON app1.appointment_id = app.appointment_id + 1
                WHERE app1.appointment_id IS NULL
                ORDER BY app.appointment_id
                LIMIT 0, 1""";

        System.out.println("*****************************************************************************************");
        System.out.println("Query set. Selecting data from 'appointments' table matching the login user id.");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Entering try/catch sequence.");
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            System.out.println("*****************************************************************************************");
            System.out.println("Attempting query execution. ResultSet set to executeQuery call.");
            ResultSet resultSet = statement.executeQuery(query);
            System.out.println("*****************************************************************************************");

            while (resultSet.next()) {
                System.out.println("*****************************************************************************************");
                System.out.println("ResultSet mapping to new variables. Advancing row.");

                System.out.println("Variable: appointmentId - SQL column: 'genAppointmentId' at row.");
                int appointmentId = resultSet.getInt("genAppointmentId");
                System.out.println("*****************************************************************************************");

                System.out.println("*****************************************************************************************");
                System.out.println("Try successful. Proceeding in function call.");
                System.out.println("*****************************************************************************************");
                return appointmentId;
            }
            System.out.println("*****************************************************************************************");
            System.out.println("End of ResultSet.");
            System.out.println("*****************************************************************************************");


        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
        return 0;
    }
    /**
     * Function that returns contact name from contact ID.
     * @param connection JDBC connection
     * @param contactId contact ID to return name.
     * @return returns contact name.
     */
    public static String returnContactName(Connection connection, int contactId) {
        System.out.println("\n****************************************************");
        System.out.println("Attempting to view MySQL table 'contacts'...");
        System.out.println("\nQuery:\n");

        String query = "SELECT contact_name FROM client_schedule.contacts WHERE contact_id = '" + contactId + "'";

        System.out.println(query);
        System.out.println("\nComparing result set...");
        System.out.print("Result: ");

        try (Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                return resultSet.getString("contact_name");
            }
        } catch (SQLException e) {
            System.out.println("Failed to run statement.");
            System.out.println("****************************************************");
            System.out.println(e.getMessage());
        }
        return null;
    }
    /**
     * Function that checks for a time conflict ADDING an appointment.
     * @param connection JDBC connection
     * @param start start of appointment.
     * @param end end of appointment.
     * @param userId compares the current logged-in user's schedule.
     * @return amount of conflicting appointments.
     */
    public static int timeConflict(Connection connection, LocalDateTime start, LocalDateTime end, int userId) {
        String query = "SELECT IF(COUNT(*) > 0, 1, 0) AS returnVal FROM client_schedule.appointments "
                + "WHERE user_id = " + userId + " AND start <= '" + end + "' AND '" + start + "' <= end";

        System.out.println("*****************************************************************************************");
        System.out.println("Query set. Selecting data from 'appointments' table.");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                return resultSet.getInt("returnVal");
            }
        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
        return 0;
    }
    /**
     * Function that checks for a time conflict UPDATING an appointment.
     * @param connection JDBC connection
     * @param startTime start of appointment.
     * @param endTime end of appointment.
     * @param userId compares the current logged-in user's schedule.
     * @param appointmentId where appointments are not the current one.
     * @return amount of conflicting appointments.
     */
    public static int timeConflict(Connection connection, LocalDateTime startTime, LocalDateTime endTime, int userId, int appointmentId) {
        System.out.println("\n****************************************************");
        System.out.println("Attempting to insert into 'Appointments' table...");
        System.out.println("\nQuery:\n");

        String query = "SELECT IF(COUNT(*) > 0, 1, 0) AS returnVal FROM client_schedule.appointments "
                + "WHERE user_id = " + userId + " AND start <= '" + endTime + "' AND '" + startTime + "' <= end AND appointment_id != " + appointmentId;

        System.out.println(query);
        System.out.println("\nComparing result set...");
        System.out.print("Result: ");

        try (Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery(query);
            while(resultSet.next()) {
                return resultSet.getInt("returnVal");
            }
        }
        catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
        return 0;
    }

    /**
     * Function that updates an appointment in the database.
     * @param connection JDBC connection
     * @param appointmentId - Appointment_ID
     * @param title - Title
     * @param description - Description
     * @param location - Location
     * @param contact - Contact_ID
     * @param type - Type
     * @param start - Start
     * @param end - End
     * @param lastUpdate - Last_Update
     * @param customerId - Customer_ID
     * @param userId - User_ID
     * @throws SQLException Thrown if query cannot execute properly.
     */
    public static void updateAppointment(Connection connection, int appointmentId, String title, String description, String location,
                                         int contact, String type, LocalDateTime start, LocalDateTime end, LocalDateTime lastUpdate,
                                         int customerId, int userId) throws SQLException {
        System.out.println("\n****************************************************");
        System.out.println("Attempting to update 'Appointments' table...");
        System.out.println("\nQuery:\n");

        String query = "UPDATE appointments SET "
                + "Title = '" + title + "', "
                + "Description = '" + description + "', "
                + "Location = '" + location + "', "
                + "Type = '" + type + "', "
                + "Start = '" + start + "', "
                + "End = '" + end + "', "
                + "Last_Update = '" + lastUpdate + "', "
                + "Last_Updated_By = '" + LoginController.getCurrentUser().getUsername() + "', "
                + "customer_id = '" + customerId + "', "
                + "user_id = '" + userId + "', "
                + "contact_id = '" + contact + "' "
                + "WHERE Appointment_ID = '" + appointmentId + "'";


        System.out.println(query);
        System.out.println("\nComparing result set...");
        System.out.print("Result: ");

        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate(query);
        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
    }

    /**
     * Function that lists users for combo boxes.
     * @param connection JDBC connection
     * @throws SQLException Thrown if query cannot execute properly.
     */
    public static void users(Connection connection) throws SQLException {

        System.out.println("*****************************************************************************************");
        System.out.println("Clearing current list of users if any present.");
        if (AppointmentsController.allUsers.size() > 0) {
            AppointmentsController.allUsers.clear();
        }
        System.out.println("*****************************************************************************************");

        String query = "SELECT * FROM client_schedule.users ORDER BY user_id";

        System.out.println("*****************************************************************************************");
        System.out.println("Query set. Selecting data from 'users' table.");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Entering try/catch sequence.");
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            System.out.println("*****************************************************************************************");
            System.out.println("Attempting query execution. ResultSet set to executeQuery call.");
            ResultSet resultSet = statement.executeQuery(query);
            System.out.println("*****************************************************************************************");

            while (resultSet.next()) {
                System.out.println("*****************************************************************************************");
                System.out.println("ResultSet mapping to new variables. Advancing row.");

                System.out.println("Variable: userId - SQL column: 'User_ID' at row.");
                int userId = resultSet.getInt("User_ID");

                System.out.println("Variable: username - SQL column: 'User_Name' at row.");
                String username = resultSet.getString("User_Name");

                System.out.println("Variable: password - SQL column: 'Password' at row.");
                String password = resultSet.getString("Password");

                System.out.println("Variable: createDate - SQL column: 'Create_Date' at row.");
                LocalDateTime createDate = resultSet.getTimestamp("Create_Date").toLocalDateTime();

                System.out.println("Variable: createdBy - SQL column: 'Created_By' at row.");
                String createdBy = resultSet.getString("Created_By");

                System.out.println("Variable: lastUpdate - SQL column: 'Last_Update' at row.");
                LocalDateTime lastUpdate = resultSet.getTimestamp("Last_Update").toLocalDateTime();

                System.out.println("Variable: lastUpdatedBy - SQL column: 'Last_Updated_By' at row.");
                String lastUpdatedBy = resultSet.getString("Last_Updated_By");

                System.out.println("Row obtained, setting to object of class 'sqlUser'");
                System.out.println("*****************************************************************************************");

                sqlUser sqlUserObj = new sqlUser(userId, username, password, createDate, createdBy, lastUpdate, lastUpdatedBy);
                AppointmentsController.allUsers.add(sqlUserObj);
                System.out.println("Object 'user' created. Object is a new object of class 'sqlUser'.");
                System.out.println("*****************************************************************************************");
            }
            System.out.println("*****************************************************************************************");
            System.out.println("Try successful. Proceeding in function call.");
            System.out.println("*****************************************************************************************");
            System.out.println("*****************************************************************************************");
            System.out.println("End of ResultSet.");
            System.out.println("*****************************************************************************************");
        } catch (SQLException e) {
            System.out.println("*****************************************************************************************");
            System.out.println("In try/catch, caught: ");
            System.out.println(e.getMessage());
            System.out.println("*****************************************************************************************");
        }
    }
}
