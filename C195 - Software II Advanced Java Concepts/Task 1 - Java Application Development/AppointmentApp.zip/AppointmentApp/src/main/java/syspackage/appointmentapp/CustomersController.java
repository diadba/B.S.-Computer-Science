package syspackage.appointmentapp;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.Window;
import syspackage.classes.*;
import syspackage.dao.customerSQL;
import syspackage.helper.JDBC;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Class that controls the logic for the scene that views customers, and adds updates and deletes customers.
 * @author Anthony Coots
 */
public class CustomersController implements Initializable {
    /**
     * FXML variable table view for display of all customers.
     */
    @FXML
    private TableView<sqlCustomer> customerTableView;
    /**
     * FXML variable table column for column in customer view that holds customer IDs.
     */
    @FXML
    private TableColumn<sqlCustomer, Integer> customerIdColumn;
    /**
     * FXML variable table column for column in customer view that holds customer names.
     */
    @FXML
    private TableColumn<sqlCustomer, String> customerNameColumn;
    /**
     * FXML variable table column for column in customer view that holds customer addresses.
     */
    @FXML
    private TableColumn<sqlCustomer, String> customerAddressColumn;
    /**
     * FXML variable table column for column in customer view that holds customer postal codes.
     */
    @FXML
    private TableColumn<sqlCustomer, String> customerPostalCodeColumn;
    /**
     * FXML variable table column for column in customer view that holds customer phone.
     */
    @FXML
    private TableColumn<sqlCustomer, String> customerPhoneColumn;
    /**
     * FXML variable table column for column in customer view that holds customer division IDs.
     */
    @FXML
    private TableColumn<sqlCustomer, Integer> customerDivisionIdColumn;
    /**
     * Variable of class 'sqlCustomer' to declare current customer.
     */
    private static sqlCustomer currentCustomer;
    /**
     * List made for all countries.
     */
    public static ObservableList<sqlCountry> allCountries = FXCollections.observableArrayList();
    /**
     * List made for all divisions.
     */
    public static ObservableList<sqlDivision> allDivisions = FXCollections.observableArrayList();
    /**
     * List made for all customers.
     */
    public static ObservableList<sqlCustomer> allCustomers = FXCollections.observableArrayList();

    /**
     * Function that initializes the customer scene.
     * @param url path location.
     * @param resourceBundle source through resources.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        System.out.println("*****************************************************************************************");
        System.out.println("*****************************************************************************************");
        System.out.println("Initializing CustomersController.");
        System.out.println("*****************************************************************************************");
        System.out.println("*****************************************************************************************");
        System.out.println();

        setCustomerTableView();
    }
    /**
     * Function that sets the customer table view.
     */
    private void setCustomerTableView() {
        System.out.println("*****************************************************************************************");
        System.out.println("Calling listCustomers function, producing list of all customers.");
        customerSQL.listCustomers(JDBC.connection);
        System.out.println("All customer objects: " + allCustomers);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Setting customer table view.");
        System.out.println("*****************************************************************************************");

        for (sqlCustomer customer : allCustomers) {
            currentCustomer = customer;

            String customerDivisionConcat = customerSQL.divisionNameFromDivisionId(JDBC.connection, currentCustomer.getDivisionId()).trim();
            String customerCountryConcat = customerSQL.countryNameFromDivisionId(JDBC.connection, currentCustomer.getDivisionId()).trim();
            String customerAddress = currentCustomer.getCustomerAddress().trim() + ", " + customerDivisionConcat + ", " + customerCountryConcat;

            currentCustomer.setFullAddress(customerAddress);
        }

        customerTableView.setItems(CustomersController.allCustomers);
        customerIdColumn.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        customerNameColumn.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        customerAddressColumn.setCellValueFactory(new PropertyValueFactory<>("fullAddress"));
        customerPostalCodeColumn.setCellValueFactory(new PropertyValueFactory<>("customerPostal"));
        customerPhoneColumn.setCellValueFactory(new PropertyValueFactory<>("customerPhone"));
        customerDivisionIdColumn.setCellValueFactory(new PropertyValueFactory<>("divisionId"));

    }

    /**
     * Function that closes current stage and calls to add customer form function.
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (Load new).
     */
    public void addCustomerClicked(ActionEvent actionEvent) throws IOException {
        System.out.println("*****************************************************************************************");
        Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        stage.close();
        System.out.println("Closing 'Customers.fxml'.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Launching new stage, following function call 'addCustomer'.");
        addCustomer(new Stage());
        System.out.println("*****************************************************************************************");
    }

    /**
     * Function that loads add customer form to new scene.
     * @param stage sets new stage.
     * @throws IOException FXMLLoader (Load new).
     */
    public void addCustomer(Stage stage) throws IOException {
        System.out.println("*****************************************************************************************");
        System.out.println("Getting resource for FXML 'AddCustomer.fxml'.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Loading new stage.");
        System.out.println("*****************************************************************************************");

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("AddCustomer.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1080, 720);
        stage.setTitle("Appointments");
        stage.setScene(scene);
        stage.show();
    }
    /**
     * Function that closes current stage and calls to update customer form function.
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (Load new).
     */
    public void updateCustomerClicked(ActionEvent actionEvent) throws IOException {
        System.out.println("*****************************************************************************************");
        System.out.println("Checking for a valid selection in month tab view.");
        System.out.println("*****************************************************************************************");

        if(customerTableView.getSelectionModel().getSelectedItem() != null) {
            System.out.println("*****************************************************************************************");
            Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
            stage.close();
            System.out.println("Closing 'Customers.fxml'.");
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            currentCustomer = customerTableView.getSelectionModel().getSelectedItem();
            System.out.println("Current customer selected from customer table view.");
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            System.out.println("Launching new stage, following function call 'updateCustomer'.");
            updateCustomer(new Stage());
            System.out.println("*****************************************************************************************");
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No customer selected");
            alert.setContentText("No customer was selected, no update can occur.");
            alert.showAndWait();
        }
    }
    /**
     * Function that loads update customer form to new scene.
     * @param stage sets new stage.
     * @throws IOException FXMLLoader (Load new).
     */
    private void updateCustomer(Stage stage) throws IOException {
        System.out.println("*****************************************************************************************");
        System.out.println("Getting resource for FXML 'UpdateCustomer.fxml'.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Loading new stage.");
        System.out.println("*****************************************************************************************");

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("UpdateCustomer.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1080, 720);
        stage.setTitle("Appointments");
        stage.setScene(scene);
        stage.show();
    }
    /**
     * Function that deletes a selected customer, makes call to delete from database as well.
     * @param actionEvent required for action load.
     */
    public void deleteCustomerClicked(ActionEvent actionEvent) {
        if (customerTableView.getSelectionModel().getSelectedItem() != null) {
            sqlCustomer currentCustomer = customerTableView.getSelectionModel().getSelectedItem();
            if (!customerSQL.existingAppointments(JDBC.connection, currentCustomer)) {
                System.out.println("*****************************************************************************************");
                System.out.println("Selection present/valid. Setting confirmation message for delete confirmation.");
                String confirmation = "This will remove the selected customer permanently.";
                System.out.println("*****************************************************************************************");

                ButtonType confirm = new ButtonType("Ok");
                ButtonType cancel = new ButtonType("Cancel");
                Alert alert = new Alert(Alert.AlertType.WARNING, confirmation, confirm, cancel);
                alert.setTitle("Confirm");
                alert.setHeaderText("Delete customer?");

                Window window = alert.getDialogPane().getScene().getWindow();
                window.setOnCloseRequest(event -> alert.hide());

                Optional<ButtonType> buttonSet = alert.showAndWait();
                buttonSet.ifPresent(selection -> {
                    if (selection.equals(confirm)) {
                        System.out.println("*****************************************************************************************");
                        customerSQL.deleteCustomer(JDBC.connection, currentCustomer);
                        System.out.println("Proceeding with dao function deleteCustomer, deleting customer.");
                        System.out.println("*****************************************************************************************");

                        Alert success = new Alert(Alert.AlertType.INFORMATION);
                        success.setTitle("Customer deleted.");
                        success.setHeaderText("Customer: " + currentCustomer.getCustomerName() + " deleted.");
                        success.setContentText("Appointment cancelled, removed from database.");
                        success.showAndWait();

                        System.out.println("*****************************************************************************************");
                        System.out.println("Resetting customer tab view.");
                        setCustomerTableView();
                        System.out.println("*****************************************************************************************");

                    } else if (selection.equals(cancel)) {
                        System.out.println("*****************************************************************************************");
                        System.out.println("Delete confirmation canceled.");
                        System.out.println("*****************************************************************************************");
                    }
                });
            } else {
                System.out.println("*****************************************************************************************");
                System.out.println("Customer has existing appointments");
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Delete error.");
                alert.setContentText("No delete can occur, please delete selected customer appointments before deleting.");
                System.out.println("*****************************************************************************************");

                System.out.println("*****************************************************************************************");
                System.out.println();
                System.out.println("REQUIREMENT 2: - When deleting a customer record, all of the customer's appointments");
                System.out.println("must be deleted first, due to foreign key restraints'");
                System.out.println();
                System.out.println("*****************************************************************************************");

                System.out.println("*****************************************************************************************");
                System.out.println("Waiting for user input.");
                alert.showAndWait();
                System.out.println("*****************************************************************************************");
            }
        } else {
            System.out.println("*****************************************************************************************");
            System.out.println("No selection made.");
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Selection error.");
            alert.setContentText("No delete can occur, no customer selected.");
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            System.out.println("Waiting for user input.");
            alert.showAndWait();
            System.out.println("*****************************************************************************************");
        }
    }

    /**
     * Function that closes stage and calls to go back to mainscreen.
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (Load new).
     */
    public void returnButtonClicked(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        stage.close();
        mainscreen(new Stage());
    }
    /**
     * Function that sets new stage for mainscreen.
     * @param stage sets new stage
     * @throws IOException FXMLLoader (Load new).
     */
    private void mainscreen(Stage stage) throws IOException {
        System.out.println("*****************************************************************************************");
        System.out.println("Getting resource for FXML 'Mainscreen.fxml'.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Loading new stage.");
        System.out.println("*****************************************************************************************");

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Mainscreen.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1080, 720);
        stage.setTitle("Appointments");
        stage.setScene(scene);
        stage.show();
    }
    /**
     * Getter for currentCustomer variable.
     * @return currentCustomer
     */
    public static sqlCustomer getCurrentCustomer() {
        return currentCustomer;
    }
    /**
     * Setter for currentCustomer.
     * @param currentCustomer currentCustomer
     */
    public static void setCurrentCustomer(sqlCustomer currentCustomer) {
        CustomersController.currentCustomer = currentCustomer;
    }

}
