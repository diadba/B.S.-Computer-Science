package syspackage.dao;

import syspackage.appointmentapp.LoginController;
import syspackage.classes.sqlUser;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;

/**
 * Class that contains SQL statements used for log in application functionality.
 * @author Anthony Coots
 */
public class loginSQL {
    /**
     * Function that compares the given username and password for appropriate login.
     * @param connection JDBC connection
     * @param user username
     * @param pass password
     * @return True, can log in. False, try again.
     */
    public static boolean viewTable(Connection connection, String user, String pass) {
        System.out.println("*****************************************************************************************");
        System.out.println("Checking users table to verify login credentials submitted.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Query:");
        String query =     "SELECT * "
                         + "FROM client_schedule.users "
                         + "WHERE user_name = '" + user + "' AND password = '" + pass + "'";
        System.out.println("*****************************************************************************************");
        System.out.println(query);
        System.out.println("*****************************************************************************************");

        try (Statement statement = connection.createStatement()) {
            ResultSet resultSet = statement.executeQuery(query);
            while (resultSet.next()) {
                System.out.println("*****************************************************************************************");
                System.out.println("Comparing passed username to username in result set.");
                System.out.println("*****************************************************************************************");
                if (resultSet.getString("User_Name").equals(user)) {
                    System.out.println("*****************************************************************************************");
                    System.out.println("Username verified.");
                    System.out.println("*****************************************************************************************");
                    System.out.println("*****************************************************************************************");
                    System.out.println("Comparing passed password to password in result set.");
                    System.out.println("*****************************************************************************************");
                    if (resultSet.getString("Password").equals(pass)) {
                        System.out.println("*****************************************************************************************");
                        System.out.println("Password verified.");
                        System.out.println("*****************************************************************************************");
                        System.out.println("*****************************************************************************************");
                        System.out.println("Collecting data from result set to make object 'currentUser' of class 'sqlUser'.");
                        System.out.println("*****************************************************************************************");

                        System.out.println("*****************************************************************************************");
                        int userId = resultSet.getInt("User_ID");
                        System.out.println("Variable 'userId' - SQL column: 'User_ID' set to: " + userId + ".");

                        String username = resultSet.getString("User_Name");
                        System.out.println("Variable: username - SQL column: 'User_Name' set to: " + username + ".");

                        String password = resultSet.getString("Password");
                        System.out.println("Variable: password - SQL column: 'Password' set to: ***************.");

                        LocalDateTime createDate = resultSet.getTimestamp("Create_Date").toLocalDateTime();
                        System.out.println("Variable: createDate - SQL column: 'Create_Date' set to: " + createDate + ".");

                        String createdBy = resultSet.getString("Created_By");
                        System.out.println("Variable: createdBy - SQL column: 'Created_By' set to: " + createdBy + ".");

                        LocalDateTime lastUpdate = resultSet.getTimestamp("Last_Update").toLocalDateTime();
                        System.out.println("Variable: lastUpdate - SQL column: 'Last_Update' set to: " + lastUpdate + ".");

                        String lastUpdatedBy = resultSet.getString("Last_Updated_By");
                        System.out.println("Variable: lastUpdatedBy - SQL column: 'Last_Updated_By' set to: " + lastUpdatedBy);
                        System.out.println("*****************************************************************************************");

                        System.out.println("*****************************************************************************************");
                        System.out.println("Creating new object 'currentUser' of class 'sqlUser'.");

                        sqlUser currentUser = new sqlUser(userId, username, password, createDate, createdBy, lastUpdate, lastUpdatedBy);
                        LoginController.setCurrentUser(currentUser);

                        System.out.println("Object 'currentUser' created.");
                        System.out.println("*****************************************************************************************");

                        System.out.println("*****************************************************************************************");
                        System.out.println("Login verified, currentUser stored.");
                        System.out.println("*****************************************************************************************");
                        return true;
                    }
                    System.out.println("*****************************************************************************************");
                    System.out.println("Could not verify username/password.");
                    System.out.println("*****************************************************************************************");
                    return false;
                }
                System.out.println("*****************************************************************************************");
                System.out.println("Could not verify username/password.");
                System.out.println("*****************************************************************************************");
                return false;
            }
            } catch (SQLException e) {
                System.out.println("*****************************************************************************************");
                System.out.println("In try/catch, caught: ");
                System.out.println(e.getMessage());
                System.out.println("*****************************************************************************************");
                return false;
            }
        return false;
    }
}
