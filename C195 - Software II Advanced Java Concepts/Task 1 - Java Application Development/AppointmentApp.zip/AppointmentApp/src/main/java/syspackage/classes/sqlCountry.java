package syspackage.classes;

import java.time.LocalDateTime;

/**
 * Class for object(s) 'sqlCountry'. sqlCountry objects are made as objects reflecting the 'countries' table
 * in database.
 * @author Anthony Coots
 */
public class sqlCountry {
    /**
     * countryId matching Country_ID in table.
     */
    private int countryId;
    /**
     * country matching Country in table.
     */
    private String country;
    /**
     * createDate matching Create_Date in table.
     */
    private LocalDateTime createDate;
    /**
     * createdBy matching Created_By in table.
     */
    private String createdBy;
    /**
     * lastUpdate matching Last_Update in table.
     */
    private LocalDateTime lastUpdate;
    /**
     * lastUpdatedBy matching Last_Updated_By in table.
     */
    private String lastUpdatedBy;

    /**
     * Class constructor.
     * @param countryId - Country_ID
     * @param country - Country
     * @param createDate - Create_Date
     * @param createdBy - Created_By
     * @param lastUpdate - Last_Update
     * @param lastUpdatedBy - Last_Updated_By
     */
    public sqlCountry(int countryId, String country, LocalDateTime createDate, String createdBy, LocalDateTime lastUpdate,
                      String lastUpdatedBy) {
        this.countryId = countryId;
        this.country = country;
        this.createDate = createDate;
        this.createdBy = createdBy;
        this.lastUpdate = lastUpdate;
        this.lastUpdatedBy = lastUpdatedBy;
    }
    /**
     * Getter for countryId
     * @return countryId of object
     */
    public int getCountryId() {
        return countryId;
    }
    /**
     * Setter for countryId
     * @param countryId countryId
     */
    public void setCountryId(int countryId) {
        this.countryId = countryId;
    }
    /**
     * Getter for country
     * @return country of object
     */
    public String getCountry() {
        return country;
    }
    /**
     * Setter for country
     * @param country country
     */
    public void setCountry(String country) {
        this.country = country;
    }
    /**
     * Getter for createDate
     * @return createDate of object
     */
    public LocalDateTime getCreateDate() {
        return createDate;
    }
    /**
     * Setter for createDate
     * @param createDate createDate
     */
    public void setCreateDate(LocalDateTime createDate) {
        this.createDate = createDate;
    }
    /**
     * Getter for createdBy
     * @return createdBy of object
     */
    public String getCreatedBy() {
        return createdBy;
    }
    /**
     * Setter for createdBy
     * @param createdBy createdBy
     */
    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }
    /**
     * Getter for lastUpdate
     * @return lastUpdate of object
     */

    public LocalDateTime getLastUpdate() {
        return lastUpdate;
    }
    /**
     * Setter for lastUpdate
     * @param lastUpdate lastUpdate
     */
    public void setLastUpdate(LocalDateTime lastUpdate) {
        this.lastUpdate = lastUpdate;
    }
    /**
     * Getter for lastUpdatedBy
     * @return lastUpdatedBy of object
     */
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }
    /**
     * Setter for lastUpdatedBy
     * @param lastUpdatedBy lastUpdatedBy
     */
    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy;
    }
}
