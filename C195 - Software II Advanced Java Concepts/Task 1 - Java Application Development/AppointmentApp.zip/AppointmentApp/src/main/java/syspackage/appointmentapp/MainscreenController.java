package syspackage.appointmentapp;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import syspackage.classes.sqlAppointment;
import syspackage.dao.appointmentSQL;
import syspackage.helper.JDBC;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/**
 * Class that controls the logic for the mainscreen post log in.
 * @author Anthony Coots
 */
public class MainscreenController implements Initializable {
    /**
     * FXML variable text that displays logged-in username.
     */
    @FXML
    private Text usernameText;

    /**
     * Function that initializes the mainscreen. Checks for appointments within 15 minutes for logged-in user.
     * @param url path location.
     * @param resourceBundle source through resources.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        System.out.println("*****************************************************************************************");
        System.out.println("*****************************************************************************************");
        System.out.println("Initializing MainscreenController.");
        System.out.println("*****************************************************************************************");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Current username: " + LoginController.getCurrentUser().getUsername());
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Setting usernameText for display.");
        usernameText.setText("User: " + LoginController.getCurrentUser().getUsername());
        System.out.println();

        checkForAppointments();
    }

    /**
     * Function that checks the database for an appointment within 15 minutes for the logged-in user.
     */
    private void checkForAppointments() {
        System.out.println("*****************************************************************************************");
        System.out.println("Checking against database if there is an appointment for this user's id within 15 mins.");
        System.out.println("*****************************************************************************************");

        AppointmentsController.allAppointmentsInMonth = FXCollections.observableArrayList();
        appointmentSQL.checkForAppointments(JDBC.connection);

        if(AppointmentsController.allAppointmentsInMonth.size() > 0) {
            for (sqlAppointment appointment : AppointmentsController.allAppointmentsInMonth) {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Appointment soon.");
                alert.setContentText("Appointment within 15 minutes.\n" + "Details:\n - Appointment ID: " + appointment.getAppointmentId()
                + "\n - Appointment Date/Time: " + appointment.getStart());
                alert.showAndWait();
            }
        }
        else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("No upcoming appointments.");
            alert.setContentText("No appointments found within 15 minutes.");
            alert.showAndWait();
        }
    }

    /**
     * Function that closes current stage to launch calendar.
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (Load new).
     */
    public void viewCalendarClicked(ActionEvent actionEvent) throws IOException {
        System.out.println("*****************************************************************************************");
        Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        stage.close();
        System.out.println("Closing 'Mainscreen.fxml'.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Launching new stage, following function call 'launchCalendar'.");
        launchCalendar(new Stage());
        System.out.println("*****************************************************************************************");
    }

    /**
     * Function that launches new stage to show appointments.
     * @param stage sets new stage.
     * @throws IOException FXMLLoader (Load new).
     */
    private void launchCalendar(Stage stage) throws IOException {
        System.out.println("*****************************************************************************************");
        System.out.println("Getting resource for FXML 'Appointments.fxml'.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Loading new stage.");
        System.out.println("*****************************************************************************************");

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Appointments.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1080, 720);
        stage.setTitle("Appointments");
        stage.setScene(scene);
        stage.show();
    }
    /**
     * Function that closes current stage to launch customers.
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (Load new).
     */
    public void viewCustomersClicked(ActionEvent actionEvent) throws IOException {
        System.out.println("*****************************************************************************************");
        Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        stage.close();
        System.out.println("Closing 'Mainscreen.fxml'.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Launching new stage, following function call 'launchCustomers'.");
        launchCustomers(new Stage());
        System.out.println("*****************************************************************************************");
    }
    /**
     * Function that launches new stage to show customers.
     * @param stage sets new stage.
     * @throws IOException FXMLLoader (Load new).
     */
    private void launchCustomers(Stage stage) throws IOException {
        System.out.println("*****************************************************************************************");
        System.out.println("Getting resource for FXML 'Customers.fxml'.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Loading new stage.");
        System.out.println("*****************************************************************************************");

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Customers.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1080, 720);
        stage.setTitle("Customers");
        stage.setScene(scene);
        stage.show();
    }
    /**
     * Function that closes current stage to launch reports.
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (Load new).
     */
    public void viewReportsClicked(ActionEvent actionEvent) throws IOException {
        System.out.println("*****************************************************************************************");
        Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        stage.close();
        System.out.println("Closing 'Mainscreen.fxml'.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Launching new stage, following function call 'launchReports'.");
        launchReports(new Stage());
        System.out.println("*****************************************************************************************");
    }
    /**
     * Function that launches new stage to show reports.
     * @param stage sets new stage.
     * @throws IOException FXMLLoader (Load new).
     */
    private void launchReports(Stage stage) throws IOException {
        System.out.println("*****************************************************************************************");
        System.out.println("Getting resource for FXML 'Reports.fxml'.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Loading new stage.");
        System.out.println("*****************************************************************************************");

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Reports.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1080, 720);
        stage.setTitle("Customers");
        stage.setScene(scene);
        stage.show();
    }
}
