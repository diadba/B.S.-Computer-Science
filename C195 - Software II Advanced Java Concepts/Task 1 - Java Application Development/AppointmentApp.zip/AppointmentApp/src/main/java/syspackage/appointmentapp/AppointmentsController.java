package syspackage.appointmentapp;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.Window;
import syspackage.classes.*;
import syspackage.dao.appointmentSQL;
import syspackage.helper.JDBC;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.ZoneId;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Class that controls the logic for the scene that views appointments in month, week, and adds, updates, and deletes
 * those appointments.
 * @author Anthony Coots
 */
public class AppointmentsController implements Initializable {
    /**
     * FXML variable tab in display for appointments in month selection.
     */
    @FXML
    private Tab monthTab;
    /**
     * FXML variable tab in display for appointments in week selection.
     */
    @FXML
    private Tab weekTab;
    /**
     * FXML variable table view for display of all appointments in month.
     */
    @FXML
    private TableView<sqlAppointment> monthTableView;
    /**
     * FXML variable table view for display of all appointments in week.
     */
    @FXML
    private TableView<sqlAppointment> weekTableView;
    /**
     * FXML variable table column for column in month table view that holds appointment IDs.
     */
    @FXML
    private TableColumn<sqlAppointment, Integer> mAppointmentIdColumn;
    /**
     * FXML variable table column for column in week table view that holds appointment IDs.
     */
    @FXML
    private TableColumn<sqlAppointment, Integer> wAppointmentIdColumn;
    /**
     * FXML variable table column for column in month table view that holds appointment title.
     */
    @FXML
    private TableColumn<sqlAppointment, String> mAppointmentTitleColumn;
    /**
     * FXML variable table column for column in week table view that holds appointment title.
     */
    @FXML
    private TableColumn<sqlAppointment, String> wAppointmentTitleColumn;
    /**
     * FXML variable table column for column in month table view that holds appointment description.
     */
    @FXML
    private TableColumn<sqlAppointment, String> mAppointmentDescColumn;
    /**
     * FXML variable table column for column in week table view that holds appointment description.
     */
    @FXML
    private TableColumn<sqlAppointment, String> wAppointmentDescColumn;
    /**
     * FXML variable table column for column in month table view that holds appointment location.
     */
    @FXML
    private TableColumn<sqlAppointment, String> mAppointmentLocColumn;
    /**
     * FXML variable table column for column in week table view that holds appointment location.
     */
    @FXML
    private TableColumn<sqlAppointment, String> wAppointmentLocColumn;
    /**
     * FXML variable table column for column in month table view that holds appointment contact ID.
     */
    @FXML
    private TableColumn<sqlAppointment, Integer> mAppointmentConColumn;
    /**
     * FXML variable table column for column in week table view that holds appointment contact ID.
     */
    @FXML
    private TableColumn<sqlAppointment, Integer> wAppointmentConColumn;
    /**
     * FXML variable table column for column in month table view that holds appointment type.
     */
    @FXML
    private TableColumn<sqlAppointment, String> mAppointmentTypeColumn;
    /**
     * FXML variable table column for column in week table view that holds appointment type.
     */
    @FXML
    private TableColumn<sqlAppointment, String> wAppointmentTypeColumn;
    /**
     * FXML variable table column for column in month table view that holds appointment start.
     */
    @FXML
    private TableColumn<sqlAppointment, Timestamp> mAppointmentStartColumn;
    /**
     * FXML variable table column for column in week table view that holds appointment start.
     */
    @FXML
    private TableColumn<sqlAppointment, Timestamp> wAppointmentStartColumn;
    /**
     * FXML variable table column for column in month table view that holds end description.
     */
    @FXML
    private TableColumn<sqlAppointment, Timestamp> mAppointmentEndColumn;
    /**
     * FXML variable table column for column in week table view that holds appointment end.
     */
    @FXML
    private TableColumn<sqlAppointment, Timestamp> wAppointmentEndColumn;
    /**
     * FXML variable table column for column in month table view that holds appointment customer ID.
     */
    @FXML
    private TableColumn<sqlAppointment, Integer> mAppointmentCIdColumn;
    /**
     * FXML variable table column for column in week table view that holds appointment customer ID.
     */
    @FXML
    private TableColumn<sqlAppointment, Integer> wAppointmentCIdColumn;
    /**
     * FXML variable table column for column in month table view that holds appointment user ID.
     */
    @FXML
    private TableColumn<sqlAppointment, Integer> mAppointmentUIdColumn;
    /**
     * FXML variable table column for column in week table view that holds appointment user ID.
     */
    @FXML
    private TableColumn<sqlAppointment, Integer> wAppointmentUIdColumn;
    /**
     * FXML variable text in view to display timezone.
     */
    @FXML
    private Text timeText;
    /**
     * Variable of class 'sqlAppointment' to declare current appointment.
     */
    private static sqlAppointment currentAppointment;
    /**
     * List made for all appointments in the month.
     */
    public static ObservableList<sqlAppointment> allAppointmentsInMonth = FXCollections.observableArrayList();
    /**
     * List made for all appointments in the week.
     */
    public static ObservableList<sqlAppointment> allAppointmentsInWeek = FXCollections.observableArrayList();
    /**
     * List made for all locations.
     */
    public static ObservableList<sqlLocation> allLocations = FXCollections.observableArrayList();
    /**
     * List made for all contacts.
     */
    public static ObservableList<sqlContact> allContacts = FXCollections.observableArrayList();
    /**
     * List made for all customers.
     */
    public static ObservableList<sqlCustomer> allCustomers = FXCollections.observableArrayList();
    /**
     * List made for all users.
     */
    public static ObservableList<sqlUser> allUsers = FXCollections.observableArrayList();

    /**
     * Function that initializes the appointment scene.
     * @param url path location.
     * @param resourceBundle source through resources.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        System.out.println("*****************************************************************************************");
        System.out.println("*****************************************************************************************");
        System.out.println("Initializing AppointmentsController.");
        System.out.println("*****************************************************************************************");
        System.out.println("*****************************************************************************************");
        System.out.println();

        timeText.setText("*Time displayed in local time: [" + ZoneId.systemDefault() + "]*");
        System.out.println("*****************************************************************************************");
        System.out.println("Calling appointmentsByMonth function, producing list of all appointments in month.");
        appointmentSQL.appointmentsByMonth(JDBC.connection);
        System.out.println("All appointment objects for user in month: " + allAppointmentsInMonth);
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Calling appointmentsByMonth function, producing list of all appointments in week.");
        appointmentSQL.appointmentsByWeek(JDBC.connection);
        System.out.println("All appointment objects for user in week: " + allAppointmentsInWeek);
        System.out.println("*****************************************************************************************");

        System.out.println();

        System.out.println("****************************************************");
        System.out.println("Moving to call appointmentsInDb()...");

        setMonthTableView();
        setWeekTableView();
    }

    /**
     * Function that adds an appointment to a given list.
     * @param list current list being added to.
     * @param appointmentToAdd appointment to add to list.
     */
    public static void addAppointment(ObservableList<sqlAppointment> list, sqlAppointment appointmentToAdd) {
        list.add(appointmentToAdd);
    }

    /**
     * Getter for observable list allAppointmentsInMonth.
     * @return allAppointmentsInMonth.
     */
    public static ObservableList<sqlAppointment> getMonthList() {
        return allAppointmentsInMonth;
    }
    /**
     * Getter for observable list allAppointmentsInWeek.
     * @return allAppointmentsInWeek.
     */
    public static ObservableList<sqlAppointment> getWeekList() {
        return allAppointmentsInWeek;
    }

    /**
     * Function that sets the month table view with allAppointmentInMonth's list.
     */
    public void setMonthTableView() {
        System.out.println("*****************************************************************************************");
        System.out.println("Setting month tab in table view.");
        System.out.println("*****************************************************************************************");

        monthTableView.setItems(AppointmentsController.allAppointmentsInMonth);
        mAppointmentIdColumn.setCellValueFactory(new PropertyValueFactory<>("appointmentId"));
        mAppointmentTitleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        mAppointmentDescColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
        mAppointmentLocColumn.setCellValueFactory(new PropertyValueFactory<>("location"));
        mAppointmentConColumn.setCellValueFactory(new PropertyValueFactory<>("contactId"));
        mAppointmentTypeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        mAppointmentStartColumn.setCellValueFactory(new PropertyValueFactory<>("start"));
        mAppointmentEndColumn.setCellValueFactory(new PropertyValueFactory<>("end"));
        mAppointmentCIdColumn.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        mAppointmentUIdColumn.setCellValueFactory(new PropertyValueFactory<>("userId"));
    }
    /**
     * Function that sets the week table view with allAppointmentsInWeek's list.
     */
    public void setWeekTableView() {
        System.out.println("*****************************************************************************************");
        System.out.println("Setting week tab in table view.");
        System.out.println("*****************************************************************************************");

        weekTableView.setItems(AppointmentsController.allAppointmentsInWeek);
        wAppointmentIdColumn.setCellValueFactory(new PropertyValueFactory<>("appointmentId"));
        wAppointmentTitleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));
        wAppointmentDescColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
        wAppointmentLocColumn.setCellValueFactory(new PropertyValueFactory<>("location"));
        wAppointmentConColumn.setCellValueFactory(new PropertyValueFactory<>("contactId"));
        wAppointmentTypeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        wAppointmentStartColumn.setCellValueFactory(new PropertyValueFactory<>("start"));
        wAppointmentEndColumn.setCellValueFactory(new PropertyValueFactory<>("end"));
        wAppointmentCIdColumn.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        wAppointmentUIdColumn.setCellValueFactory(new PropertyValueFactory<>("userId"));
        }

    /**
     * Function that loads the add appointment form scene.
     * @param stage sets new stage
     * @throws IOException FXMLLoader (Loads new).
     */
    public void addAppointment(Stage stage) throws IOException {
        System.out.println("*****************************************************************************************");
        System.out.println("Getting resource for FXML 'AddAppointment.fxml'.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Loading new stage.");
        System.out.println("*****************************************************************************************");

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("AddAppointment.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1080, 720);
        stage.setTitle("Appointments");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Function that calls add appointment (scene function) once the add appointment button is clicked in the months tab.
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (Load new).
     */
    public void mAddApptClicked(ActionEvent actionEvent) throws IOException {
        System.out.println("*****************************************************************************************");
        weekTableView.getSelectionModel().clearSelection();
        System.out.println("Cleared potential pending selection from week tab.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        stage.close();
        System.out.println("Closing 'Appointments.fxml'.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Launching new stage, following function call 'addAppointment'.");
        addAppointment(new Stage());
        System.out.println("*****************************************************************************************");
    }

    /**
     * Function that calls update appointment (scene function) once the update button is clicked in the months tab.
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (Load new).
     */
    public void mUpdateApptClicked(ActionEvent actionEvent) throws IOException {
        System.out.println("*****************************************************************************************");
        weekTableView.getSelectionModel().clearSelection();
        System.out.println("Cleared potential pending selection from week tab.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Checking for a valid selection in month tab view.");
        System.out.println("*****************************************************************************************");

        if(monthTableView.getSelectionModel().getSelectedItem() != null) {
            System.out.println("*****************************************************************************************");
            Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
            stage.close();
            System.out.println("Closing 'Appointments.fxml'.");
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            currentAppointment = monthTableView.getSelectionModel().getSelectedItem();
            System.out.println("Current appointment selected from month table view.");
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            System.out.println("Launching new stage, following function call 'updateAppointment'.");
            updateAppointment(new Stage());
            System.out.println("*****************************************************************************************");
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No appointment selected");
            alert.setContentText("No appointment was selected, no update can occur.");
            alert.showAndWait();
        }
    }

    /**
     * Function that loads the update appointment form scene.
     * @param stage sets new stage.
     * @throws IOException FXMLLoader (Loads new).
     */
    private void updateAppointment(Stage stage) throws IOException {
        System.out.print("Getting resource for FXML 'UpdateAppointment.fxml'.");

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("UpdateAppointment.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1080, 720);
        stage.setTitle("Appointments");
        stage.setScene(scene);
        stage.show();
    }
    /**
     * Function that deletes a selected appointment once delete button in month tab is clicked.
     * @param actionEvent required for action load.
     */
    public void mDeleteApptClicked(ActionEvent actionEvent) throws SQLException {
        System.out.println("*****************************************************************************************");
        System.out.println("Checking for a valid selection in month tab view.");
        System.out.println("*****************************************************************************************");

        if(monthTableView.getSelectionModel().getSelectedItem() != null && monthTab.isSelected()) {
            System.out.println("*****************************************************************************************");
            System.out.println("Selection present/valid. Setting confirmation message for delete confirmation.");
            String confirmation = "This will remove the selected appointment permanently.";
            System.out.println("*****************************************************************************************");

            ButtonType confirm = new ButtonType("Ok");
            ButtonType cancel = new ButtonType("Cancel");
            Alert alert = new Alert(Alert.AlertType.WARNING, confirmation, confirm, cancel);
            alert.setTitle("Confirm");
            alert.setHeaderText("Cancel/Delete appointment?");

            Window window = alert.getDialogPane().getScene().getWindow();
            window.setOnCloseRequest(event -> alert.hide());

            Optional<ButtonType> buttonSet = alert.showAndWait();
            buttonSet.ifPresent(selection -> {
                if (selection.equals(confirm)) {
                    System.out.println("*****************************************************************************************");
                    System.out.println("Delete action confirmed. Clearing selection of week tab for clean delete.");
                    weekTableView.getSelectionModel().clearSelection();
                    System.out.println("*****************************************************************************************");

                    System.out.println("*****************************************************************************************");
                    sqlAppointment appointment = monthTableView.getSelectionModel().getSelectedItem();
                    System.out.println("All appointments in 'allAppointmentsInMonth': " + AppointmentsController.allAppointmentsInMonth);
                    System.out.println("Deleting: " + appointment);
                    System.out.println("*****************************************************************************************");

                    System.out.println("*****************************************************************************************");
                    System.out.println("Entering try/catch sequence.");
                    System.out.println("*****************************************************************************************");

                    try {
                        System.out.println("*****************************************************************************************");
                        appointmentSQL.deleteSelected(JDBC.connection, appointment);
                        System.out.println("Proceeding with dao function deleteSQL, deleting appointment.");
                        System.out.println("*****************************************************************************************");

                        Alert success = new Alert(Alert.AlertType.INFORMATION);
                        success.setTitle("Appointment cancelled.");
                        success.setHeaderText(appointment.getAppointmentId() + ", "+ appointment.getType());
                        success.setContentText("Appointment cancelled, removed from database.");
                        success.showAndWait();

                    } catch (SQLException e) {
                        System.out.println("*****************************************************************************************");
                        System.out.println("In try/catch, caught: ");
                        System.out.println(e.getMessage());
                        System.out.println("*****************************************************************************************");
                    }

                    System.out.println("*****************************************************************************************");
                    System.out.println("Reiterating week appointments.");
                    appointmentSQL.appointmentsByWeek(JDBC.connection);
                    System.out.println("*****************************************************************************************");

                    System.out.println("*****************************************************************************************");
                    System.out.println("Reiterating month appointments.");
                    appointmentSQL.appointmentsByMonth(JDBC.connection);
                    System.out.println("*****************************************************************************************");

                    System.out.println("*****************************************************************************************");
                    System.out.println("Resetting week tab view.");
                    setWeekTableView();
                    System.out.println("*****************************************************************************************");

                    System.out.println("*****************************************************************************************");
                    System.out.println("Resetting month tab view.");
                    setMonthTableView();
                    System.out.println("*****************************************************************************************");

                } else if (selection.equals(cancel)) {
                    System.out.println("*****************************************************************************************");
                    System.out.println("Delete confirmation canceled.");
                    System.out.println("*****************************************************************************************");
                }
            });
        }
        else {
            System.out.println("*****************************************************************************************");
            System.out.println("No selection made. Present error.");
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No appointment selected");
            alert.setContentText("No appointment was selected, no delete can occur.");
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            System.out.println("Waiting for user input.");
            alert.showAndWait();
            System.out.println("*****************************************************************************************");
        }
    }
    public void wAddApptClicked(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        stage.close();
        addAppointment(new Stage());

    }
    /**
     * Function that calls update appointment (scene function) once the update button is clicked in the week tab.
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (Load new).
     */
    public void wUpdateApptClicked(ActionEvent actionEvent) throws IOException {
        monthTableView.getSelectionModel().clearSelection();

        if(weekTableView.getSelectionModel().getSelectedItem() != null) {
            Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
            stage.close();

            currentAppointment = weekTableView.getSelectionModel().getSelectedItem();

            updateAppointment(new Stage());
        }
        else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No appointment selected");
            alert.setContentText("No appointment was selected, no update can occur.");
            alert.showAndWait();
        }
    }
    /**
     * Function that deletes a selected appointment once delete button in week tab is clicked.
     * Lambda 3:
     *      parameter 1: selection (button).
     *      ->
     *      expression: conditional reaction based on confirming / deleting appointment.
     *      NOTE: Also in mDeleteApptClicked but hardly any different.
     * @param actionEvent required for action load.
     */
    public void wDeleteApptClicked(ActionEvent actionEvent) throws SQLException {
        System.out.println("*****************************************************************************************");
        System.out.println("Checking for a valid selection in week tab view.");
        System.out.println("*****************************************************************************************");

        if(weekTableView.getSelectionModel().getSelectedItem() != null && weekTab.isSelected()) {
            System.out.println("*****************************************************************************************");
            System.out.println("Selection present/valid. Setting confirmation message for delete confirmation.");
            String confirmation = "This will remove the selected appointment permanently.";
            System.out.println("*****************************************************************************************");

            ButtonType confirm = new ButtonType("Ok");
            ButtonType cancel = new ButtonType("Cancel");
            Alert alert = new Alert(Alert.AlertType.WARNING, confirmation, confirm, cancel);
            alert.setTitle("Confirm");
            alert.setHeaderText("Delete appointment?");

            Window window = alert.getDialogPane().getScene().getWindow();
            window.setOnCloseRequest(event -> alert.hide());

            Optional<ButtonType> buttonSet = alert.showAndWait();
            buttonSet.ifPresent(selection -> {
                if (selection.equals(confirm)) {
                    System.out.println("*****************************************************************************************");
                    System.out.println("Delete action confirmed. Clearing selection of month tab for clean delete.");
                    monthTableView.getSelectionModel().clearSelection();
                    System.out.println("*****************************************************************************************");

                    System.out.println("*****************************************************************************************");
                    sqlAppointment appointment = weekTableView.getSelectionModel().getSelectedItem();
                    System.out.println("All appointments in 'allAppointmentsInWeek': " + AppointmentsController.allAppointmentsInWeek);
                    System.out.println("Deleting: " + appointment);
                    System.out.println("*****************************************************************************************");

                    System.out.println("*****************************************************************************************");
                    System.out.println("Entering try/catch sequence.");
                    System.out.println("*****************************************************************************************");

                    try {
                        System.out.println("*****************************************************************************************");
                        appointmentSQL.deleteSelected(JDBC.connection, appointment);
                        System.out.println("Proceeding with dao function deleteSQL, deleting appointment.");
                        System.out.println("*****************************************************************************************");

                        Alert success = new Alert(Alert.AlertType.INFORMATION);
                        success.setTitle("Appointment cancelled.");
                        success.setHeaderText(appointment.getAppointmentId() + ", "+ appointment.getType());
                        success.setContentText("Appointment cancelled, removed from database.");
                        success.showAndWait();

                    } catch (SQLException e) {
                        System.out.println("*****************************************************************************************");
                        System.out.println("In try/catch, caught: ");
                        System.out.println(e.getMessage());
                        System.out.println("*****************************************************************************************");
                    }

                    System.out.println("*****************************************************************************************");
                    System.out.println("Reiterating month appointments.");
                    appointmentSQL.appointmentsByMonth(JDBC.connection);
                    System.out.println("*****************************************************************************************");

                    System.out.println("*****************************************************************************************");
                    System.out.println("Reiterating week appointments.");
                    appointmentSQL.appointmentsByWeek(JDBC.connection);
                    System.out.println("*****************************************************************************************");

                    System.out.println("*****************************************************************************************");
                    System.out.println("Resetting month tab view.");
                    setMonthTableView();
                    System.out.println("*****************************************************************************************");

                    System.out.println("*****************************************************************************************");
                    System.out.println("Resetting week tab view.");
                    setWeekTableView();
                    System.out.println("*****************************************************************************************");

                } else if (selection.equals(cancel)) {
                    System.out.println("*****************************************************************************************");
                    System.out.println("Delete confirmation canceled.");
                    System.out.println("*****************************************************************************************");
                }
            });
        }
        else {
            System.out.println("*****************************************************************************************");
            System.out.println("No selection made. Present error.");
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No appointment selected");
            alert.setContentText("No appointment was selected, no delete can occur.");
            System.out.println("*****************************************************************************************");

            System.out.println("*****************************************************************************************");
            System.out.println("Waiting for user input.");
            alert.showAndWait();
            System.out.println("*****************************************************************************************");
        }

    }

    /**
     * Function that returns to mainscreen upon return button clicked.
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (Load new).
     */
    public void returnButtonClicked(ActionEvent actionEvent) throws IOException {
        Stage stage = (Stage) ((Button) actionEvent.getSource()).getScene().getWindow();
        stage.close();
        mainscreen(new Stage());
    }

    /**
     * Function that sets new stage for mainscreen.
     * @param stage sets new stage
     * @throws IOException FXMLLoader (Load new).
     */
    private void mainscreen(Stage stage) throws IOException {
        System.out.println("*****************************************************************************************");
        System.out.println("Getting resource for FXML 'Mainscreen.fxml'.");
        System.out.println("*****************************************************************************************");

        System.out.println("*****************************************************************************************");
        System.out.println("Loading new stage.");
        System.out.println("*****************************************************************************************");

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("Mainscreen.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1080, 720);
        stage.setTitle("Appointments");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Getter for currentAppointment variable.
     * @return currentAppointment
     */
    public static sqlAppointment getCurrentAppointment() {
        return currentAppointment;
    }
}

