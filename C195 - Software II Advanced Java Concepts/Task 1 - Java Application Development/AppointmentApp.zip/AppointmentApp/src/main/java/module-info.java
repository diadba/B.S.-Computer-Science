module syspackage.appointmentapp {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires mysql.connector.java;


    opens syspackage.appointmentapp to javafx.fxml;
    exports syspackage.appointmentapp;
    exports syspackage.classes;
}