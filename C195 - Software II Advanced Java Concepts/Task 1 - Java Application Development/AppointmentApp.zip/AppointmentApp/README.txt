TITLE: C195 - Advanced Java Concepts - AppointmentApp
PURPOSE: Providing a GUI application for scheduling appointments.

AUTHOR: Coots, Anthony.
CONTACT INFORMATION: acoots@wgu.edu
STUDENT APPLICATION VERSION: 1.1.2
DATE: 08-10-2023

IDE: IntelliJ Community 2023.1.2
JDK: 17.0.8+9-LTS-211
JAVAFX: 17.0.6

HOW TO RUN:
    After the program starts, a login screen is introduced in either English or French depending on location.
    The user will be asked for valid credentials that are stored in the MySQL local database. After logging in,
    the user will be presented with the choice of viewing appointments, customers, or reports.

ADDITIONAL REPORT:
    The third report in the reports tab will display the number of customers in a certain location. I.E., if two customers
    exist in Nevada, U.S. A table will display the following:

    LOCATION    | CUSTOMERS
    Nevada, U.S.| 2

MYSQL CONNECTOR: mysql-connector-java-8.0.30