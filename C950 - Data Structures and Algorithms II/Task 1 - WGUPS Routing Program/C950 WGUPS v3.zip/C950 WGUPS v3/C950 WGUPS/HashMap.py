#+-----------------------------------------------------------------------------+#
# Name:         Anthony Coots
# Student ID:   010958511
#
# MODIFICATION HISTORY:                                         DATE:
# ------------------------------------------------              ----------------#
# v1.0 - Creation of HashMap.py using source below,             06/04/2023       
#        created __init__, hashFunction, hashAdd, and hashFind
# 
# v1.1 - Final adjustments and comments made.                   06/09/2023
#+-----------------------------------------------------------------------------+#

# C950.REQUIREMENT.D: IDENTIFY A SELF-ADJUSTING DATA STRUCTURE, SUCH AS A HASH TABLE... #
# CITATION / REFERENCE #
# Hash map constuction from https://www.youtube.com/watch?v=9HFbhPscPU0 (Oggi AI - Artificial Intelligence Today), with my own implementation specific of the program
class HashMap:                                                                      
    def __init__(self):                                                         # equivalent of a C++ constructor.
        self.size = 40                                                          # set to size 40 to show for no collision assumption. (PA instruction).
        self.map = [None] * self.size                                           # initialized each cell to none to force list construction of fixed-length.
    
    # Hash function to convert a key of key-value set to an index for the hash table.
    def hashFunction(self, key):
        # example: print(h.hashFunction(58)), an object of class HashMap, h, would return the index for cell of appropriate key. (58 % 40 = 18).
        # This is beneficial in smaller systems, though the assessment specifically states the assumption "there is no collision", a minimal number
        # works just fine and handles collisions via chaining. However with the assumption, collision handling is done by chaining.
        return hash(int(key)) % self.size                                            
 
# C950.REQUIREMENT.E: DEVELOP A HASH TABLE, WITHOUT USING ANY ADDITIONAL LIBRARIES OR CLASSES, THAT HAS AN INSERTION FUNCTION... #   
    # Add function to take key and value, maps to appropriate cell of hash table.
    def hashAdd(self, key, value):
        # key_index represents the index value of hash table for respective key. Uses hashFunction() above.
        key_index = self.hashFunction(key)     
        # key_value is what is to be inserted into the respective cell of the index found with key_index.
        key_value = [key, value]

        # Check to see if the cell is empty.
        if self.map[key_index] is None:
            # If value of hash map at respective index is of empty then add a new list containing the key value pair.
            self.map[key_index] = list([key_value])
            # Return Validation.
            return True
        
        # Should the cell NOT be empty.
        else:
            # Check to see if key already exists within the array.
            for pair in self.map[key_index]:
                # If the 1st value matches the key.
                if pair[0] == key:
                    # Then update the value of the key-value pair.
                    pair[1] = value
                    # Return Validation.
                    return True
                # If the key is not being used / found then append the list at that index.
                self.map[key_index].append(key_value)
                # Return Validation
                return True

# C950.REQUIREMENT.F: DEVELOP A LOOKUP FUNCTION... #
    # Find function returns the key-value pair given the key.
    def hashFind(self, key):
        # key_index represents the index value of hash table for respective key. The same as hashAdd key_index.
        key_index = self.hashFunction(key)
        # If the cell of map at location key_index is not empty (of datatype None).
        if self.map[key_index] is not None:
            # For new array variable 'pair' for comparison of list values in object hash map at position key_index.
            for pair in self.map[key_index]:
                # If the value of array pair[0] equates to input key for position.
                if pair[0] == key:
                    # Return the associated value for key-value pair.
                    return pair[1]
        return None