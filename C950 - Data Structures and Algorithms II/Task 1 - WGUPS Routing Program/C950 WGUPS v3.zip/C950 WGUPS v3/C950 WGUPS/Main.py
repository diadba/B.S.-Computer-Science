#+-----------------------------------------------------------------------------+#
# Title:        C950 WGUPS
# Script:       main.py
# Name:         Anthony Coots
# Student ID:   010958511
#
# MODIFICATION HISTORY:                                         DATE:
# ------------------------------------------------              ----------------#
# v1.0 - Creation of Main.py using source below,                06/06/2023       
#        able to import data via CSV files, started
#        ordering trucks packages lists for which
#        truck is responsible for which package.
# 
# v1.1 - Code to implement data from csv into                   06/07/2023
#        package objects. Successfully implemented
#        and read a packages hash map. Confirming
#        useful structure of HashMap() in HashMap.py
#
#        Added a distance function that reads the 
#        distance table excel turned csv and will
#        accurately give the float distance between
#        two points.
#
#        Started development of nearest neighbor
#        algorithm.
#
# v1.2 - Started development of truckRoute function             06/08/2023
#        that loops through and updates the trucks
#        trip (odometer, time, last address, etc)
#
# v1.3 - Final adjustments and comments made.                   06/09/2023
#
# v1.4 - Removed gui. Results are now displayed in
#        the command line interface.
#+-----------------------------------------------------------------------------+#

# Data is read via CSVs in datastream folder.
import csv
# Floor calculations used with respect to time.
import math
# Datetime for conversion upon input.
from datetime import datetime, timedelta
# Use of hash tables via HashMap.py script.
from HashMap import HashMap
# Use of packages and truck classes for objects.
from Packages import *

# START OF PACKAGES #

# Initialize Hash Table for key-value pair (packageID, packageAddress)
packageHash = HashMap()

# Using import csv, read the csv in datastream directory that will then parse through
# each row making a respective package item with given details, this package object
# is then used with a hash table for its respective ID.
with open("datastream/PackageTable.csv") as PackageTable:
    PackageList = csv.reader(PackageTable)
    for set in PackageList:
        # First  comma seperated value.
        packageID       = set[0]
        # Second comma seperated value.
        packageAddress  = set[1]
        # Third  comma seperated value.
        packageCity     = set[2]
        packageState    = ''
        # Fifth  comma seperated value.
        packageZip      = set[4]
        packageDeadline = set[5]
        packageWeight   = set[6]
        packageNotes    = set[7]

        # Create an object of class Packages (see Packages.py).
        package = Packages(packageID
                          ,packageAddress
                          ,packageDeadline
                          ,packageCity
                          ,packageState
                          ,packageZip 
                          ,packageWeight
                          ,packageNotes
                          # Default value, all packages will leave the HUB.
                          ,'At the hub')
        # hashAdd is a function defintion for HashMap class that will add a new key-value 
        # pair using the packageID, key, and the package object, value, to the newly constructed HashMap.
        packageHash.hashAdd(packageID, package)

# Using import csv, read the csv in datastream directory that will then parse through
# the file to give a list then declared as variable 'DistanceArray'.
with open("datastream/DistanceTableFormatted.csv") as DistanceTable:
    DistanceArray = csv.reader(DistanceTable)
    DistanceArray = list(DistanceArray)


# END OF PACKAGES #

# C950.REQUIREMENT.A: IDENTIFY A SELF-ADJUSTING ALGORITHM THAT YOU USED TO CREATE YOUR PROGRAM TO DELIVER PACKAGES #

# START OF NEAREST NEIGHBOR ALGORITHM #                                                                                                 

# Definition (Function) to calculate the distance between two given locations, as mail
# gets delivered, that recently dropped off location will become the new start for a 
# nearest neighbor algorithm. Nearest neighbor seems, in my opinion, the most intuitive
# as one truck is already considered for time constraints, the other package constraints,
# and the third (being the first truck) for little to no constraints for delivery. 
def distanceCalc(start, end):
    # totalDistance variable is the cell value given at an x and y location as read from DistanceArray. 
    # Of O(1) time and space-complextity as both position values are given.
    totalDistance = DistanceArray[start][end]   
    # The CSV read will make empty spaces as '' for comparison. We know that the distance from a to b is
    # the same as b to a given in the project assumptions.
    if DistanceArray[start][end] == '':
        # Then given the fact the given data is of 1:1 correspondance in rows and columns, then the
        # inverse will amount to the respective float value. Example: If working left to right as
        # 'from' then 'to', then distanceCalc(4,9), resulting in an empty cell, should be of equivalence
        # to location (9,4) as the addresses are in parallel should you mirror the table. Then,
        # DistanceArray[start][end] == DistanceArray[end][start] is assumed.
        totalDistance = DistanceArray[end][start] 
    # Returns the value of the CSV at given array coordinates to call.
    return totalDistance

# TRUCKS #

# The WGUPS hub is where all packages are loaded and thus where the first current address is.
initLocation = '4001 South 700 East'

# This truck object to have some constraints, will leave at initial start of 8:00 a.m.
# Package list will be constructed of all available packages at 8 a.m. NOT exceeding 16 total.
# Package of ID  1 has only a constraint that delivery deadline is before 10:30 a.m.
# Package of ID 13 has only a constraint that delivery deadline is before 10:30 a.m.
# Package of ID 14 has constraints that delivery deadline is before 10:30 a.m. and must be on same truck as 15 and 19.
# Package of ID 15 has only a constraint that delivery deadline is before 9:00  a.m.
# Package of ID 16 has constraints that delivery deadline is before 10:30 a.m. and must be on same truck as 13 and 19.
# Package of ID 19 has no constraints, but was taken off of truck C, because package with ID 25 would not be on time.
# Package of ID 20 has constraints that delivery deadline is before 10:30 a.m. and must be on same truck as 13 and 15.
# Package of ID 29 has only a constraint that delivery deadline is before 10:30 a.m.
# Package of ID 30 has only a constraint that delivery deadline is before 10:30 a.m.
# Package of ID 31 has only a constraint that delivery deadline is before 10:30 a.m.
# Package of ID 34 has only a constraint that delivery deadline is before 10:30 a.m.
# Package of ID 37 has only a constraint that delivery deadline is before 10:30 a.m.
# Package of ID 40 has only a constraint that delivery deadline is before 10:30 a.m.
# Truck A has a departure time of 8 a.m. this take care of packages with an early delivery deadline as that is the
# earliest a truck may leave.
truckA = Trucks([1, 13, 14, 15, 16, 19, 20, 29, 30, 31, 34, 37, 40], 0.0, initLocation, timedelta(hours = 8,minutes = 0))

# This truck object to have some package constraints, will leave at 10:20 a.m.
# Package of ID  3 must be delivered on truck 2.
# Package of ID  9 will be ready for delivery at 10:20 a.m.
# Package of ID 12 has no constraints.
# Package of ID 17 has no constraints.
# Package of ID 18 must be delivered on truck 2.
# Package of ID 21 has no constraints.
# Package of ID 22 has no constraints.
# Package of ID 23 has no constraints.
# Package of ID 24 has no constraints.
# Package of ID 26 has no constraints.
# Package of ID 27 has no constraints.
# Package of ID 35 has no constraints.
# Package of ID 36 must be delivered on truck 2.
# Package of ID 38 must be delivered on truck 2.
# Package of ID 39 has no constraints.
# Truck B has one job, take packages with no time constraints as it leaves at 10:20:00 a.m. which, conveniently is when package 
# with ID 19, corrects its' address from assumptive error. Also giving time for a truck to be done and a driver available.
truckB = Trucks([3, 9, 12, 17, 18, 21, 22, 23, 24, 26, 27, 35, 36, 38, 39], 0.0, initLocation, timedelta(hours = 10,minutes = 20))

# This truck object to have some package constraints, will leave at 9:05 a.m.
# Package of ID  2 has no constraints.
# Package of ID  4 has no constraints.
# Package of ID  5 has no constraints.
# Package of ID  6 has been delayed to hub until 9:05 a.m.
# Package of ID  7 has no constraints.
# Package of ID  8 has no constraints.
# Package of ID 10 has no constraints.
# Package of ID 11 has no constraints.
# Package of ID 25 has been delayed to hub until 9:05 a.m.
# Package of ID 28 has been delayed to hub until 9:05 a.m.
# Package of ID 32 has been delayed to hub until 9:05 a.m.
# Package of ID 33 has no constraints.
truckC = Trucks([2, 4, 5, 6, 7, 8, 10, 11, 25, 28, 32, 33], 0.0, initLocation, timedelta(hours = 9,minutes = 5))

# Function / definition that returns a number of which package is closest. O(NlogN) + O(N).
def getClosestDelivery(truck):
    # Make an empty list to contain a package ID and how close it is to the current location (truck.truckAddress)
    compList = []

    # For the amount of packages in a truck...
    for i in range(0, len(truck.truckPackages)):
        # Indicate a package in the trucks list of packages at position i.
        packageKey = truck.truckPackages[i]
        # Select the package in the hash table being stored at key.
        package = packageHash.hashFind(key = str(packageKey))
        # Package address is to the current package's packageAddress class value.
        packageAddr = package.packageAddress

        # For function / definition getAddressInt, which returns which row the address is in the distance table,
        # set variable currAddressNum to an integer of the functions return value.
        currAddressNum = int(getAddressInt(truck.truckAddress))
        # For function / definition getAddressInt, which returns which row the address is in the distance table,
        # set variable nextAddressNum to an integer of the functions return value.
        nextAddressNum = int(getAddressInt(packageAddr))

        # Variable distance is calculated using function / definition distanceCalc, which calculates the distance
        # between two locations in the distance table using their integer values to mark a row and column.
        distance = float(distanceCalc(currAddressNum, nextAddressNum))

        # Add to the initially empty list, the distance from current package to next address, the package ID, and
        # the package address.
        compList.append([float(distance), packageKey, packageAddr])  

    # Known to average time-complexity of O(NlogN) and of O(N) space-complexity.
    compList.sort()                                                     # O(nlogn) time-complexity in average cases, which is due to variable 
    popNum = compList[0][1]                                             # sorting calculation as list either increases or decreases. As
                                                                        # it is faster with a smaller list of input and slower if bigger.
    # Return the package to be removed 'popped' off of the truck.truckPackages list.
    return popNum
    

# Function / definition to calculate the column location of an address in the distances table that is later used
# for calculation of distances between two locations in the same table.
def getAddressInt(currentAddress):  
    # 27 addresses are given, 27 iterations are used for the loop
    for i in range(0,28):
        # Is of O(N) time-complexity as it does need to search the entire first column.
        if currentAddress in DistanceArray[0][i]:
            # Return the row number for the matching string address in the distance table.
            return int(i)

# Function / definition to calculate the trucks live route.
def truckRoute(truck, time):

    initTruckTime = truck.truckDepart
    # Given a datetime time, return a string for hours based on the %H location.
    hrs  = int(time.strftime("%H"))
    # Given a datetime time, return a string for minutes based on the %M location.
    mins = int(time.strftime("%M"))
    # Given a datetime time, return a string for seconds based on the %S location.
    sec  = int(time.strftime("%S"))
    # Set time to a timedelta variable used for comparison of truck departures.
    time = timedelta(hours = hrs, minutes = mins, seconds = sec)
    # A comparison flag for packages that are en route but not yet delivered on a time fault.
    limitFlag = 0

    # Hot fix for the package #9 issue, while hard coded, a function that searches for a substring
    # on packageNotes and then does the update is more desirable however not needed. There are many
    # ways to do the same thing.
    # If the timedelta time is equal or greater than 10:20:00 a.m., WGUPS has been informed and the
    # address is changed.
    if time >= timedelta(hours = 10, minutes = 20, seconds = 0) and truck == truckB:
        # fixPackage variable to be the second package on truckB, package #9.
        fixPackage = truck.truckPackages[1]
        # Package class information is now set to variable package via hash table.
        package = packageHash.hashFind(key = str(fixPackage))
        # Package address is then updated to the correct address before doing any nearest neighbor math.
        package.packageAddress = '410 S State St'
        package.packageNotes += str(', address updated')
    
    # if the time is before the trucks start (departure time) change the flag so no packages are delivered yet.
    if time <= initTruckTime:
        for i in range(0, len(truck.truckPackages)):
            packageKey = truck.truckPackages[i]
            package = packageHash.hashFind(key = str(packageKey))
            if package.packageNotes[:7].upper() == "DELAYED":
                package.packageLocation = str('At the hub / Delayed: ' + str(package.packageNotes[51:55]))
            else:
                package.packageLocation = str('At the hub: ' + str(time))
        # While loop condition violated.
        limitFlag = 1
    
    # of O(N) time and space-complexity, each truck has a different amount of packages resulting in more or less time and space.
    for i in range(0, len(truck.truckPackages)):
        # Checks the flag to validate process.
        while limitFlag == 0:
            # If the trucks departure time is before the desired input time, begin the process of delivering packages.
            if truck.truckDepart < time:
                # Variable popnum checks the closest delivery for each package on a truck. 
                popNum = getClosestDelivery(truck)
                # package information is set to the currently to be delivered package.
                package = packageHash.hashFind(key = str(popNum))
                # calculate the distance between the trucks current address and the next delivered address.
                tripMiles = float(distanceCalc(getAddressInt(truck.truckAddress), getAddressInt(package.packageAddress)))
                # Trip time is a calculation based on minutes and seconds using the average speed of 18 miles per hour and
                # the distance traveled (in miles).
                tripTime = round((tripMiles / 18) * 60, 2)
            
                # If the trip time is 0, then both no time was used in between deliveries meaning
                # multiple packages were delivered to the same address.
                if tripTime == 0.0:
                    # Trip minutes are zero.
                    tripMin = 0.0
                    # Trip seconds are zero.
                    tripSec = 0.0
                # If the two addresses are different, do the math on the distance traveled and the average speed
                # that was given in the assumptions.
                else:
                    # Example if trip time was 18.85, based on the tripTime math, the floor gives the trip minutes (18).
                    tripMin = math.floor(tripTime)
                    # Then this, by modulo operating with the floor of the trip time, gives the seconds * 60 for integer value.
                    tripSec = round(tripTime % int(math.floor(tripTime)) * 60,2)
                
                # For the next package in line...
                preDepart = truck.truckDepart
                # Truck time is updated.
                truck.truckDepart = truck.truckDepart + timedelta(minutes = tripMin, seconds = int(tripSec))
                # The next package's location is en route.
                package.packageLocation = str('En route: ' + str(time))

                # If the truck departure is greater than the time given for checking, the truck has been en route.
                if truck.truckDepart > time:
                    for i in range(0, len(truck.truckPackages)):
                        inKey = truck.truckPackages[i]
                        inPack = packageHash.hashFind(key = str(inKey))
                        inPack.packageLocation = str('En route: ' + str(time))
                    limitFlag = 1
                    truck.truckDepart = preDepart
                    truck.truckStatus = 'EN ROUTE'
                    break

                # For each package delivered, update the trucks odometer after each package.
                truck.truckOdo += tripMiles
                # Remove the package from the trucks list so it is not compared in Nearest Neighbor Algorithm.
                truck.truckPackages.remove(int(package.packageID))
                # Its current location is that of the most recent package delivered
                truck.truckAddress = package.packageAddress
                # The most recent package has now been delivered.
                hrs, mins, sec = str(truck.truckDepart).split(':')
                if int(hrs) < 10: hrs = str('0' + str(hrs))
                package.packageLocation = str('Delivered: ' + str(hrs) + ':' + str(mins))
                
                # If the truck has no packages or no more packages, it returns to the hub.
                if truck.truckPackages == []:
                    # Do one last calculation from last stop to back to hub.
                    truck.truckOdo += float(distanceCalc(getAddressInt(truck.truckAddress), getAddressInt(initLocation))) 
                    # Truck address is set back to the hub's address.
                    truck.truckAddress = initLocation
                    # Truck status is updated.
                    truck.truckStatus = 'AT THE HUB'
                    # end loop.
                    limitFlag = 1

    return int(truck.truckOdo)

def userInterface(truck, time):
    print('+--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+')
    if truck == truckA: print('TRUCK A: ')
    elif truck == truckB: print('TRUCK B: ')
    else: print('TRUCK C: ')
    # Initial truck list of packages before they are removed from the truck.
    initTruck = []
    totalOdo = 0.0

    # for the amount of packages on each truck, append each package to the temp list.
    for i in range(0, len(truck.truckPackages)):
        initTruck.append(truck.truckPackages[i])

    # Do truck / program math.
    totalOdo = truckRoute(truck, time)

    tableFormat(initTruck)

    return float(totalOdo)



# CITATION / REFERENCE #
# C950 WGUUPS Project Implementation steps, section E is used with a twist. #
# Minimal comments made as this is just the interface...
def main():
    print('MENU OPTIONS:')
    print('+--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+')
    print('1.\tPrint all package status and total mileage')
    print('2.\tGet a single package status with a time')
    print('3.\tGet all package status with a time')
    print('4.\tPrint hash table')
    print('5.\tExit program')
    print('+--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+')

    start = input('Please select from the menu: ')

    match start:
        case '1': 
            printAll(1)
        case '2':
            printSingle()
        case '3':
            printAll(3)
        case '4':
            seeHash()
        case '5':
            exit()
        case _:
            print('Invalid input. Exiting...')
            exit()

    print('Please scroll to top for interface results...')
    print('+--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+')

def printAll(check):
    if check == 1:
        time = datetime.strptime('23:59:59', "%H:%M:%S")
    else:
        time = datetime.strptime(input("Please enter a time in HH:MM:SS format: "), "%H:%M:%S") 
    t1 = userInterface(truckA, time)
    t2 = userInterface(truckB, time)
    t3 = userInterface(truckC, time)
    if check == 1:
        print('+--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+')
        print('TOTAL MILES: ' + str(round(t1+t2+t3, 2)))
        print('+--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+')
    else:
        print('+--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+')
        print('TOTAL MILES FROM START: ' + str(round(t1+t2+t3, 2)))
        print('+--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+')
        print('TIME: ' + str(time)[11:16])
        print('+--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+')

def printSingle():
    ID = input("Please enter a package ID: ")
    time = input("Please enter a time in HH:MM:SS format: ")
    time = datetime.strptime(time, "%H:%M:%S")

    t1 = truckRoute(truckA, time)
    t2 = truckRoute(truckB, time)
    t3 = truckRoute(truckC, time) 

    package = packageHash.hashFind(key = str(ID))
    tableFormat(ID)

    print('+--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+')
    print('TOTAL MILES: ' + str(round(t1+t2+t3, 2)))
    print('+--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+')
    print('TIME: ' + str(time)[11:16])
    print('+--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+')

def seeHash():
    print('\n# C950.REQUIREMENT.E - HASH TABLE:')
    print(*packageHash.map, sep='\n')
    print('+--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+')

def tableFormat(List):
    print('+--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+')
    print('ID:     Address:\t\t\t        City:             Zip:   Deadline:     KG:     Notes:                                                        Status:')
    print('+--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+')
    # For the amount of packages in the list.
    for i in List:
        # Current package is set.
        package = packageHash.hashFind(key = str(i))
        Address = stringFormat(str(package.packageAddress), 40)
        City = stringFormat(str(package.packageCity), 18)
        Deadline = stringFormat(str(package.packageDeadline), 14)
        Weight = stringFormat(str(package.packageWeight), 8)
        Notes = stringFormat(str(package.packageNotes), 62)
        Location = stringFormat(str(package.packageLocation), 20)
        
        print(str(package.packageID) + '\t' + str(Address) + str(City) + str(package.packageZip) + '  ' + str(Deadline) + str(Weight)
            + str(Notes) + str(Location)) 
   
def stringFormat(fstr, length):
    for i in range(0, length - len(fstr)):
        fstr += ' '

    return fstr
    
main()

