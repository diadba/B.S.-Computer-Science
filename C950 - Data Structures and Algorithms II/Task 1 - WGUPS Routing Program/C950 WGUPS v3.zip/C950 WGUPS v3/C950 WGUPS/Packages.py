#+-----------------------------------------------------------------------------+#
# Name:         Anthony Coots
# Student ID:   010958511
#
# MODIFICATION HISTORY:                                         DATE:
# ------------------------------------------------              ----------------#
# v1.0 - Creation of Packages.py using source below,            06/06/2023       
#
# v1.1 - Changed __str__ in both classes to return all
#        associated values as string. (str() ... + ' '
#        around each value).
#+-----------------------------------------------------------------------------+#

class Packages:
    # Constructor for class Packages as packages data will require a variety of datatypes.
    def __init__(self
                ,packageID
                ,packageAddress
                ,packageDeadline
                ,packageCity
                ,packageState                                                   # State not necessary see REQUIREMENTS E. (06/06/23)
                ,packageZip
                ,packageWeight
                ,packageNotes
                ,packageLocation):
        self.packageID = packageID
        self.packageAddress = packageAddress
        self.packageDeadline = packageDeadline
        self.packageCity = packageCity
        self.packageState = packageState                                        # State not necessary see REQUIREMENTS E. (06/06/23)
        self.packageZip = packageZip
        self.packageWeight = packageWeight
        
        if packageNotes == '':
            packageNotes = 'No notes'
        self.packageNotes = packageNotes
        self.packageLocation = 'EN ROUTE'



    # String representation of each package will be necessary for representation throughout the program.
    # Returns a string conversion of all data aspects of a package.
    def __str__(self):
        return(str(self.packageID)      + ' ' +
               str(self.packageAddress) + ' ' +
               str(self.packageCity)    + ' ' +
               str(self.packageState)    + 
               str(self.packageZip)     + ' ' +
               str(self.packageDeadline)+ ' ' +
               str(self.packageWeight)  + ' ' +
               str(self.packageNotes)   + ' ' +
               str(self.packageLocation))

class Trucks:
    # Constructor for class Trucks as there will be 3 truck objects with variety of datatypes.
    def __init__(self
                ,truckPackages
                ,truckOdo
                ,truckAddress
                ,truckDepart):
        self.truckPackages = truckPackages
        self.truckOdo = truckOdo
        self.truckAddress = truckAddress
        self.truckDepart = truckDepart
        self.truckStatus = ''
    
    # String representation for each truck.
    def __str__(self):
        return(str(self.truckPackages)      + ' ' +
                   str(self.truckOdo)       + ' ' +
                   str(self.truckAddress)   + ' ' +
                   str(self.truckDepart))

