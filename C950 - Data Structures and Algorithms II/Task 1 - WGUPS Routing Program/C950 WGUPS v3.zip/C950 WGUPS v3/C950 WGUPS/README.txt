NAME:	Coots, Anthony
DATE: 	06/13/2023

NOTES: Please know the development of the project uses python version 3.10. The code 
makes use of the 'match' syntax which will cause error upon runtime if version 3.10
or older is not used.