package syspackage.inventorymanagement;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

/**
 * Class that controls the logic for the modify part screen.
 * @author Anthony Coots
 *
 * FUTURE ENHANCEMENT: Initially upon constructing this form, there was a reason the code within 'modifyFormSet()'
 * was exterior to initialize, now it can be moved back in...
 */

public class ModifyPartController implements Initializable {
    /**
     * FXML variable that sets a disabled text field for a parts ID.
     */

    @FXML
    private TextField modifyPartIdField;

    /**
     * FXML variable that sets a text field for a parts name that may or may not be changed.
     */

    @FXML
    private TextField modifyPartNameField;

    /**
     * FXML variable that sets a text field for a parts inventory (stock) that may or may not be changed.
     */

    @FXML
    private TextField modifyPartInventoryField;

    /**
     * FXML variable that sets a text field for a parts cost / price that may or may not be changed.
     */

    @FXML
    private TextField modifyPartCostField;

    /**
     * FXML variable that sets a text field for a parts minimum inventory that may or may not be changed.
     */

    @FXML
    private TextField modifyPartMinField;

    /**
     * FXML variable that sets a text field for a parts maximum inventory that may or may not be changed.
     */

    @FXML
    private TextField modifyPartMaxField;

    /**
     * FXML variable that sets a dynamic text field for a parts machine id or company name that may or may not be changed.
     */

    @FXML
    private TextField modifyPartMachineField;

    /**
     * FXML variable for Radio Button In-House objects for the modify part screen as a part may be changed to such.
     */

    @FXML
    private RadioButton modifyInHouseRadioButton;

    /**
     * FXML variable for Radio Button Outsourced objects for the modify part screen as a part may be changed to such.
     */

    @FXML
    private RadioButton modifyOutsourcedRadioButton;

    /**
     * FXML variable that sets text before the machine ID / company name field. Changes as a subclass is selected.
     */

    @FXML
    private Text machineOrComp;

    /**
     * List of all parts listed in the inventory.
     */

    private final ObservableList<Part> indexCheck = Inventory.getAllParts();

    /**
     * Function that is called upon to initiate the modify part screen. The objects current class sets the radio button.
     * @param url path location.
     * @param resourceBundle source through root.
     */

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        modifyFormSet();
    }

    /**
     * Function that unselects the other radio button (outsourced) and sets the text before the text field appropriately.
     */
    public void inhouseClicked() {
        if(modifyOutsourcedRadioButton.isSelected()) {
            modifyOutsourcedRadioButton.setSelected(false);
            modifyInHouseRadioButton.setSelected(true);
        }
        else {
            modifyInHouseRadioButton.setSelected(true);
        }
        machineOrComp.setText("MACHINE ID:");
    }

    /**
     * Function that takes the string that caused the function to be called and makes a visible alert that the cost
     * text field data is invalid and must be modified.
     * @param errorValue is the string value causing the function to be called, input data, tested on, must be modified.
     */
    public void invalidCost(String errorValue) {
        String confirmation = "Invalid price / cost value input \"" + errorValue +"\". Please try again.";

        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("Invalid price / cost");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }

    /**
     * Function if any of the text fields contain invalid data upon saving to display an alert notifying user of such.
     */
    private void invalidFields() {
        String confirmation = "Invalid values. Please try again.";

        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("Invalid input in fields.\n\nNOTE: Min should be less than max; and Inv should be between those two values.\nMin and Max should be greater than or equal to 0.");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }

    /**
     * Function that takes the inventory string and makes a visible alert that the inventory text field data is invalid
     * and must be modified.
     * @param errorValue is the string value causing the function to be called, input data, tested on, must be modified.
     */
    public void invalidInv(String errorValue) {
        String confirmation = "Invalid inv input \"" + errorValue +"\". Please try again.";

        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("Invalid inventory");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }

    /**
     * Function that takes the maximum inventory string and makes a visible alert that the inventory text field data is
     * invalid and must be modified.
     * @param errorValue is the string value causing the function to be called, input data, tested on, must be modified.
     */
    public void invalidMax(String errorValue) {
        String confirmation = "Invalid max value input \"" + errorValue +"\". Please try again.";

        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("Invalid maximum");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }

    /**
     * Function that takes the minimum inventory string and makes a visible alert that the inventory text field data is
     * invalid and must be modified.
     * @param errorValue is the string value causing the function to be called, input data, tested on, must be modified.
     */
    public void invalidMin(String errorValue) {
        String confirmation = "Invalid min value input \"" + errorValue +"\". Please try again.";

        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("Invalid minimum");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }

    /**
     * Additional T/F function that checks input integrity by comparing the inventory, minimum and maximum values to see if
     * the minimum and maximum is a non-negative integer and if the inventory is within the minimum and maximum bounds. (Inclusive).
     * @param inv inventory string then converted to an integer.
     * @param min inventory string then converted to an integer.
     * @param max inventory string then converted to an integer.
     * @return true if the inventory, minimum and maximum fields are valid. else false, but giving an alert.
     */
    public boolean invCheck(String inv, String min, String max) {
        int checkInv = Integer.parseInt(inv);
        int checkMin = Integer.parseInt(min);
        int checkMax = Integer.parseInt(max);

        if(checkMin >= 0 && checkMax >= 0 && checkInv >= checkMin && checkInv <= checkMax) {
            return true;
        }
        else {
            invalidFields();
            return false;
        }
    }

    /**
     * Function to check if certain input is numeric (where certain fields do not take numeric values).
     * @param string the string of respective fields to be checked for numeric value.
     * @return true of false, condition works on called logic.
     */
    public boolean isNumeric(String string) {
        return string != null && string.matches("[-+]?\\d*\\.?\\d+");
    }


    /**
     * Function if any of the text fields are empty (not populated with data) to display an alert notifying user of such.
     */
    public void missingFields() {
        String confirmation = "One or more fields with no value. Please try again.";

        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("Missing fields.");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }

    /**
     * Function that essentially initiates the form, separated from initialize in the early development stages.
     */
    public void modifyFormSet() {
        Part currentPart = MainController.getCurrentPart();

        String partID = String.valueOf(currentPart.getId());
        String partName = currentPart.getName();
        String partCost = String.valueOf(currentPart.getPrice());
        String partInv = String.valueOf(currentPart.getStock());
        String partMin = String.valueOf(currentPart.getMin());
        String partMax = String.valueOf(currentPart.getMax());

        modifyPartIdField.setText(partID);
        modifyPartNameField.setText(partName);
        modifyPartCostField.setText(partCost);
        modifyPartInventoryField.setText(partInv);
        modifyPartMinField.setText(partMin);
        modifyPartMaxField.setText(partMax);

        if (currentPart instanceof InHouse) {
            machineOrComp.setText("MACHINE ID: ");
            modifyInHouseRadioButton.setSelected(true);
            int partMId = ((InHouse) currentPart).getMachineId();
            modifyPartMachineField.setText(String.valueOf(partMId));

        } else if (currentPart instanceof Outsourced) {
            machineOrComp.setText("COMPANY NAME: ");
            modifyOutsourcedRadioButton.setSelected(true);
            String partCompany = ((Outsourced) currentPart).getCompanyName();
            modifyPartMachineField.setText(String.valueOf(partCompany));
        }
    }

    /**
     * Function that calls return to main screen function. Could be minimized in the future however, this is an
     * 'on action' event for the FXML.
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (returning to main screen, essentially).
     */
    public void modifyPartCancelClicked(ActionEvent actionEvent) throws IOException {
        returnMainScreen(actionEvent);
    }

    /**
     * Function that processes the input within the text fields, or lack thereof, and responds accordingly. If input
     * within text fields is valid, the modified part is saved. Else, alerts are returned though stays on the form.
     * @param actionEvent required action for load.
     */
    public void modifySaveClicked(ActionEvent actionEvent) {
        Part currentPart = MainController.getCurrentPart();

        String partName     = modifyPartNameField.getText();
        String partCost     = modifyPartCostField.getText();
        String partInv      = modifyPartInventoryField.getText();
        String partMin      = modifyPartMinField.getText();
        String partMax      = modifyPartMaxField.getText();
        String partCompany  = modifyPartMachineField.getText();

        int newId = currentPart.getId();
        int index = indexCheck.indexOf(currentPart);

        try {
            if(paramCheck(partName, partCost, partInv, partMin, partMax, partCompany)) {
                if(invCheck(partInv, partMin, partMax)) {
                    double newCost = Double.parseDouble(modifyPartCostField.getText());
                    int newInv = Integer.parseInt(modifyPartInventoryField.getText());
                    int newMin = Integer.parseInt(modifyPartMinField.getText());
                    int newMax = Integer.parseInt(modifyPartMaxField.getText());

                    if (currentPart instanceof InHouse) {
                        if (modifyOutsourcedRadioButton.isSelected()) {
                            Part newSubClass = new Outsourced(newId, partName, newCost, newInv, newMin, newMax, partCompany);

                            Inventory.updatePart(index, newSubClass);
                            returnMainScreen(actionEvent);
                        }
                        else if (modifyInHouseRadioButton.isSelected() && isNumeric(partCompany)) {
                            int machineId = Integer.parseInt(modifyPartMachineField.getText());

                            Part updatePart = new InHouse(newId, partName, newCost, newInv, newMin, newMax, machineId);

                            Inventory.updatePart(index, updatePart);
                            returnMainScreen(actionEvent);
                        }
                        else invalidFields();
                    }
                    else if (currentPart instanceof Outsourced) {
                        if (modifyOutsourcedRadioButton.isSelected()) {
                            Part updatePart = new Outsourced(newId, partName, newCost, newInv, newMin, newMax, partCompany);

                            Inventory.updatePart(index, updatePart);
                            returnMainScreen(actionEvent);
                        }
                        else if (modifyInHouseRadioButton.isSelected() && isNumeric(partCompany)) {
                            int machineId = Integer.parseInt(modifyPartMachineField.getText());

                            Part newSubClass = new InHouse(newId, partName, newCost, newInv, newMin, newMax, machineId);

                            Inventory.updatePart(index, newSubClass);
                            returnMainScreen(actionEvent);
                        }
                        else invalidFields();
                    }
                }
            }
        } catch (Exception e) {
            invalidFields();
        }
    }

    /**
     * Function that unselects the other radio button (in-house) and sets the text before the text field appropriately.
     */
    public void outsourcedClicked() {
        if(modifyInHouseRadioButton.isSelected()) {
            modifyInHouseRadioButton.setSelected(false);
            modifyOutsourcedRadioButton.setSelected(true);
        }
        else {
            modifyOutsourcedRadioButton.setSelected(true);
        }
        machineOrComp.setText("COMPANY NAME:");
    }

    /**
     * Function that given the MODIFIED part's name, cost, inventory, minimum and maximum inventory, and machine ID or company name
     * input, will execute multiple checks to confirm the input is valid so the form can be saved (the part added). If
     * input fails during a certain check, a certain error is shown for the respective field where the error occurred.
     * @param name part's name input.
     * @param cost part's cost / price input.
     * @param inv part's inventory input.
     * @param min part's minimum inventory input.
     * @param max part's maximum inventory input.
     * @param dynamic part's machine ID or company name input.
     * @return if the input is valid, the boolean function returns true where called, meaning the form may proceed.
     * and if false, the form has invalid fields and will not proceed.
     */
    public boolean paramCheck(String name, String cost, String inv, String min, String max, String dynamic) {
        if(name.isEmpty() || cost.isEmpty() || inv.isEmpty() || min.isEmpty() || max.isEmpty() || dynamic.isEmpty()) {
            missingFields();
            return false;
        }
        if(cost.matches("[a-zA-Z]+")) {
            invalidCost(cost);
            return false;
        }
        if(inv.matches("[a-zA-Z]+")) {
            invalidInv(inv);
            return false;
        }
        if(min.matches("[a-zA-Z]+")) {
            invalidMin(min);
            return false;
        }
        if(max.matches("[a-zA-Z]+")) {
            invalidMax(max);
            return false;
        }
        return true;
    }

    /**
     * Function that loads the main form FXML upon call (exiting the modify part form).
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (returning to main screen).
     */
    private void returnMainScreen(ActionEvent actionEvent) throws IOException {
        Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("MainForm.fxml")));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
}
