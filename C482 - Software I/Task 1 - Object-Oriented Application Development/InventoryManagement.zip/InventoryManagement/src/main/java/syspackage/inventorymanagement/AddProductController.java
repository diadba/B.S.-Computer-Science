package syspackage.inventorymanagement;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.Optional;
import java.util.ResourceBundle;


/**
 * Class AddProductController, that controls the logic for the Add button for the Product Table from the main screen.
 * @author Anthony Coots
 *
 * RUNTIME ERROR: error relative to input string "" in any field. If a field was blank, the integer / double conversions
 * that were previously placed outside the parameter check in the save function would attempt to parse an empty string
 * and cause error.
 */

public class AddProductController implements Initializable {
    /**
     * FXML variable for text field that takes product name input.
     */

    @FXML
    private TextField addProductNameField;

    /**
     * FXML variable for text field that takes product inventory input.
     */

    @FXML
    private TextField addProductInventoryField;

    /**
     * FXML variable for text field that takes product cost input.
     */

    @FXML
    private TextField addProductCostField;

    /**
     * FXML variable for text field that takes product minimum inventory input.
     */

    @FXML
    private TextField addProductMinField;

    /**
     * FXML variable for text field that takes product maximum inventory input.
     */

    @FXML
    private TextField addProductMaxField;

    /**
     * FXML variable for text field that is used to search for parts to add to the product.
     */

    @FXML
    private TextField partSearchBar;

    /**
     * FXML variable for table that presents all parts, that can be added, to be considered "associated".
     */

    @FXML
    private TableView<Part> addAssociatedTable;

    /**
     * FXML variable for table that presents added associated parts, that can be removed, that are no longer "associated".
     */

    @FXML
    private TableView<Part> currAssociatedTable;

    /**
     * Column in table of parts that may be added, holding the parts' identifier.
     */

    @FXML
    private TableColumn<Part, Integer> addAssociatedId;

    /**
     * Column in table of parts that have been added to the product, holding the parts' identifier.
     */

    @FXML
    private TableColumn<Part, Integer> currAssociatedId;

    /**
     * Column in table of parts that may be added, holding the parts' name.
     */

    @FXML
    private TableColumn<Part, String> addAssociatedName;

    /**
     * Column in table of parts that have been added to the product, holding the parts' name.
     */

    @FXML
    private TableColumn<Part, String> currAssociatedName;

    /**
     * Column in table of parts that may be added, holding the parts' inventory (stock).
     */

    @FXML
    private TableColumn<Part, Integer> addAssociatedInventory;

    /**
     * Column in table of parts that have been added to the product, holding the parts' inventory (stock).
     */

    @FXML
    private TableColumn<Part, Integer> currAssociatedInventory;

    /**
     * Column in table of parts that may be added, holding the parts' cost / price.
     */

    @FXML
    private TableColumn<Part, Double> addAssociatedCost;

    /**
     * Column in table of parts that have been added to the product, holding the parts' cost / price.
     */

    @FXML
    private TableColumn<Part, Double> currAssociatedCost;

    /**
     * Method that initiates a new id for the product to be
     */

    private final int newId = initNewId();

    /**
     * List of all parts, used in the parts that may be added table.
     */
    ObservableList<Part> allListed = Inventory.getAllParts();

    /**
     * Empty list, that collects parts post 'add' button use (before save).
     */
    ObservableList<Part> itemsToAdd = FXCollections.observableArrayList();

    /**
     * Function that is called upon to initiate the add product screen. Everytime the screen is initiated, so are the
     * all parts table and the empty table of parts later added.
     * @param url path location.
     * @param resourceBundle source through root.
     */

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        System.out.println("AddPartController.java called successfully.");

        initAddTable();
        initCurrTable();
    }

    /**
     * FXML related function that adds the associated part, via add button under all parts table, to the item to be
     * associated parts list.
     */
    public void addAssociatedClicked() {
        Part selection = addAssociatedTable.getSelectionModel().getSelectedItem();

        if (selection != null) {
            if (itemsToAdd.contains(selection)) associatedExists();
            else itemsToAdd.add(selection);
        }
        else selectAssociated();
    }

    /**
     * FXML related function that returns to main screen, not adding any of the input / does not make a product.
     * The process of product making is cancelled.
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (returning to main screen).
     */
    public void addPartCancelClicked(ActionEvent actionEvent) throws IOException {
        returnMainScreen(actionEvent);
    }

    /**
     * FXML related function that saves the product, or alerts user why a product cannot be added (invalid / missing input).
     * @param actionEvent required for action load.
     */
    public void addSaveClicked(ActionEvent actionEvent) {
        String productName      = addProductNameField.getText();
        String productCost      = addProductCostField.getText();
        String productInv       = addProductInventoryField.getText();
        String productMin       = addProductMinField.getText();
        String productMax       = addProductMaxField.getText();

        try {
            if(paramCheck(productName, productCost, productInv, productMin, productMax)) {
                if (invCheck(productInv, productMin, productMax)) {
                    int newInv = Integer.parseInt(productInv);
                    int newMin = Integer.parseInt(productMin);
                    int newMax = Integer.parseInt(productMax);
                    double newCost = Double.parseDouble(productCost);

                    Product productToAdd = new Product(newId, productName, newCost, newInv, newMin, newMax);

                    for (Part items : itemsToAdd) {
                        productToAdd.addAssociatedParts(items);
                    }

                    Inventory.addProduct(productToAdd);
                    returnMainScreen(actionEvent);
                }
            }
        } catch (Exception e) {
            invalidFields();
        }
    }

    /**
     * Function that returns alert that a part intended to be added already exists in the associated parts to be list.
     */
    private void associatedExists() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("PART NOT ADDED");
        alert.setContentText("Part is already associated with product.");
        alert.showAndWait();
    }

    /**
     * Function that alerts user that no part was selected in the all parts table.
     */
    public void highlightError() {
        String confirmation = "No part selected. Please try again.";

        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("No part highlighted");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }

    /**
     * Function that loads the table containing all parts that may be added.
     */
    public void initAddTable() {
        addAssociatedTable.setItems(allListed);
        addAssociatedId.setCellValueFactory(new PropertyValueFactory<>("id"));
        addAssociatedName.setCellValueFactory(new PropertyValueFactory<>("name"));
        addAssociatedInventory.setCellValueFactory(new PropertyValueFactory<>("stock"));
        addAssociatedCost.setCellValueFactory(new PropertyValueFactory<>("price"));
        addAssociatedCost.setCellFactory(cell -> new TableCell<>() {
            @Override
            protected void updateItem(Double cost, boolean empty) {
                super.updateItem(cost, empty);
                if (cost == null || empty) {
                    setText(null);
                } else {
                    setText(String.format("%.2f", cost));
                }
            }
        });
    }

    /**
     * Function that loads the table containing all parts that have be added (before save).
     */
    public void initCurrTable() {
        currAssociatedTable.setItems(itemsToAdd);

        currAssociatedId.setCellValueFactory(new PropertyValueFactory<>("id"));
        currAssociatedName.setCellValueFactory(new PropertyValueFactory<>("name"));
        currAssociatedInventory.setCellValueFactory(new PropertyValueFactory<>("stock"));
        currAssociatedCost.setCellValueFactory(new PropertyValueFactory<>("price"));
        currAssociatedCost.setCellFactory(cell -> new TableCell<>() {
            @Override
            protected void updateItem(Double cost, boolean empty) {
                super.updateItem(cost, empty);
                if (cost == null || empty) {
                    setText(null);
                } else {
                    setText(String.format("%.2f", cost));
                }
            }
        });
    }

    /**
     * Integer function to auto generate a new id for the new product being created.
     * @return the newly auto generated identifier.
     */

    private int initNewId() {
        Product tempProd = null;
        for (Product comparable : Inventory.getAllProducts()) {
            tempProd = comparable;
        }
        assert tempProd != null;
        return tempProd.getId() + 1;
    }

    /**
     * Function that takes the string that caused the function to be called and makes a visible alert that the cost
     * text field data is invalid and must be modified.
     * @param errorValue is the string value causing the function to be called, input data, tested on, must be modified.
     */
    public void invalidCost(String errorValue) {
        String confirmation = "Invalid price / cost value input \"" + errorValue +"\". Please try again.";

        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("Invalid price / cost");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }

    /**
     * Function if any of the text fields contain invalid data upon saving to display an alert notifying user of such.
     */
    private void invalidFields() {
        String confirmation = "Invalid values. Please try again.";

        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("Invalid input in fields.\n\nNOTE: Min should be less than max; and Inv should be between those two values.\nMin and Max should be greater than or equal to 0.");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }

    /**
     * Function that takes the inventory string and makes a visible alert that the inventory text field data is invalid
     * and must be modified.
     * @param errorValue is the string value causing the function to be called, input data, tested on, must be modified.
     */
    public void invalidInv(String errorValue) {
        String confirmation = "Invalid inv input \"" + errorValue +"\". Please try again.";

        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("Invalid inventory");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }

    /**
     * Function that takes the maximum inventory string and makes a visible alert that the inventory text field data is
     * invalid and must be modified.
     * @param errorValue is the string value causing the function to be called, input data, tested on, must be modified.
     */
    public void invalidMax(String errorValue) {
        String confirmation = "Invalid max value input \"" + errorValue +"\". Please try again.";

        System.out.println("hi");
        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("Invalid maximum");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }

    /**
     * Function that takes the minimum inventory string and makes a visible alert that the inventory text field data is
     * invalid and must be modified.
     * @param errorValue is the string value causing the function to be called, input data, tested on, must be modified.
     */
    public void invalidMin(String errorValue) {
        String confirmation = "Invalid min value input \"" + errorValue +"\". Please try again.";

        System.out.println("hi");
        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("Invalid minimum");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }

    /**
     * Additional T/F function that checks input integrity by comparing the inventory, minimum and maximum values to see if
     * the minimum and maximum is a non-negative integer and if the inventory is within the minimum and maximum bounds. (Inclusive).
     * @param inv inventory string then converted to an integer.
     * @param min inventory string then converted to an integer.
     * @param max inventory string then converted to an integer.
     * @return true if the inventory, minimum and maximum fields are valid. else false, but giving an alert.
     */
    public boolean invCheck(String inv, String min, String max) {
        int checkInv = Integer.parseInt(inv);
        int checkMin = Integer.parseInt(min);
        int checkMax = Integer.parseInt(max);

        if(checkMin >= 0 && checkMax >= 0 && checkInv >= checkMin && checkInv <= checkMax) {
            return true;
        }
        else {
            invalidFields();
            return false;
        }
    }

    /**
     * Function to check if certain input is numeric (where certain fields do not take numeric values).
     * @param string the string of respective fields to be checked for numeric value.
     * @return true of false, condition works on called logic.
     */
    private boolean isNumeric(String string) {
        return string != null && string.matches("[-+]?\\d*\\.?\\d+");
    }


    /**
     * Function if any of the text fields are empty (not populated with data) to display an alert notifying user of such.
     */
    public void missingFields() {
        String confirmation = "One or more fields with no value. Please try again.";

        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("Missing fields.");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }

    /**
     * If the user input in the search box text field does not match and parts, then the user is alerted.
     * @param string is of value inserted into the search box text field.
     */
    private void noVal(String string) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("No results");
        alert.setContentText("No results found in search \"" + string + "\"");
        alert.showAndWait();
    }

    /**
     * Function that given the product's name, cost, inventory, minimum and maximum inventory input, will execute multiple
     * checks to confirm the input is valid so the form can be saved (the part added). If input fails during a certain check,
     * a certain error is shown for the respective field where the error occurred. The list of added parts is officially
     * added to the product's associated parts.
     * @param name product's name input.
     * @param cost product's cost / price input.
     * @param inv product's inventory input.
     * @param min product's minimum inventory input.
     * @param max product's maximum inventory input.
     * @return if the input is valid, the boolean function returns true where called, meaning the form may proceed.
     * and if false, the form has invalid fields and will not proceed.
     */
    public boolean paramCheck(String name, String cost, String inv, String min, String max) {
        if(name.isEmpty() || cost.isEmpty() || inv.isEmpty() || min.isEmpty() || max.isEmpty()) {
            missingFields();
            return false;
        }
        if(cost.matches("[a-zA-Z]+")) {
            invalidCost(cost);
            return false;
        }
        if(inv.matches("[a-zA-Z]+")) {
            invalidInv(inv);
            return false;
        }
        if(min.matches("[a-zA-Z]+")) {
            invalidMin(min);
            return false;
        }
        if(max.matches("[a-zA-Z]+")) {
            invalidMax(max);
            return false;
        }
        return true;
    }

    /**
     * FXML related function that uses the text field as a search box, giving results relative to the text inputted,
     * if only one result, the result is highlighted.
     */
    public void partSearchWord() {
        ObservableList<Part> partTemp = FXCollections.observableArrayList();
        addAssociatedTable.getSelectionModel().clearSelection();

        if (partSearchBar.getText().isEmpty()) {
            addAssociatedTable.setItems(Inventory.getAllParts());
        } else if (partSearchBar.getText().length() > 0) {
            boolean isNum = isNumeric(partSearchBar.getText());
            if (isNum) {
                int i = Integer.parseInt(partSearchBar.getText());
                partTemp.add(Inventory.lookupPart(i));

                if(Inventory.lookupPart(i) == null) {
                    noVal(partSearchBar.getText());}
                else { addAssociatedTable.setItems(partTemp); }
            }
            else {
                partTemp = Inventory.lookupPart(partSearchBar.getText());

                if(partTemp.isEmpty()) { noVal(partSearchBar.getText());}
                else {
                    addAssociatedTable.setItems(partTemp);

                    if (partTemp.size() == 1) {
                        addAssociatedTable.getSelectionModel().selectFirst();
                    }
                }
            }
        }
    }

    /**
     * FXML related function that removes an associated part, via remove button under added parts table, from the added
     * parts table.
     */
    public void removeAssociatedClicked() {
        Part selection = currAssociatedTable.getSelectionModel().getSelectedItem();

        if(selection == null) {
            highlightError();
        }
        else {
            removeConfirmation(selection);
            currAssociatedTable.setItems(itemsToAdd);
        }
    }

    /**
     * Function that awaits second approval from user that the highlighted part is ok to remove from the added parts
     * table.
     * @param part the part that is to be removed pending approval.
     */

    public void removeConfirmation(Part part) {
        String confirmation = "This will remove the selected part from product.";

        ButtonType confirm = new ButtonType("Ok");
        ButtonType cancel = new ButtonType("Cancel");
        Alert alert = new Alert(Alert.AlertType.WARNING, confirmation, confirm, cancel);
        alert.setTitle("Confirm");
        alert.setHeaderText("Remove part from product?");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        Optional<ButtonType> buttonSet = alert.showAndWait();
        buttonSet.ifPresent(selection -> {
            if (selection.equals(confirm)) {
                itemsToAdd.remove(part);
            } else if (selection.equals(cancel)) {
                System.out.println("returning...");
            }
        });
    }

    /**
     * Function that returns to main screen.
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (returning to main screen).
     */
    private void returnMainScreen(ActionEvent actionEvent) throws IOException {
        Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("MainForm.fxml")));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Function that returns alert that intention to add a part cannot happen because no part is selected.
     */
    private void selectAssociated() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("PART NOT ADDED");
        alert.setContentText("No associated part selected.");
        alert.showAndWait();
    }
}
