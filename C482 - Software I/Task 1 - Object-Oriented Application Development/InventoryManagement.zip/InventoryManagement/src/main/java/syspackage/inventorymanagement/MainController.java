package syspackage.inventorymanagement;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Class that controls the logic for the main screen of the application.
 * @author Anthony Coots
 *
 * FUTURE ENHANCEMENT: Relative to Main.java, be able to move the alerts out of each class and reference seperately
 * as the alerts make up most of the code within this class.
 */

public class MainController implements Initializable {
    /**
     * FXML variable for all Parts table.
     */

    @FXML
    private TableView<Part> tablePart;

    /**
     * FXML variable for all Products table.
     */

    @FXML
    private TableView<Product> tableProduct;

    /**
     * Column in table of all parts, holding the parts' identifier.
     */

    @FXML
    private TableColumn<Part, Integer> partID;

    /**
     * Column in table of all products, holding the parts' identifier.
     */

    @FXML
    private TableColumn<Product, Integer> productID;

    /**
     * Column in table of all parts, holding the parts' name.
     */

    @FXML
    private TableColumn<Part, String> partName;

    /**
     * Column in table of all products, holding the products' name.
     */

    @FXML
    private TableColumn<Product, String> productName;

    /**
     * Column in table of all parts, holding the parts' inventory (stock).
     */

    @FXML
    private TableColumn<Part, Integer> partInventory;

    /**
     * Column in table of all products, holding the products' inventory (stock).
     */

    @FXML
    private TableColumn<Product, Integer> productInventory;

    /**
     * Column in table of all parts, holding the parts' cost / price.
     */

    @FXML
    private TableColumn<Part, Double> partCost;

    /**
     * Column in table of all products, holding the products' cost / price.
     */

    @FXML
    private TableColumn<Product, Double> productCost;

    /**
     * FXML variable that acts as search bar over the all parts table.
     */

    @FXML
    private TextField partSearchBar;

    /**
     * FXML variable that acts as search bar over the all products table.
     */

    @FXML
    private TextField productSearchBar;

    /**
     * variable initialized to hold a part when set.
     */
    private static Part currentPart;

    /**
     * variable initialized to hold a product when set.
     */
    private static Product currentProduct;

    /**
     * Function that initiates the main screen, that oversees multiple buttons and two tables.
     * @param url path location.
     * @param resourceBundle source through root.
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        System.out.println("I am initialized, MainController.java called successfully.");

        initPartTable();
        initProductTable();
    }

    /**
     * Function that loads the add part form when the add button under the parts table is clicked.
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (Load add part form).
     */
    public void addPartButtonClicked(ActionEvent actionEvent) throws IOException {
        Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("AddPartForm.fxml")));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Function that loads the add product form when the add button under the products table is clicked.
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (Load add product form).
     */
    public void addProductButtonClicked(ActionEvent actionEvent) throws IOException {
        Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("AddProductForm.fxml")));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
    /**
     * Alert that appears notifying that a user must delete a products associated parts before the product can be
     * deleted.
     */
    public void deleteAssociatedFirst() {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("CANNOT DELETE PRODUCT");
        alert.setContentText("This product has associated parts. Please remove associated parts and try again.");
        alert.showAndWait();
    }

    /**
     * Function that alerts user that no part / product has been deleted because none was highlighted
     */
    public void deleteNotice() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("NULL");
        alert.setContentText("No part / product highlighted, no delete occurred.");
        alert.showAndWait();
    }

    /**
     * Function that handles the parts table when the delete button has been pressed.
     */
    public void deletePartButtonClicked() {
        Part toRemove  = tablePart.getSelectionModel().getSelectedItem();

        if(toRemove == null) {
            deleteNotice();
        }
        else {
            String confirmation = "This will remove the selected product from inventory.";

            ButtonType confirm = new ButtonType("Ok");
            ButtonType cancel = new ButtonType("Cancel");
            Alert alert = new Alert(Alert.AlertType.WARNING, confirmation, confirm, cancel);
            alert.setTitle("Confirm");
            alert.setHeaderText("Delete part?");

            Window window = alert.getDialogPane().getScene().getWindow();
            window.setOnCloseRequest(event -> alert.hide());

            Optional<ButtonType> buttonSet = alert.showAndWait();
            buttonSet.ifPresent(selection -> {
                if (selection.equals(confirm)) {
                    Inventory.deletePart(toRemove);
                    tablePart.setItems(Inventory.getAllParts());
                } else if (selection.equals(cancel)) {
                    System.out.println("returning...");
                }
            });
        }
    }

    /**
     * Function that handles the products table when the delete button is clicked.
     */
    public void deleteProductButtonClicked() {
        Product toRemove  = tableProduct.getSelectionModel().getSelectedItem();

        if(toRemove == null) {
            deleteNotice();
        }
        else if (toRemove.getAllAssociatedParts().size() > 0) {
            deleteAssociatedFirst();
        }
        else {
            String confirmation = "This will remove the selected product from inventory.";

            ButtonType confirm = new ButtonType("Ok");
            ButtonType cancel = new ButtonType("Cancel");
            Alert alert = new Alert(Alert.AlertType.WARNING, confirmation, confirm, cancel);
            alert.setTitle("Confirm");
            alert.setHeaderText("Delete part?");

            Window window = alert.getDialogPane().getScene().getWindow();
            window.setOnCloseRequest(event -> alert.hide());

            Optional<ButtonType> buttonSet = alert.showAndWait();
            buttonSet.ifPresent(selection -> {
                if (selection.equals(confirm)) {
                    Inventory.deleteProduct(toRemove);
                    tableProduct.setItems(Inventory.getAllProducts());
                } else if (selection.equals(cancel)) {
                    System.out.println("returning...");
                }
            });
        }
    }

    /**
     * Function that closes the application upon the exit program button being clicked.
     */
    public void exitButtonClicked() {
        System.exit(0);
    }

    /**
     * Function that returns the highlighted part.
     * @return currentPart
     */
    public static Part getCurrentPart() {
        return currentPart;
    }

    /**
     * Function that returns the highlighted part.
     * @return currentProduct
     */
    public static Product getCurrentProduct() {
        return currentProduct;
    }

    /**
     * Function that loads and sets the table containing all parts upon main screen initialization.
     */
    public void initPartTable() {
        tablePart.setItems(Inventory.getAllParts());
        partID.setCellValueFactory(new PropertyValueFactory<>("id"));
        partName.setCellValueFactory(new PropertyValueFactory<>("name"));
        partInventory.setCellValueFactory(new PropertyValueFactory<>("stock"));
        partCost.setCellValueFactory(new PropertyValueFactory<>("price"));
        partCost.setCellFactory(cell -> new TableCell<>() {
            @Override
            protected void updateItem(Double cost, boolean empty) {
                super.updateItem(cost, empty);
                if (cost == null || empty) {
                    setText(null);
                } else {
                    setText(String.format("%.2f", cost));
                }
            }
        });

    }

    /**
     * Function that loads and sets the table containing all products upon main screen initialization.
     */
    public void initProductTable() {
        tableProduct.setItems(Inventory.getAllProducts());
        productID.setCellValueFactory(new PropertyValueFactory<>("id"));
        productName.setCellValueFactory(new PropertyValueFactory<>("name"));
        productInventory.setCellValueFactory(new PropertyValueFactory<>("stock"));
        productCost.setCellValueFactory(new PropertyValueFactory<>("price"));
        productCost.setCellFactory(cell -> new TableCell<>() {
            @Override
            protected void updateItem(Double cost, boolean empty) {
                super.updateItem(cost, empty);

                if (cost == null || empty) {
                    setText(null); }
                else { setText(String.format("%.2f", cost)); }
            }
        });
    }

    /**
     * Function to check if certain input is numeric (where certain fields do not take numeric values).
     * @param string the string of respective fields to be checked for numeric value.
     * @return true of false, condition works on called logic.
     */
    public boolean isNumeric(String string) {
        return string != null && string.matches("[-+]?\\d*\\.?\\d+");
    }

    /**
     * Function that alerts user that no part or product has been selected (highlighted) to modify.
     */
    private void modifyNotice() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("NULL");
        alert.setContentText("No part / product highlighted, cannot modify.");
        alert.showAndWait();
    }

    /**
     * Function that loads the modify part form when the modify button under the parts table is clicked.
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (Load modify part form).
     */
    public void modifyPartButtonClicked(ActionEvent actionEvent) throws IOException {
        currentPart = tablePart.getSelectionModel().getSelectedItem();

        if(currentPart == null) {
            modifyNotice();
        }
        else {
            Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("ModifyPartForm.fxml")));
            Scene scene = new Scene(parent);
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        }
    }

    /**
     * Function that loads the modify product form when the modify button under the product table is clicked.
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (Load modify product form).
     */
    public void modifyProductButtonClicked(ActionEvent actionEvent) throws IOException {
        currentProduct = tableProduct.getSelectionModel().getSelectedItem();

        if(currentProduct == null) {
            modifyNotice();
        }
        else {
            Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("ModifyProductForm.fxml")));
            Scene scene = new Scene(parent);
            Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        }
    }

    /**
     * Function that alerts user there is no part / product containing input characters.
     * @param string string of characters that resulted in no match.
     */
    public void noVal(String string) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("No results");
        alert.setContentText("No results found in search \"" + string + "\"");
        alert.showAndWait();
    }

    /**
     * Function that is interactive as a text field, searches for parts relative to key input of the table containing
     * all parts.
     */
    public void partSearchWord() {
        ObservableList<Part> partTemp = FXCollections.observableArrayList();
        tablePart.getSelectionModel().clearSelection();


        if (partSearchBar.getText().isEmpty()) {
            tablePart.setItems(Inventory.getAllParts());
        } else if (partSearchBar.getText().length() > 0) {
            boolean isNum = isNumeric(partSearchBar.getText());
            if (isNum) {
                int i = Integer.parseInt(partSearchBar.getText());
                partTemp.add(Inventory.lookupPart(i));

                if(Inventory.lookupPart(i) == null) {
                    noVal(partSearchBar.getText());}
                else {
                    tablePart.setItems(partTemp);
                    if(partTemp.size() == 1) {
                        tablePart.getSelectionModel().selectFirst();
                    }
                }
            }
            else {
                partTemp = Inventory.lookupPart(partSearchBar.getText());

                if(partTemp.isEmpty()) { noVal(partSearchBar.getText());}
                else {
                    tablePart.setItems(partTemp);
                    if (partTemp.size() == 1) {
                        tablePart.getSelectionModel().selectFirst();
                    }
                }
            }
        }
    }

    /**
     * Function that is interactive as a text field, searches for products relative to key input of the table containing
     * all products.
     */
    public void productSearchWord() {
        ObservableList<Product> prodTemp = FXCollections.observableArrayList();
        tableProduct.getSelectionModel().clearSelection();

        if (productSearchBar.getText().isEmpty()) {
            tableProduct.setItems(Inventory.getAllProducts());
        } else if (productSearchBar.getText().length() > 0) {
            boolean isNum = isNumeric(productSearchBar.getText());
            if (isNum) {
                int i = Integer.parseInt(productSearchBar.getText());
                prodTemp.add(Inventory.lookupProduct(i));

                if(Inventory.lookupProduct(i) == null) {
                    noVal(productSearchBar.getText());}
                else {
                    tableProduct.setItems(prodTemp);
                    if (prodTemp.size() == 1) {
                        tableProduct.getSelectionModel().selectFirst();
                    }
                }
            }
            else {
                prodTemp = Inventory.lookupProduct(productSearchBar.getText());

                if(prodTemp.isEmpty()) { noVal(productSearchBar.getText());}
                else {
                    tableProduct.setItems(prodTemp);
                    if (prodTemp.size() == 1) {
                        tableProduct.getSelectionModel().selectFirst();
                    }
                }
            }
        }
    }
}




