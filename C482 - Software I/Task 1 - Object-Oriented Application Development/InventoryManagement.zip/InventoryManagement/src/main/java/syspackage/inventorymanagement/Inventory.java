package syspackage.inventorymanagement;

import javafx.collections.FXCollections;                            // for both Part and Product list.
import javafx.collections.ObservableList;                           // for both Part and Product List.

/**
 * Class for object(s) 'Inventory'; Class with two lists of objects of alternative classes. Makes use of many methods
 * to update 'Product' and 'Part' within an 'Inventory'.
 * @author Anthony Coots
 *
 * FUTURE ENHANCEMENT: remove curly braces where not necessarily required, more reader friendly.
 */

public class Inventory {
    /* - (private) allParts:ObservableList<Part> */
    private static ObservableList<Part> allParts = FXCollections.observableArrayList();
    /* - allProducts:ObservableList<Product> */
    private static ObservableList<Product> allProducts = FXCollections.observableArrayList();

    /* + addPart(newPart:Part):void */
    /**
     * Add a new part to the current observable list.
     * @param newPart
     */
    public static void addPart(Part newPart)
    {
        allParts.add(newPart);
    }

    /* + addProduct(newProduct:Product):void */
    /**
     * Add a new product to the current observable allProducts list.
     * @param newProduct
     */
    public static void addProduct(Product newProduct)
    {
        allProducts.add(newProduct);
    }

    /* + lookupPart(partId:int):Part */
    /**
     * Searches for part relative to the given partId upon call.
     * @param partID
     * @return product
     */
    public static Part lookupPart(int partID)
    {
        for(Part part : Inventory.getAllParts())             // developed post getAllParts(), organized for UML diagram.
        {
            if(part.getId() == partID)
            {
                return part;
            }
        }
        return null;
    }

    /* + lookupProduct(productId:int):Product */
    /**
     * Searches for product relative to the given productId upon call.
     * @param productId
     * @return product
     * NOTE: different from other lookupPart function.
     */
    public static Product lookupProduct(int productId)
    {
        for(Product product : Inventory.getAllProducts())    // developed post getAllParts(), organized for UML diagram.
        {
            if(product.getId() == productId)
            {
                return product;
            }
        }
        return null;
    }

    /* + lookupPart(partName:String):ObservableList<Part> */
    /**
     * Searches for part(s) relative to the given partName upon call.
     * @param partName
     * @return temp
     * NOTE: different from other lookupPart function.
     */
    public static ObservableList<Part> lookupPart(String partName)
    {
        ObservableList<Part> temp =  FXCollections.observableArrayList();   // makes the new temporary list.

        for(Part part: allParts)
        {
            if(part.getName().contains(partName))
            {
                temp.add(part);                                             // add item to list if item in original list
            }                                                               // contains string sequence.
        }
        return temp;
    }

    /* + lookupProduct(partName:String):ObservableList<Product> */
    /**
     * Searches for product(s) relative to the given productName upon call.
     * @param productName
     * @return temp
     *
     */
    public static ObservableList<Product> lookupProduct(String productName)
    {
        ObservableList<Product> temp =  FXCollections.observableArrayList();

        for(Product product: allProducts)
        {
            if(product.getName().contains(productName))
            {
                temp.add(product);
            }
        }
        return temp;
    }

    /* updatePart(index:int, selectedPart:Part):void */
    /**
     * Update / replace a part at a given index with a new part object made.
     * @param index
     * @param selectedPart
     */
    public static void updatePart(int index, Part selectedPart)
    {
        allParts.set(index, selectedPart);                          // set is a simple 'update' command...
    }

    /* updateProduct(index:int, selectedProduct:Product):void */
    /**
     * Update / replace a product at a given index with a new product object made.
     * @param index
     * @param selectedProduct
     * NOTE: same function as updatePart, copy and pasted, updated appropriately..
     */
    public static void updateProduct(int index, Product selectedProduct)
    {
        allProducts.set(index, selectedProduct);
    }

    /* + deletePart(selectedPart:Part):boolean */
    /**
     * Deletes a 'Part' object from the respective list in the 'Inventory'.
     * @param selectedPart
     * @return boolean
     */
    public static boolean deletePart(Part selectedPart)
    {
        boolean status = true;
        if(allParts.contains(selectedPart))
        {
            allParts.remove(selectedPart);
        }
        else
        {
            status = false;
        }
        return status;
    }

    /* + deleteProduct(selectedProduct:Product):boolean */
    /**
     * Deletes a 'Product' object from the list in the 'Inventory'.
     * @param selectedProduct
     * @return boolean
     * NOTE: copy-paste previous function changed appropriately.
     * forgot to change allParts to allProducts!
     */
    public static boolean deleteProduct(Product selectedProduct)
    {
        boolean status = true;
        if(allProducts.contains(selectedProduct))
        {
            allProducts.remove(selectedProduct);
        }
        else
        {
            status = false;
        }
        return status;
    }

    /* + getAllParts():ObservableList<Part> */
    /**
     * Static list of all 'Part' objects in single inventory.
     * @return allParts list.
     */
    public static ObservableList<Part> getAllParts()
    {
        return allParts;
    }

    /* + getAllProducts():ObservableList<Product> */
    /**
     * Static list of all 'Product' objects in single inventory.
     * @return allProducts list.
     */
    public static ObservableList<Product> getAllProducts()
    {
        return allProducts;
    }
}