package syspackage.inventorymanagement;
/**
 * Class AddProductController, that controls the logic for the Add button for the Product Table from the main screen.
 * @author Anthony Coots
 *
 * InHouse class with abstract Part inheritance.
 *
 * RUNTIME ERROR: price field accidentally declared as integer would output doubles (I.E. 7.77) as integers (7,
 * decimal values where truncated.
 */

public class InHouse extends Part
{
    /**
     * machine identifier as specified in the 'UML Class Diagram' pdf.
     */
    private int machineId;
    // + (public) InHouse(id : int, name : String, price : double, stock : int, min : int, max : int, machineId : int)

    /**
     * Constructor for object defining identifier, name, price, inventory, minimum and maximum inventory bounds and
     * machine ID.
     * @param id In-House part integer identifier.
     * @param name In-House part name.
     * @param price In-House part price / cost.
     * @param stock In-House part inventory.
     * @param min In-House part minimum inventory.
     * @param max In-House part maximum inventory.
     * @param machineId In-House part machine ID.
     */
    public InHouse(int id, String name, double price, int stock, int min, int max, int machineId)
    {
        super(id, name, price, stock, min, max);
        this.machineId = machineId;
    }

    /**
     * Setter that sets the machine ID if called.
     * @param machineId machine ID integer needed to set this objects machine ID.
     */
    public void setMachineId(int machineId)
    {
        this.machineId = machineId;
    }

    /**
     * Getter that returns the specific objects' machine ID.
     * @return In-House objects' machine ID.
     */
    public int getMachineId()
    {
        return machineId;
    }
}