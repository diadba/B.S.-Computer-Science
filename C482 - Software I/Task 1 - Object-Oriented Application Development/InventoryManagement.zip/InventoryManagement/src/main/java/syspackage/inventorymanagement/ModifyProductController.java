package syspackage.inventorymanagement;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * Class that controls the logic for the modify product screen.
 * @author Anthony Coots
 *
 * RUNTIME ERROR: Excessive time was spent (~ 5 days) on implementing the observable lists correctly
 * such that if a user cancelled, the list remained unchanged. Prior to that was a static error in the Product.java
 * class that would set all Products associated parts list the same. Future 'enhancement' would be to take more time.
 * Multiple in line comments and system out put was implemented to notify the process of what resided in the lists.
 */

public class ModifyProductController implements Initializable {
    /**
     * FXML variable to set foundation for a table containing all parts.
     */

    @FXML
    private TableView<Part> allPartsTableView;

    /**
     * FXML variable for table containing all parts setting the identifier column.
     */

    @FXML
    private TableColumn<Part, Integer> allIdColumn;

    /**
     * FXML variable for table containing all parts setting the name column.
     */

    @FXML
    private TableColumn<Part, String> allNameColumn;

    /**
     * FXML variable for table containing all parts setting the inventory (stock) column.
     */

    @FXML
    private TableColumn<Part, Integer> allInvColumn;

    /**
     * FXML variable for table containing all parts setting the cost / price column.
     */

    @FXML
    private TableColumn<Part, Double> allCostColumn;

    /**
     * FXML variable to set foundation for a table containing added parts new or existing.
     */

    @FXML
    private TableView<Part> currentPartsTableView;

    /**
     * FXML variable for table containing added or existing parts setting the identifier column.
     */

    @FXML
    private TableColumn<Part, Integer> currentIdColumn;

    /**
     * FXML variable for table containing added or existing parts setting the name column.
     */

    @FXML
    private TableColumn<Part, String> currentNameColumn;

    /**
     * FXML variable for table containing added or existing parts setting the inventory (stock) column.
     */

    @FXML
    private TableColumn<Part, Integer> currentInvColumn;

    /**
     * FXML variable for table containing added or existing parts setting the cost / price column.
     */

    @FXML
    private TableColumn<Part, Double> currentCostColumn;

    /**
     * FXML variable responsible for displaying the products ID.
     */

    @FXML
    private TextField modifyProductIdField;

    /**
     * FXML variable responsible for taking input the products name.
     */

    @FXML
    private TextField modifyProductNameField;

    /**
     * FXML variable responsible for taking input the products inventory (stock).
     */

    @FXML
    private TextField modifyProductInventoryField;

    /**
     * FXML variable responsible for taking input the products cost / price.
     */

    @FXML
    private TextField modifyProductCostField;

    /**
     * FXML variable responsible for taking input the products minimum inventory (stock).
     */

    @FXML
    private TextField modifyProductMinField;

    /**
     * FXML variable responsible for taking input the products maximum inventory (stock).
     */

    @FXML
    private TextField modifyProductMaxField;

    /**
     * FXML variable text field used as a search box for all parts, these parts are then added to associated parts.
     */

    @FXML
    private TextField allSearchField;

    /**
     * List containing all parts in the inventory a product can associate.
     */
    ObservableList<Part> allPartsOfProgram = FXCollections.observableArrayList();

    /**
     * List containing a products pre associated parts.
     */
    ObservableList<Part> selectedProductAssociated = FXCollections.observableArrayList();

    /**
     * List made to add all items, existing and added parts, before a user attempts to save, if a user cancels, the parts
     * added at the moment then unsaved will not affect the current products existing parts.
     */
    ObservableList<Part> preSaveList = FXCollections.observableArrayList();

    /**
     * The variable selected from the main screen to modify.
     */
    Product mainSelectedProduct;

    /**
     * Function that is called upon to initiate the modify product screen. The objects current class sets the radio button.
     * @param url path location.
     * @param resourceBundle source through root.
     */

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        System.out.println("-------------------------------------------------------------------------------------");
        System.out.println("Clearing preSaveList...");
        System.out.println("preSaveList: " + preSaveList);
        System.out.println("Cleared!");
        System.out.println("-------------------------------------------------------------------------------------");

        System.out.println("loaded successfully from MainController.java...");
        allPartsOfProgram = Inventory.getAllParts();
        System.out.println("All parts: " + allPartsOfProgram);

        mainSelectedProduct = MainController.getCurrentProduct();
        System.out.println("Product selected: " + mainSelectedProduct.getName() + "\n");

        ObservableList<Part> selectedAssociatedParts = mainSelectedProduct.getAllAssociatedParts();
        System.out.println(mainSelectedProduct.getName() + "'s associated parts: " + selectedAssociatedParts + "\n");

        System.out.println("Initializing the 'ADD ASSOCIATED PARTS' table...");
        System.out.println("Preparing ID column...");
        allIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        System.out.println("Preparing name column...");
        allNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        System.out.println("Preparing inventory column...");
        allInvColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        System.out.println("Preparing price column...");
        allCostColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        System.out.println("Formatting price column...");
        allCostColumn.setCellFactory(cell -> new TableCell<>() {
            @Override
            protected void updateItem(Double cost, boolean empty) {
                super.updateItem(cost, empty);
                if (cost == null || empty) {
                    setText(null);
                } else {
                    setText(String.format("%.2f", cost));
                }
            }
        });
        System.out.println("Columns loaded, setting table with all parts in program.");
        allPartsTableView.setItems(allPartsOfProgram);
        System.out.println(".\n.\n.");
        System.out.println("Table " + allPartsTableView.getId() + " set with " + allPartsTableView.getItems().size() + " items.\n");

        selectedProductAssociated = mainSelectedProduct.getAllAssociatedParts();
        System.out.print(selectedProductAssociated.size() + " parts are associated with product: " + mainSelectedProduct.getName() + ", ");
        System.out.println(selectedProductAssociated);

        System.out.println("Initializing the " + mainSelectedProduct.getName() + "'s 'ASSOCIATED PARTS' table...");
        System.out.println("-------------------------------------------------------------------------------------");
        System.out.println("Table set to data yet to be saved, initialized with data existing relative to product");
        System.out.println("-------------------------------------------------------------------------------------");

        ObservableList<Part> tempCheck;
        // if there are no associated parts, then use clear list to initiate current associated parts table load.
        if(selectedProductAssociated.isEmpty()) tempCheck = preSaveList;
        // else, there are currently associated parts, initiate table load with the currently associated parts.
        else tempCheck = selectedAssociatedParts;

        currentPartsTableView.setItems(tempCheck);

        System.out.println("Preparing ID column...");
        currentIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        System.out.println("Preparing name column...");
        currentNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        System.out.println("Preparing inventory column...");
        currentInvColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        System.out.println("Preparing price column...");
        currentCostColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        System.out.println("Formatting price column...");
        currentCostColumn.setCellFactory(cell -> new TableCell<>() {
            @Override
            protected void updateItem(Double cost, boolean empty) {
                super.updateItem(cost, empty);
                if (cost == null || empty) {
                    setText(null);
                } else {
                    setText(String.format("%.2f", cost));
                }
            }
        });
        System.out.println("Columns loaded, setting table with all parts in program.");
        allPartsTableView.setItems(allPartsOfProgram);
        System.out.println(".\n.\n.");
        System.out.println("Table " + currentPartsTableView.getId() + " set with " + currentPartsTableView.getItems().size() + " items.\n");

        System.out.println("Setting form data...");
        System.out.println("Converting values to String...");
        String mainId = String.valueOf(mainSelectedProduct.getId());
        String mainName = mainSelectedProduct.getName();
        String mainInv = String.valueOf(mainSelectedProduct.getStock());
        String mainCost = String.valueOf(mainSelectedProduct.getPrice());
        String mainMin = String.valueOf(mainSelectedProduct.getMin());
        String mainMax = String.valueOf(mainSelectedProduct.getMax());

        System.out.println("Conversion successful...");
        modifyProductIdField.setText(mainId);
        modifyProductNameField.setText(mainName);
        modifyProductInventoryField.setText(mainInv);
        modifyProductCostField.setText(mainCost);
        modifyProductMinField.setText(mainMin);
        modifyProductMaxField.setText(mainMax);

        System.out.println("Interactive form set with pre-existing data, please make use of form buttons.");
        preSaveList.addAll(selectedProductAssociated);
    }

    /**
     * Text field used as a search box to search of all products (to add).
     */

    public void allSearchText() {
        allPartsTableView.getSelectionModel().clearSelection();

        System.out.print("Declaring variable 'search'");
        String search = allSearchField.getText();
        System.out.println("'search' set with: " + search);

        System.out.println("Declaring temporary search result list 'resultList'...");
        ObservableList<Part> resultList = FXCollections.observableArrayList();
        System.out.println("'resultList' set to empty, editable list.");

        if (allSearchField.getText().isEmpty()) {
            System.out.println("Search field empty, returning all parts of " + allPartsTableView.getId() + ".");
            allPartsTableView.setItems(allPartsOfProgram);
        }
        else if (search.length() > 0) {
            if (search.matches("[-+]?\\d*\\.?\\d+")) {
                int i = Integer.parseInt(search);
                System.out.println("Searching for product with ID: " + search);
                resultList.add(Inventory.lookupPart(i));

                if (Inventory.lookupPart(i) == null) {
                    System.out.println("No value found with integer ID: " + i);
                    noVal(search);
                } else {
                    allPartsTableView.setItems(resultList);

                    if (resultList.size() == 1) {
                        allPartsTableView.getSelectionModel().selectFirst();
                    }
                }
            }
            else {
                resultList = Inventory.lookupPart(search);

                if (resultList.isEmpty()) noVal(search);
                else {
                    allPartsTableView.setItems(resultList);

                    if (resultList.size() == 1) {
                        allPartsTableView.getSelectionModel().selectFirst();
                    }
                }
            }
        }
    }

    /**
     * FXML related function, when the add button under the all parts table in the form is clicked, the part
     * is now associated with that product but not yet saved.
     */
    public void addAssociatedPartClicked() {
        System.out.println("-------------------------------------------------------------------------------------");
        System.out.println("Add associated part button request received...");
        System.out.println("-------------------------------------------------------------------------------------");
        System.out.println("Currently associated parts for " + mainSelectedProduct.getName() + ": " + selectedProductAssociated);
        System.out.println("New part declared / redeclaration, 'highlighted part'...");
        Part higlightedPart = allPartsTableView.getSelectionModel().getSelectedItem();
        System.out.println("'highlighted part' set to " + higlightedPart.getName() + " part...");

        System.out.println("-------------------------------------------------------------------------------------");
        System.out.println("Adding 'highlightedPart' Part to partsToAdd list...");

        try {
            if (preSaveList.contains(higlightedPart)) {
                highlightError();
            }
            else {
                preSaveList.add(higlightedPart);

                currentPartsTableView.setItems(preSaveList);

                System.out.println("-------------------------------------------------------------------------------------");
                System.out.println("CHECK: List before saving. ");
                System.out.println("preSaveList: " + preSaveList);
                System.out.println("current:     " + selectedProductAssociated);
            }
        } catch (Exception e) {
            highlightError();
        }
    }

    /**
     * FXML related function that as the 'cancel' button is clicked, no product is updated in any way. Returning to
     * main screen by calling the function.
     * @param actionEvent required for action load.
     * @throws IOException I/O operation dependent.
     */
    public void cancelModifyFormClicked(ActionEvent actionEvent) throws IOException {
        returnMainScreen(actionEvent);
    }

    /**
     * Function that generates the index location of the current part to be modified, used by the class update function
     * in Inventory.
     * @return index integer (location).
     */
    public int getIndex() {
        int index = Inventory.getAllProducts().indexOf(mainSelectedProduct);
        System.out.println(index);
        return index;
    }

    /**
     * Alert that is shown if no part is highlighted to add to added or existing parts table.
     */
    public void highlightError() {
        String confirmation = "No part selected. Please try again.";

        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("No part highlighted");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }

    /**
     * Function that takes the string that caused the function to be called and makes a visible alert that the cost
     * text field data is invalid and must be modified.
     * @param errorValue is the string value causing the function to be called, input data, tested on, must be modified.
     */
    public void invalidCost(String errorValue) {
        String confirmation = "Invalid price / cost value input \"" + errorValue +"\". Please try again.";

        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("Invalid price / cost");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }

    /**
     * Function that takes the inventory string and makes a visible alert that the inventory text field data is invalid
     * and must be modified.
     * @param errorValue is the string value causing the function to be called, input data, tested on, must be modified.
     */
    public void invalidInv(String errorValue) {
        String confirmation = "Invalid inv input \"" + errorValue +"\". Please try again.";

        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("Invalid inventory");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }

    /**
     * Function if any of the text fields contain invalid data upon saving to display an alert notifying user of such.
     */
    private void invalidFields() {
        String confirmation = "Invalid values. Please try again.";

        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("Invalid input in fields.\n\nNOTE: Min should be less than max; and Inv should be between those two values.\nMin and Max should be greater than or equal to 0.");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }


    /**
     * Function that takes the maximum inventory string and makes a visible alert that the inventory text field data is
     * invalid and must be modified.
     * @param errorValue is the string value causing the function to be called, input data, tested on, must be modified.
     */
    public void invalidMax(String errorValue) {
        String confirmation = "Invalid max value input \"" + errorValue +"\". Please try again.";

        System.out.println("hi");
        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("Invalid maximum");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }

    /**
     * Function that takes the minimum inventory string and makes a visible alert that the inventory text field data is
     * invalid and must be modified.
     * @param errorValue is the string value causing the function to be called, input data, tested on, must be modified.
     */
    public void invalidMin(String errorValue) {
        String confirmation = "Invalid min value input \"" + errorValue +"\". Please try again.";

        System.out.println("hi");
        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("Invalid minimum");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }

    /**
     * Additional T/F function that checks input integrity by comparing the inventory, minimum and maximum values to see if
     * the minimum and maximum is a non-negative integer and if the inventory is within the minimum and maximum bounds. (Inclusive).
     * @param inv inventory string then converted to an integer.
     * @param min inventory string then converted to an integer.
     * @param max inventory string then converted to an integer.
     * @return true if the inventory, minimum and maximum fields are valid. else false, but giving an alert.
     */
    public boolean invCheck(String inv, String min, String max) {
        int checkInv = Integer.parseInt(inv);
        int checkMin = Integer.parseInt(min);
        int checkMax = Integer.parseInt(max);

        if(checkMin >= 0 && checkMax >= 0 && checkInv >= checkMin && checkInv <= checkMax) {
            return true;
        }
        else {
            invalidFields();
            return false;
        }
    }

    /**
     * Function if any of the text fields are empty (not populated with data) to display an alert notifying user of such.
     */
    public void missingFields() {
        String confirmation = "One or more fields with no value. Please try again.";

        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("Missing fields.");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }

    /**
     * Alert that is shown to user if there is no data similar to what is in the search box text field.
     * @param string takes what the user had typed to draw alert.
     */

    public void noVal(String string) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("No results");
        alert.setContentText("No results found in search \"" + string + "\"");
        alert.showAndWait();
    }

    /**
     * Function that given the MODIFIED part's name, cost, inventory, minimum and maximum inventory, and machine ID or company name
     * input, will execute multiple checks to confirm the input is valid so the form can be saved (the part added). If
     * input fails during a certain check, a certain error is shown for the respective field where the error occurred.
     * @param name part's name input.
     * @param cost part's cost / price input.
     * @param inv part's inventory input.
     * @param min part's minimum inventory input.
     * @param max part's maximum inventory input.
     * @return if the input is valid, the boolean function returns true where called, meaning the form may proceed.
     * and if false, the form has invalid fields and will not proceed.
     */
    public boolean paramCheck(String name, String cost, String inv, String min, String max) {
        if(name.isEmpty() || cost.isEmpty() || inv.isEmpty() || min.isEmpty() || max.isEmpty()) {
            missingFields();
            return false;
        }
        if(cost.matches("[a-zA-Z]+")) {
            invalidCost(cost);
            return false;
        }
        if(inv.matches("[a-zA-Z]+")) {
            invalidInv(inv);
            return false;
        }
        if(min.matches("[a-zA-Z]+")) {
            invalidMin(min);
            return false;
        }
        if(max.matches("[a-zA-Z]+")) {
            invalidMax(max);
            return false;
        }
        return true;
    }

    /**
     * remove button under the added or existing associated parts table that removes an added or existing associated
     * part not yet saved, though.
     */
    public void removeAssociatedPartClicked() {
        Part higlightedPart = currentPartsTableView.getSelectionModel().getSelectedItem();
        if(higlightedPart == null) {
            highlightError();
        }
        else {
            removeConfirmation(higlightedPart);
            currentPartsTableView.setItems(preSaveList);
        }
    }

    /**
     * An alert shown to the user asking for second confirmation to remove an added or existing associated part
     * from the product.
     * @param part removes the part from this function officially.
     */
    public void removeConfirmation(Part part) {
        String confirmation = "This will remove the selected part from product.";

        ButtonType confirm = new ButtonType("Ok");
        ButtonType cancel = new ButtonType("Cancel");
        Alert alert = new Alert(Alert.AlertType.WARNING, confirmation, confirm, cancel);
        alert.setTitle("Confirm");
        alert.setHeaderText("Remove part from product?");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        Optional<ButtonType> buttonSet = alert.showAndWait();
        buttonSet.ifPresent(selection -> {
            if (selection.equals(confirm)) {
                preSaveList.remove(part);
            } else if (selection.equals(cancel)) {
                System.out.println("returning...");
            }
        });
    }

    /**
     * Function to return to the main screen if called.
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (returning to main screen).
     */
    private void returnMainScreen(ActionEvent actionEvent) throws IOException {
        Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("MainForm.fxml")));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * FXML related function if the save button at the bottom of the form is clicked, tests if input is valid.
     * If so, the product is added to the inventory.
     * @param actionEvent required for action load.
     */
    public void saveModifiedProductClicked(ActionEvent actionEvent) {
        String productId    = modifyProductIdField.getText();
        String productName  = modifyProductNameField.getText();
        String productInv   = modifyProductInventoryField.getText();
        String productCost  = modifyProductCostField.getText();
        String productMin   = modifyProductMinField.getText();
        String productMax   = modifyProductMaxField.getText();

        int index = getIndex();
        int newId = Integer.parseInt(productId);

        try {
            if(paramCheck(productName, productCost, productInv, productMin, productMax)) {
                if (invCheck(productInv, productMin, productMax)) {
                    double newCost  = Double.parseDouble(productCost);
                    int newInv      = Integer.parseInt(productInv);
                    int newMin      = Integer.parseInt(productMin);
                    int newMax      = Integer.parseInt(productMax);

                    Product newProduct = new Product(newId, productName, newCost, newInv, newMin, newMax);

                    for (Part part : preSaveList) {
                        newProduct.addAssociatedParts(part);
                    }

                    Inventory.updateProduct(index, newProduct);
                    returnMainScreen(actionEvent);
                }
            }
            else missingFields();
        } catch (Exception e) {
            invalidFields();
        }
    }
}