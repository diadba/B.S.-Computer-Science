package syspackage.inventorymanagement;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 *  The applications start point. Parts have been set up similar to the example word document provided by the class.
 *  @author Anthony Coots
 *
 *  FUTURE ENHANCEMENT: Include a general alert handling function within main and have classes reference main to use that
 *  function, for I had coded each alert error numerous times, and realized halfway through that the code was being
 *  repeated excessively between classes.
 */

public class Main extends Application {

    /**
     * Where the application starts, hence 'start'.
     * @param stage javafx graphical implementation.
     * @throws IOException I/O required.
     */
    @Override
    public void start(Stage stage) throws IOException {

        Part brakes = new InHouse(1, "Brakes", 15.00, 10, 4, 16, 1);
        Inventory.addPart(brakes);
        Part wheels = new InHouse(2, "Wheel", 11.00, 16, 4, 16, 1);
        Inventory.addPart(wheels);
        Part seat = new Outsourced(3, "Seat", 10.00, 10, 1, 16, "Herman");
        Inventory.addPart(seat);
        Product bike = new Product(1000, "Giant Bike", 299.99, 5, 1, 10);
        Inventory.addProduct(bike);
        Product tricycle = new Product(1001, "Remote Car", 99.99, 3, 1, 10);
        Inventory.addProduct(tricycle);

        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("MainForm.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1080, 720);
        stage.setTitle("WGU Inventory Management!");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Mains, main function.
     * @param args java required argument.
     */

    public static void main(String[] args) {
        launch();
    }
}