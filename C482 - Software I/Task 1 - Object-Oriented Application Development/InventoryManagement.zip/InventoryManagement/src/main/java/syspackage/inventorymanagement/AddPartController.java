package syspackage.inventorymanagement;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

/**
 * Class AddPartController, that controls the logic for the Add button for the Parts Table.
 * @author Anthony Coots
 *
 * RUNTIME ERROR: Machine ID integer not properly handling incorrect or empty input. If user changed between In-House
 * and Outsourced buttons and mistakenly input a string (company name) into an integer field (machine ID) the program
 * would error, as there wasn't a proper invalid field alert for that text field.
 */

public class AddPartController implements Initializable {
    /**
     * FXML variable for Radio Button In-House objects for the add part screen.
     */

    @FXML
    private RadioButton addInHouseRadioButton;

    /**
     * FXML variable for Radio Button Outsourced objects for the add part screen.
     */

    @FXML
    private RadioButton addOutsourcedRadioButton;

    /**
     * FXML variable for the text field specification dependent on the added part class (In-House / Outsourced).
     */

    @FXML
    private Text machineOrComp;

    /**
     * FXML variable for the text field input for a parts' name.
     */

    @FXML
    private TextField addPartNameField;

    /**
     * FXML variable for the text field input for a parts' inventory integer.
     */

    @FXML
    private TextField addPartInventoryField;

    /**
     * FXML variable for the text field input for a parts' cost double.
     */

    @FXML
    private TextField addPartCostField;

    /**
     * FXML variable for the text field input for a parts' minimum stock integer.
     */

    @FXML
    private TextField addPartMinField;

    /**
     * FXML variable for the text field input for a parts' maximum stock integer.
     */

    @FXML
    private TextField addPartMaxField;

    /**
     * FXML variable for the text field input for a parts' machineID OR company name.
     */

    @FXML
    private TextField addPartMachineField;

    /**
     * Method that initiates a new id for the part to be
     */
    private final int newId = initNewId();

    /**
     * Function that is called upon to initiate the add part screen. By default, the In-House radio button is selected
     * for integrity purposes.
     * @param url path location.
     * @param resourceBundle source through root.
     */

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        System.out.println("AddPartController.java called successfully.");
        addInHouseRadioButton.setSelected(true);

    }
    /**
     * FXML response method to the cancel button being clicked. calling the return to main screen function.
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (returning to main screen).
     */
    public void addPartCancelClicked(ActionEvent actionEvent) throws IOException {
        returnMainScreen(actionEvent);
    }

    /**
     * FXML response method, when the save button is clicked, all input within text fields are set to strings to start
     * the process of integrity checking the form, which itself calls other methods to verify the form data is valid.
     * @param actionEvent required for action load.
     */
    public void addSaveClicked(ActionEvent actionEvent) {
        String partName = addPartNameField.getText();
        String partCost = addPartCostField.getText();
        String partInv  = addPartInventoryField.getText();
        String partMin  = addPartMinField.getText();
        String partMax  = addPartMaxField.getText();
        String partMID  = addPartMachineField.getText();
        boolean inHouse = addInHouseRadioButton.isSelected();

        try {
            if(paramCheck(partName, partCost, partInv, partMin, partMax, partMID)) {
                if (invCheck(partInv, partMin, partMax)) {
                    double doubleCost = Double.parseDouble(partCost);
                    int intInv = Integer.parseInt(partInv);
                    int intMin = Integer.parseInt(partMin);
                    int intMax = Integer.parseInt(partMax);
                    int intMID = 0;
                    if (inHouse) {
                        intMID = Integer.parseInt(partMID);
                    }

                    Part newPart;

                    if (inHouse) {
                        newPart = new InHouse(newId, partName, doubleCost, intInv, intMin, intMax, intMID);
                    }
                    else {
                        newPart = new Outsourced(newId, partName, doubleCost, intInv, intMin, intMax, partMID);
                    }
                    Inventory.addPart(newPart);
                    returnMainScreen(actionEvent);
                    }
            }
        } catch (Exception e) {
            invalidFields();
        }
    }

    /**
     * FXML response method, when the In-House radio button is selected, will set the other radio button selection to
     * false and logically ensure only one subclass is chosen at a time. Also sets the text for the final field to machine ID
     * since In-House objects only make use of machine ID not company name.
     */
    public void inhouseClicked() {
        if(addOutsourcedRadioButton.isSelected()) {
            addOutsourcedRadioButton.setSelected(false);
            addInHouseRadioButton.setSelected(true);
        }
        else {
            addInHouseRadioButton.setSelected(true);
        }
        machineOrComp.setText("MACHINE ID:");
    }

    /**
     * Generates a new identification integer by looking through all parts, selecting the final part (largest id),
     * taking that id and incrementing by 1 for new id generation.
     * @return new identification integer.
     */
    private int initNewId() {
        Part tempPart = null;
        for (Part comparable : Inventory.getAllParts()) {
            tempPart = comparable;
        }
        assert tempPart != null;
        return tempPart.getId() + 1;
    }

    /**
     * Function that takes the string that caused the function to be called and makes a visible alert that the cost
     * text field data is invalid and must be modified.
     * @param errorValue is the string value causing the function to be called, input data, tested on, must be modified.
     */
    public void invalidCost(String errorValue) {
        String confirmation = "Invalid price / cost value input \"" + errorValue +"\". Please try again.";

        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("Invalid price / cost");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }

    /**
     * Function if any of the text fields contain invalid data upon saving to display an alert notifying user of such.
     */
    private void invalidFields() {
        String confirmation = "Invalid values. Please try again.";

        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("Invalid input in fields.\n\nNOTE: Min should be less than max; and Inv should be between those two values.\nMin and Max should be greater than or equal to 0.");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }

    /**
     * Function that takes the inventory string and makes a visible alert that the inventory text field data is invalid
     * and must be modified.
     * @param errorValue is the string value causing the function to be called, input data, tested on, must be modified.
     */
    public void invalidInv(String errorValue) {
        String confirmation = "Invalid inv input \"" + errorValue +"\". Please try again.";

        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("Invalid inventory");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }

    /**
     * Function that takes the maximum inventory string and makes a visible alert that the inventory text field data is
     * invalid and must be modified.
     * @param errorValue is the string value causing the function to be called, input data, tested on, must be modified.
     */
    public void invalidMax(String errorValue) {
        String confirmation = "Invalid max value input \"" + errorValue +"\". Please try again.";

        System.out.println("hi");
        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("Invalid maximum");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }
    /**
     * Function that takes the minimum inventory string and makes a visible alert that the inventory text field data is
     * invalid and must be modified.
     * @param errorValue is the string value causing the function to be called, input data, tested on, must be modified.
     */
    public void invalidMin(String errorValue) {
        String confirmation = "Invalid min value input \"" + errorValue +"\". Please try again.";

        System.out.println("hi");
        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("Invalid minimum");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }

    /**
     * Additional T/F function that checks input integrity by comparing the inventory, minimum and maximum values to see if
     * the minimum and maximum is a non-negative integer and if the inventory is within the minimum and maximum bounds. (inclusive).
     * @param inv inventory string then converted to an integer.
     * @param min inventory string then converted to an integer.
     * @param max inventory string then converted to an integer.
     * @return true if the inventory, minimum and maximum fields are valid. else false, but giving an alert.
     */
    public boolean invCheck(String inv, String min, String max) {
        int checkInv = Integer.parseInt(inv);
        int checkMin = Integer.parseInt(min);
        int checkMax = Integer.parseInt(max);

        if(checkMin >= 0 && checkMax >= 0 && checkInv >= checkMin && checkInv <= checkMax) {
            return true;
        }
        else {
            invalidFields();
            return false;
        }
    }

    /**
     * Function if any of the text fields are empty (not populated with data) to display an alert notifying user of such.
     */
    public void missingFields() {
        String confirmation = "One or more fields with no value. Please try again.";

        ButtonType confirm = new ButtonType("Ok");
        Alert alert = new Alert(Alert.AlertType.ERROR, confirmation, confirm);
        alert.setTitle("Error");
        alert.setHeaderText("Missing fields.");

        Window window = alert.getDialogPane().getScene().getWindow();
        window.setOnCloseRequest(event -> alert.hide());

        alert.showAndWait();
    }

    /**
     * FXML response method, when the Outsourced radio button is selected, will set the other radio button selection to
     * false and logically ensure only one subclass is chosen at a time. Also sets the text for the final field to company name
     * since Outsourced objects only make use of company name not machine IDs.
     */
    public void outsourcedClicked() {
        if(addInHouseRadioButton.isSelected()) {
            addInHouseRadioButton.setSelected(false);
            addOutsourcedRadioButton.setSelected(true);
        }
        else {
            addOutsourcedRadioButton.setSelected(true);
        }
        machineOrComp.setText("COMPANY NAME:");
    }

    /**
     * Function that given the part's name, cost, inventory, minimum and maximum inventory, and machine ID or company name
     * input, will execute multiple checks to confirm the input is valid so the form can be saved (the part added). If
     * input fails during a certain check, a certain error is shown for the respective field where the error occurred.
     * @param name part's name input.
     * @param cost part's cost / price input.
     * @param inv part's inventory input.
     * @param min part's minimum inventory input.
     * @param max part's maximum inventory input.
     * @param dynamic part's machine ID or company name input.
     * @return if the input is valid, the boolean function returns true where called, meaning the form may proceed.
     * and if false, the form has invalid fields and will not proceed.
     */
    public boolean paramCheck(String name, String cost, String inv, String min, String max, String dynamic) {
        if(name.isEmpty() || cost.isEmpty() || inv.isEmpty() || min.isEmpty() || max.isEmpty() || dynamic.isEmpty()) {
            missingFields();
            return false;
        }
        if(cost.matches("[a-zA-Z]+")) {
            invalidCost(cost);
            return false;
        }
        if(inv.matches("[a-zA-Z]+")) {
            invalidInv(inv);
            return false;
        }
        if(min.matches("[a-zA-Z]+")) {
            invalidMin(min);
            return false;
        }
        if(max.matches("[a-zA-Z]+")) {
            invalidMax(max);
            return false;
        }
        return true;
    }

    /**
     * Function that loads the main form FXML upon call (exiting the add part form).
     * @param actionEvent required for action load.
     * @throws IOException FXMLLoader (returning to main screen).
     */
    private void returnMainScreen(ActionEvent actionEvent) throws IOException {
        Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("MainForm.fxml")));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
}
