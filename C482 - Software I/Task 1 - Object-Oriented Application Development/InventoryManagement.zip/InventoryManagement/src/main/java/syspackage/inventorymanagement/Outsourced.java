package syspackage.inventorymanagement;

/**
 * Subclass of Parts, for parts that are 'outsourced'.
 * @author Anthony Coots
 *
 * FUTURE ENHANCEMENT: Make use of the setcompanyName setter, it may have made the code more reader friendly however
 * the approach does not require it.
 */
public class Outsourced extends Part
{
    // - companyName : String
    /**
     * String that associates an outsourced object with a company name definition.
     */
    private String companyName;
    // constructor.
    // + Outsourced(id : int, name : String, price : double, stock : int, min : int, max : int, companyName : String)

    /**
     * Class Object constructor requiring all parts for the object to be made if not empty or null.
     * @param id Outsourced Parts' integer identifier.
     * @param name Outsourced Parts' name.
     * @param price Outsourced Parts' cost / price.
     * @param stock Outsourced Parts' inventory (stock).
     * @param min Outsourced Parts' minimum inventory.
     * @param max Outsourced Parts' maximum inventory.
     * @param companyName Outsourced Parts' company name.
     */
    public Outsourced(int id, String name, double price, int stock, int min, int max, String companyName)
    {
        super(id, name, price, stock, min, max);
        this.companyName = companyName;
    }
    // setter.
    // + setCompanyName(companyName : String):void

    /**
     * Class mutator to set the company name.
     * @param companyName takes the input and sets company name.
     */
    public void setCompanyName(String companyName)
    {
        this.companyName = companyName;
    }

    // getter.
    // + getCompanyName():String

    /**
     * Class accessor.
     * @return accesses (gets) the company name.
     */
    public String getCompanyName()
    {
        return companyName;
    }
}