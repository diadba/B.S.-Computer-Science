package syspackage.inventorymanagement;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;


/**
 * Class to make objects (Product), products are made of detailed values and of part objects.
 * @author Anthony Coots
 *
 * RUNTIME ERROR: Unfortunately, two days were spent attempting to fix and error that all products would contain the
 * same list of associated parts. The solution was removing an accidental 'static' on the getAllAssociatedParts.
 */

public class Product
{
    // PRIVATE ACCESS, also not static...
    // - associatedParts:ObservableList<Part>
    /**
     * Private list of associated parts for each Product; Parts make up the Product.
     */
    private ObservableList<Part> associatedParts = FXCollections.observableArrayList();
    // - id : int
    /**
     * Integer identifier for a product.
     */
    private int id;
    // - name : String
    /**
     * Name of a product.
     */
    private String name;
    // - price : double
    /**
     * Cost / price of a product.
     */
    private double price;
    // - stock : int
    /**
     * Inventory (stock) of a product.
     */
    private int stock;
    // - min : int
    /**
     * Minimum inventory of a product.
     */
    private int min;
    // - max : int
    /**
     * Maximum inventory of a product.
     */
    private int max;
    // END PRIVATE ACCESS

    // PUBLIC ACCESS
    // constructor
    // + Product(id : int, name : String, price : double, stock : int, min : int, max : int)

    /** Class constructor of a Product.
     *
     * @param id Products' integer identifier.
     * @param name Products' name.
     * @param price Products' cost / price.
     * @param stock Products' inventory (stock).
     * @param min Products' minimum inventory.
     * @param max Products' maximum inventory.
     */
    public Product(int id, String name, double price, int stock, int min, int max)
    {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.min = min;
        this.max = max;
    }
    /* + setId(id : int):void */
    /**
     * set the product objects name value.
     * @param id products' integer identifier.
     */
    public void setId(int id)
    {
        this.id = id;
    }
    /* + setName(name : String):void */
    /**
     * set the product objects name value.
     * @param name products' name.
     */
    public void setName(String name)
    {
        this.name = name;
    }
    /* + setPrice(price : double):void */
    /**
     * set the product objects price / cost value.
     * @param price products' cost / price.
     */
    public void setPrice(double price)
    {
        this.price = price;
    }
    /* + setStock(stock : int):void */
    /**
     * set the product objects inventory value.
     * @param stock products' inventory (stock).
     */
    public void setStock(int stock)
    {
        this.stock = stock;
    }
    /* + setMin(min : int):void */
    /**
     * set the product objects minimum inventory value.
     * @param min products' minimum inventory (stock).
     */
    public void setMin(int min)
    {
        this.min = min;
    }
    /* + setMax(max : int):void */
    /**
     * set the product objects maximum inventory value.
     * @param max products' maximum inventory (stock).
     */
    public void setMax(int max)
    {
        this.max = max;
    }
    /* + getId():int */
    /**
     * return the product objects identifier value.
     * @return id;
     */
    public int getId()
    {
        return id;
    }
    /* + getName():String */
    /**
     * return the product objects name value.
     * @return name;
     */
    public String getName()
    {
        return name;
    }
    /* + getPrice():double */
    /**
     * return the product objects price / cost value.
     * @return price;
     */
    public double getPrice()
    {
        return price;
    }
    /* + getStock():int */
    /**
     * return the product objects inventory value.
     * @return stock;
     */
    public int getStock()
    {
        return stock;
    }
    /* + getMin():int */
    /**
     * return the product objects minimum inventory value.
     * @return min;
     */
    public int getMin()
    {
        return min;
    }
    /* + getMax():int */
    /**
     * return the product objects maximum inventory value.
     * @return max;
     */
    public int getMax()
    {
        return max;
    }
    /* + addAssociatedPart(part:Part):void */
    /**
     * Add a part to a products associated list of parts.
     * @param part Part to be added to the Products' list of associated parts.
     */
    public void addAssociatedParts(Part part)
    {
        associatedParts.add(part);
    }
    /* + deleteAssociatedPart(selectedAssociatedPart:Part):boolean */
    /**
     * Remove a part from the products associated list of parts.
     */
    public boolean deleteAssociatedPart(Part selectedAssociatedPart)
    {
        associatedParts.remove(selectedAssociatedPart);
        return true;
    }
    /* + getAllAssociatedParts():ObservableList<Part> */
    /**
     * Return all parts for a selected product associated with said product; Part(s) make up the product.
     * @return associatedParts.
     */
    public ObservableList<Part> getAllAssociatedParts()     // originally had a typo 'getAssociatedParts'.
    {
        return associatedParts;
    }
}
