module syspackage.inventorymanagement {
    requires javafx.controls;
    requires javafx.fxml;


    opens syspackage.inventorymanagement to javafx.fxml;
    exports syspackage.inventorymanagement;
}