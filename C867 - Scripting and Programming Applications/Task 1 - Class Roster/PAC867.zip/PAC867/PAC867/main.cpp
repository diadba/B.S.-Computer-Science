#include <iomanip>
#include <iostream>
#include <string>
#include "degree.h"
#include "roster.h"
#include "student.h"
using namespace std;

int main()
{
/* ------------------------------------------------------------------------------------------------------------------
A:  Modify the "studentData Table" to include your personal information as the last item.
------------------------------------------------------------------------------------------------------------------ */
    
    const string studentData[5] = {  "A1,John,Smith,John1989@gm ail.com,20,30,35,40,SECURITY",
                                    "A2,Suzan,Erickson,Erickson_1990@gmailcom,19,50,30,40,NETWORK",
                                    "A3,Jack,Napoli,The_lawyer99yahoo.com,19,20,40,33,SOFTWARE",
                                    "A4,Erin,Black,Erin.black@comcast.net,22,50,58,40,SECURITY",
                                    "A5,Anthony,Coots,acoots5@wgu.edu,21,32,12,13,SOFTWARE"         // PI here.
    };

/* ------------------------------------------------------------------------------------------------------------------
F1: Print out to the screen, via your application, the course title, the programming language used, 
    your WGU student ID, and your name.
------------------------------------------------------------------------------------------------------------------ */

    printf("Course Title: \t\tScripting and Programming - Applications - C867\n");
    printf("Programming Language: \tC++\n");
    printf("Student ID: \t\t010958511\n");
    printf("Name: \t\t\tCoots, Anthony\n\n");

/* ------------------------------------------------------------------------------------------------------------------
F2: Create an instance of the Roster class called classRoster.
------------------------------------------------------------------------------------------------------------------ */

    Roster* classRoster = new Roster(5);

/* ------------------------------------------------------------------------------------------------------------------
F3: Add each student to classRoster.
------------------------------------------------------------------------------------------------------------------ */

    for (int i = 0; i < 5; ++i)
        classRoster->parseSet(studentData[i]);

/* ------------------------------------------------------------------------------------------------------------------
F4: Pseudocode.
NOTE: double data type used for average days calculation. considered this for specific day value.
------------------------------------------------------------------------------------------------------------------ */

//  classRoster->add("A6", "Test", "Student", "test_cast@wgu.edu", 99, 10, 30, 40, DegreeProgram::SECURITY);  

    cout << "+" << setw(120) << setfill('-') << "+" << endl;
    classRoster->printAll();
    cout << endl << "+" << setw(120) << setfill('-') << "+" << endl;
    classRoster->printInvalidEmails();
    cout << endl << "+" << setw(120) << setfill('-') << "+" << endl;

    cout << endl << "Average # of days in a course for students: " << endl << endl;
    for(int i = 0; i < 5; ++i)
        classRoster->printAverageDaysInCourse(classRoster->accStudent(i)->accStudentId());
      //classRoster. printAverageDaysInCourse (/*current_object's student id*/);  

    cout << endl << "+" << setw(120) << setfill('-') << "+" << endl;
    classRoster->printByDegreeProgram(SOFTWARE);
    cout << endl << "+" << setw(120) << setfill('-') << "+" << endl;
    classRoster->remove("A3");
    cout << endl << "+" << setw(120) << setfill('-') << "+" << endl;
    classRoster->printAll();
    cout << endl << "+" << setw(120) << setfill('-') << "+" << endl;
    classRoster->remove("A3");
    cout << endl << "+" << setw(120) << setfill('-') << "+" << endl << endl;

/* ------------------------------------------------------------------------------------------------------------------
F5: Implement the destructor to release the memory that was allocated dynamically in Roster.
------------------------------------------------------------------------------------------------------------------ */

    delete classRoster;

/* ------------------------------------------------------------------------------------------------------------------
eof;
------------------------------------------------------------------------------------------------------------------ */

    return 0;
}

