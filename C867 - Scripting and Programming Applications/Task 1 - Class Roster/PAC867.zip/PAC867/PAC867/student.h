#ifndef student_h
#define student_h

#include <string>
#include "degree.h"
using namespace std;
/* ------------------------------------------------------------------------------------------------------------------
D1: Create the class Student  in the files student.h and student.cpp, which includes the following variables.
------------------------------------------------------------------------------------------------------------------ */
class Student
{
public:
	DegreeProgram degreeprogram;							// all lowercase as used in 3a. requirements.
	int age;												// wanted to make this an unsigned int, since age is >= 0.
	int daysInCourse[3];									// pointer address declaration.
	string studentID;										// will be a mix of a single char and single digit.
	string firstName, lastName, emailAddress;
/* ------------------------------------------------------------------------------------------------------------------
D2: Accessors (a).
------------------------------------------------------------------------------------------------------------------ */
	int accAge();											// ordered alphabetically, should be so for cpp files.
	int* accDaysInCourse();									// array for days for 3 courses. 
	DegreeProgram accDegreeProgram();						// accessor of type DegreeProgram as declared in degree.h
	string accEmailAddress();								// accessor for email address.			
	string accFirstName();									// accessor for first name.	
	string accLastName();									// accessor for last name.	
	string accStudentId();									// accessor for studentID.	
/* ------------------------------------------------------------------------------------------------------------------
D2: Mutators (b).
------------------------------------------------------------------------------------------------------------------ */	
	void mutAge(int age);				
	void mutDaysInCourse(int daysInCourse[]);
	void mutDegreeProgram(DegreeProgram degreeprogram);
	void mutEmailAddress(string emailAddress);
	void mutFirstName(string firstName);
	void mutLastName(string lastName);
	void mutStudentId(string studentID);
	void print();											// "print()" as specified in requirements.
/* ------------------------------------------------------------------------------------------------------------------
D2: Constructors (d).
------------------------------------------------------------------------------------------------------------------ */												
															// sought it better to make a new, then alter
	Student(												// constructor using all input parameters.
		string studentID, string firstName, string lastName,
		string emailAddress, int age, int daysInCourse[], DegreeProgram degreeprogram
	);							
/* ------------------------------------------------------------------------------------------------------------------
eof;
------------------------------------------------------------------------------------------------------------------ */
};
#endif
