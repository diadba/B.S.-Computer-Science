#ifndef roster_h						
#define roster_h

#include <iostream>
#include <string>
#include "student.h"
using namespace std;
/* ------------------------------------------------------------------------------------------------------------------
E1: Create an array of pointers, classRosterArray, to hold the data provided in the "studentData Table."
------------------------------------------------------------------------------------------------------------------ */
class Roster
{
	public:
		Student** classRosterArray;							// as specified in requirements, an array of pointers. 
															// int* classRosterArray is a pointer to obj.
															// int** classRosterArray is a pointer to a pointer to obj.
															// the other way is int *classRosterArray[] 
															// but doesn't match requirements.
		int defStudents;
		int currStudent;
/* ------------------------------------------------------------------------------------------------------------------
Accessors:
------------------------------------------------------------------------------------------------------------------ */
															// this is the reason for the array of pointers, 
		Student* accStudent(int student);					// each student set must be parsed (all data relative
															// to the student must be seperated).
/* ------------------------------------------------------------------------------------------------------------------
Mutators:
------------------------------------------------------------------------------------------------------------------ */
		void add(
			string studentID, string firstName, string lastName,
			string emailAddress, int age, int daysInCourse1, int daysInCourse2, int daysInCourse3, 
			DegreeProgram degreeprogram
		);													// similar build as student constructor.
		void parseSet(string currStudentData);
		void printAll();									// as specified in requirements. for public void 
		void printAverageDaysInCourse(string studentID);	// printAll() call. in requirements.
		void printByDegreeProgram(DegreeProgram degreeprogram);
		void printInvalidEmails();							// for public void printInvalidEmails() call.
		void remove(string studentID);						// this is the reason for the array of pointers, 
															// each student set must be parsed
															// (all data relative to the student must be seperated).
/* ------------------------------------------------------------------------------------------------------------------
Constructors:
------------------------------------------------------------------------------------------------------------------ */

		Roster();
		Roster(int defStudents);

/* ------------------------------------------------------------------------------------------------------------------
Destructors:
------------------------------------------------------------------------------------------------------------------ */
	
		~Roster();
};
/* ------------------------------------------------------------------------------------------------------------------
eof;
------------------------------------------------------------------------------------------------------------------ */
#endif