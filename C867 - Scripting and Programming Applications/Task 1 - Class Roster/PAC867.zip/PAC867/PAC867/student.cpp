#ifndef student_cpp							
#define student_cpp

#include <iomanip>
#include <iostream>								
#include <string>
#include "student.h"
using namespace std;
/* ------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------ */
void Student::mutStudentId(string stuID)					
{															
	studentID = stuID;										
}															
void Student::mutFirstName(string fName)
{
	firstName = fName;								
}															
void Student::mutLastName(string lName)
{
	lastName = lName;
}															
void Student::mutEmailAddress(string email)
{
	emailAddress = email;								
}															
void Student::mutAge(int stuAge)
{
	age = stuAge;										
}
void Student::mutDaysInCourse(int dayArray[])
{
	for (int i = 0; i < 3; ++i)
	{
		this->daysInCourse[i] = dayArray[i];
		cout << this->daysInCourse[i] << " ";
	}	
}
void Student::mutDegreeProgram(DegreeProgram degree)
{
	degreeprogram = degree;								
}															
void Student::print()
{
	int* daysInCourse = accDaysInCourse();		// access the daysInCourse for each student record.
	
	cout << accStudentId()									// specific student data, per requirements. no email.
		 << "\tFirst Name: " << accFirstName()
		 << "\tLast Name: " << accLastName()
		 << "\tAge: " << accAge()
		 << "\tdaysInCourse: {" << daysInCourse[0] << ", " << daysInCourse[1] << ", " << daysInCourse[2] << "} "
		 << "Degree Program: "  << DegreeArray[accDegreeProgram()] << "." << endl;
}
/* ------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------ */
Student::Student(string studentID, string firstName, string lastName,
	string emailAddress, int age, int daysInCourse[], DegreeProgram degreeprogram)
{												
	mutStudentId(studentID);
	mutFirstName(firstName); 
	mutLastName(lastName);
	mutEmailAddress(emailAddress);
	mutAge(age);
	for (int i = 0; i < 3; ++i)
		this->daysInCourse[i] = daysInCourse[i];
	mutDegreeProgram(degreeprogram);												
}
/* ------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------ */
string Student::accStudentId()					// access (get) object student ID.
{
	return studentID;							// mutStudentId() will set upon checkpoint.
}
string Student::accFirstName()					// access (get) object first name.
{
	return firstName;							// mutFirstName() will set upon checkpoint.
}
string Student::accLastName()					// access (get) object last name.
{
	return lastName;							// mutLastName() will set upon checkpoint.
}
string Student::accEmailAddress()				// access (get) object email address.
{
	return emailAddress;						// mutEmailAddress() will set upon checkpoint.
}
int Student::accAge()							// access (get) object age.
{
	return age;									// mutAge() will set upon checkpoint.
}
int* Student::accDaysInCourse()					// NOTE: access (get) object array as int !!*!! points to
{												// the object's array.
	return this->daysInCourse;					// mutDaysInCourse() will set upon checkpoint as array is returned.
}
DegreeProgram Student::accDegreeProgram()		// access (get) object degreeprogram (SOFTWARE, NETWORK, SECURITY).
{
	return degreeprogram;						// mutDegreeProgram() will set upon checkpoint.
}
#endif