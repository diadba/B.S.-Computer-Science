#ifndef degree_h
#define degree_h

#include <iostream>
#include <string>
using namespace std;

/* ------------------------------------------------------------------------------------------------------------------
Define an enumerated data type DegreeProgram for the degree programs containing
data type values Security, Network, Software.

Security, network and software are allocated values for DegreeProgram user data type.
------------------------------------------------------------------------------------------------------------------ */

/* ------------------------------------------------------------------------------------------------------------------
C:  Define an enumerated data type DegreeProgram for the degree programs containing the data type values SECURITY,
	NETWORK, and SOFTWARE.
------------------------------------------------------------------------------------------------------------------ */

enum DegreeProgram { SECURITY, NETWORK, SOFTWARE };
const string DegreeArray[3] = { "SECURITY", "NETWORK", "SOFTWARE" };

/* ------------------------------------------------------------------------------------------------------------------
eof;
------------------------------------------------------------------------------------------------------------------ */
#endif 