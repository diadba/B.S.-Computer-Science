#ifndef roster_cpp
#define roster_cpp

#include <iomanip>
#include <iostream>
#include <string>
#include <vector>
#include "roster.h"
using namespace std;
/* ------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------ */
Student* Roster::accStudent(int student)
{
	return classRosterArray[student];
}
/* ------------------------------------------------------------------------------------------------------------------
E3: public void add(string studentID, string firstName, string lastName, string emailAddress, int age, 
	int daysInCourse1, int daysInCourse2, int daysInCourse3, DegreeProgram degreeprogram) that sets the 
	instance variables from part D1 and updates the roster (a).
------------------------------------------------------------------------------------------------------------------ */
void Roster::add(string studentID, string firstName, string lastName,
	string emailAddress, int age, int daysInCourse1, int daysInCourse2, int daysInCourse3,
	DegreeProgram degreeprogram)								
{	
	int daysInCourse[3];
	daysInCourse[2] = daysInCourse3;
	daysInCourse[1] = daysInCourse2;
	daysInCourse[0] = daysInCourse1;

	for (int i = 0; i < 5; ++i)
	{
		classRosterArray[currStudent] = new Student(studentID, firstName, lastName,
			emailAddress, age, daysInCourse, degreeprogram);
	}
}
/* ------------------------------------------------------------------------------------------------------------------
E2: Parse each set of data identified in the "studentData Table".
	Add each student object to classRosterArray.
------------------------------------------------------------------------------------------------------------------ */
void Roster::parseSet(string currStudentData)
{
	string tempData = currStudentData;
	int commaPos = 0;
	currStudent++;

	DegreeProgram degreeprogram;
	string studentID;
	string firstName;
	string lastName;
	string emailAddress;
	int age;
	int daysInCourse[3];

//	this->classRosterArray[currStudent] = new Student();

	commaPos = tempData.find(",");
	studentID = tempData.substr(0, commaPos);
	tempData.erase(0, commaPos + 1);
	commaPos = tempData.find(",");

	firstName = tempData.substr(0, commaPos);
	tempData.erase(0, commaPos + 1);
	commaPos = tempData.find(",");

	lastName = tempData.substr(0, commaPos);
	tempData.erase(0, commaPos + 1);
	commaPos = tempData.find(",");

	emailAddress = tempData.substr(0, commaPos);
	tempData.erase(0, commaPos + 1);
	commaPos = tempData.find(",");

	age = stoi(tempData.substr(0, commaPos));
	tempData.erase(0, commaPos + 1);
	commaPos = tempData.find(",");

	for (int i = 0; i < 3; ++i)
	{
		daysInCourse[i] = stoi(tempData.substr(0, commaPos));
		tempData.erase(0, commaPos + 1);
		commaPos = tempData.find(",");
	}

	if (tempData.substr(0, 1) == "N")
		degreeprogram = NETWORK;
	else if (tempData.substr(0, 1) == "S")
		if ((tempData.substr(1, 1)) == "E")
			degreeprogram = SECURITY;
		else if (tempData.substr(1, 1) == "O")
			degreeprogram = SOFTWARE;

	this->classRosterArray[currStudent] = 
		new Student(studentID, firstName, lastName, emailAddress,
			age, daysInCourse, degreeprogram);
}
/* ------------------------------------------------------------------------------------------------------------------
E3: public void printAll() that prints a complete tab-separated list of student data in the provided format: 
	A1 [tab] First Name: John [tab] Last Name: Smith [tab] Age: 20 [tab]daysInCourse: {35, 40, 55} 
	Degree Program: Security. The printAll() function should loop through all the students in classRosterArray and 
	call the print() function for each student (c)
------------------------------------------------------------------------------------------------------------------ */
void Roster::printAll()
{
	cout << endl;											// formatting endl.
	for (int i = 0; i <= currStudent; ++i)					// currStudent due to parseSet ending on last student
		this->classRosterArray[i]->print();					// giving the total number post function.
}															// must print at location given from array.
/* ------------------------------------------------------------------------------------------------------------------
E3: public void printAverageDaysInCourse(string studentID)  that correctly prints a student�s average number of 
	days in the three courses. The student is identified by the studentID parameter (d).
------------------------------------------------------------------------------------------------------------------ */
void Roster::printAverageDaysInCourse(string studentID)
{
	double avg = 0.0;										// made a double for specific instance, if an average 
															// is calculated as say, 20.50 days then, that
	for (int i = 0; i < defStudents; ++i)					// particular student finishes a class on average every
	{														// 20 days with the next day ending at noon, midnight,
															// etc.
		if (this->classRosterArray[i]->studentID == studentID)					
		{
			int* dayPoint = classRosterArray[i]->accDaysInCourse();
															// another array declared to not mix students days.
			avg = dayPoint[0] + dayPoint[1] + dayPoint[2];
			avg = avg / 3.0;
			cout << studentID << ": " << fixed << setprecision(2) << avg << " days." << endl;
		}
	}
}
/* ------------------------------------------------------------------------------------------------------------------
E3: public void printByDegreeProgram(DegreeProgram degreeProgram) that prints out student information for a 
	degree program specified by an enumerated type (f).
------------------------------------------------------------------------------------------------------------------ */
void Roster::printByDegreeProgram(DegreeProgram degreeprogram)
{
	cout << endl << "Students pursuing '" << DegreeArray[degreeprogram] << "' degree:" << endl << endl;

	for (int i = 0; i < defStudents; ++i)					
		if (this->classRosterArray[i]->accDegreeProgram() == degreeprogram)
			this->classRosterArray[i]->print();				// for the students of array, print ONLY students
															// that when the DegreeProgram accessor of student at
}															// index i has an equivalent argument DegreeProgram match.
/* ------------------------------------------------------------------------------------------------------------------
E3: public void printInvalidEmails() that verifies student email addresses and displays all invalid email 
	addresses to the user (e).
------------------------------------------------------------------------------------------------------------------ */
void Roster::printInvalidEmails()							// for the students of array, print any email such that
{															// should .find(" ") NOT be equivalent to NO position,
	cout << endl << "Invalid emails: " << endl << endl;		// .find(".") BE equivalent to no position, (no . found),
	for (int i = 0; i < defStudents; ++i)					// .find("@") BE equivalent to no position, (no @ found),
	{														// then the email is considered invalid by these rules.
		if (classRosterArray[i]->accEmailAddress().find(" ") != string::npos)
			cout << classRosterArray[i]->accEmailAddress() << endl;
		else if (classRosterArray[i]->accEmailAddress().find(".") == string::npos)
			cout << classRosterArray[i]->accEmailAddress() << endl;
		else if (classRosterArray[i]->accEmailAddress().find("@") == string::npos)
			cout << classRosterArray[i]->accEmailAddress() << endl;
	}
}
/* ------------------------------------------------------------------------------------------------------------------
E3: public void remove(string studentID)  that removes students from the roster by student ID. If the student ID 
	does not exist, the function prints an error message indicating that the student was not found (b).
------------------------------------------------------------------------------------------------------------------ */
void Roster::remove(string studentID)
{
	bool exists = false;

	cout << endl;											// formatting endl.
	for (int i = 0; i <= currStudent; ++i)
	{
		if (classRosterArray[i]->accStudentId() == studentID)
		{
			classRosterArray[i] = nullptr;					// a lot of pointing is occuring, since this student is
															// being removed, it must be replaced.
			this->classRosterArray[i] = this->classRosterArray[currStudent];
															// this statement follows the null-ing of what once was
															// a pointer for an old student record. this is now being
															// replaced by the last student record as currStudent
															// is set to the last record location integer due to 
															// initial parse / addition of data ending on the last
															// student with associated array location integer.
			cout << "Student " << studentID << " removed." << endl;
			currStudent--;									//important change to index from size defStudents--;
			exists = true;									// for future self-reference.
		}
		else if ((i == currStudent) && (exists == false))	// if we have reached the last student, hence the less
		{													// than equal to operator in the for loop,
			cout << "Error message: Student ";				// and the bool flag has yet to be evaluated to true
			cout << studentID << " does not exist." << endl;// then there is no match for the argument studentID.	
		}
	}



}
/* ------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------ */
Roster::Roster()
{
	this->classRosterArray = nullptr;						// initialize null data	as it will be defined,
	this->currStudent = -1;									// see the constructor with defStudents argument.
	this->defStudents = 0;									
}
Roster::Roster(int defStudents)
{
	this->classRosterArray = new Student* [defStudents];	// pointer for member (the member is
															// classRosterArray of class Student). this is set to 
															// an allocation for the number of students / student  
															// pointers. hence the reason for an array of pointers.
	this->currStudent = -1;									
	this->defStudents = defStudents;						// though seems assumed, it is not. this definition must
															// be stated.
}																
/* ------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------ */
Roster::~Roster()
{
	cout << "Roster data removed." << endl;					// verification of deconstructor use.
	cout << endl << "+" << setw(120) << setfill('-') << "+" << endl;
}
/* ------------------------------------------------------------------------------------------------------------------
eof;
------------------------------------------------------------------------------------------------------------------ */
#endif
