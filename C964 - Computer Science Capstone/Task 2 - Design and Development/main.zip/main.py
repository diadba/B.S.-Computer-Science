import pandas as pd
import seaborn as sb
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
from pandas.plotting import scatter_matrix
from sklearn import metrics, model_selection, svm # external install / anaconda, supporting library.

""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
# See https://ashejim.github.io/C964/task2_c/task2_part_c.html used in 
# WGU C964 resources.

# Import data and convert it to a data frame (using Pandas). Project creates
# images by exploring the data in 3 different instances, see Visual 1,
# Visual 2 and Visual 3.
# ML algorithm used: Supported Vector Machines, see scikit learn.
""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
transferProtocol = "https://"
subDomain = "raw."
secondDomain = "githubusercontent."
domain = "com/"
subDirectory = "diadba/C964/main/Healthcare-Diabetes-readready.csv"
url = transferProtocol + subDomain + secondDomain + domain + subDirectory       # import data.

dataFields = ['BMI', 'Pedigree', 'Age', 'Outcome'] 
dataFrame = pd.read_csv(url, names = dataFields)                                # converted to data frame.

modelToTrain = svm.SVC()
y = dataFrame.values[:, 3]
X = dataFrame.values[:, 0:3]

varBMI = dataFrame.values[:, 0]
varDPF = dataFrame.values[:, 1]
varAge = dataFrame.values[:, 2]
varOutcome = dataFrame.values[:, 3]

ageSpace = np.exp(np.linspace(0, np.log(80), len(varBMI)))

""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
# Visual 1, heat map.
sb.heatmap(dataFrame.corr(), annot=True)
plt.show()
""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
# Visual 2, 3-dimensional scatter plot.
# Figure
fig = plt.figure(figsize = (16, 9))
ax = plt.axes(projection = '3d')
   
# Grid
ax.grid(b = True, color ='grey', linestyle ='-.', linewidth = 0.3, alpha = 0.2)
 
# Plot
plot3d = ax.scatter3D(varBMI, varDPF, varAge, alpha = 1, c = varOutcome, cmap = plt.get_cmap('copper'))
 
plt.title('BMI, Pedigree, and Age scatter bloom')
ax.set_xlabel('BMI', fontweight ='bold')
ax.set_ylabel('Pedigree', fontweight ='bold')
ax.set_zlabel('Age', fontweight ='bold')

colorPatch = mpatches.Patch(color='#ffc77f', label='Diabetes presence')
ax.legend(handles=[colorPatch])
 
plt.show()
""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
# Application to algorithm, training algorithm, model creation.
# Inspiration from Dr. Jim Ashe, see link: https://wgu.webex.com/recordingservice/sites/wgu/recording/9469df1f7d63103abf7f0050568114a0/playback
X_train, X_test, y_train, y_test = model_selection.train_test_split(X, y, test_size = 0.3)

modelToTrain.fit(X_train, y_train)

y_pred = modelToTrain.predict(X_test)

patBMI = input("\n\n\nInput patient BMI (ex: 27.4): ")
patDPF = input("Input patient DPF (ex: 1.01): ")
patAge = input("Input patient Age (ex: 25): ")

# Procedure for user to apply model, use IPython Console in Spyder.
print("\n")
print("Patient BMI: " + patBMI)
print("Patient Pedigree: " + patDPF)
print("Patient Age: " + patAge + "\n")

# Application of the model to single input.
varResult = str(modelToTrain.predict([[patBMI, patDPF, patAge]]))

if(varResult == '[0.]'): 
    varResult = "False."
else: 
    varResult = "True."

print("Risk range result: " + varResult + " (Relative to data the model was trained with.)" + "\n")
print("Confidence based on existing dataset: ")
print(str(round(float(metrics.accuracy_score(y_test, y_pred)) , 2) * 100) + "%")
print("RANGE: 60-69% OK, 70%-100% Preferred.")
""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""

""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
# Visual 3, unbalance scatter plot representation.

X = dataFrame.values[:, 0:2]
y = dataFrame.values[:, 3].tolist()
y = list(map(int, y))

sample_weight_constant = np.ones(len(X))

descriptiveNoWeight = svm.SVC()
descriptiveNoWeight.fit(X, y)

fig, axes = plt.subplots(1, 1, figsize=(12, 6))

xx, yy = np.meshgrid(np.linspace(0, 85), np.linspace(0, 3))

Z = descriptiveNoWeight.decision_function(np.c_[xx.ravel(), yy.ravel()])
Z = Z.reshape(xx.shape)

plt.contourf(xx, yy, Z, alpha=1, cmap=plt.cm.copper)
plt.scatter(
    X[:, 0],
    X[:, 1],
    c=varOutcome,
    s=ageSpace * 3,
    alpha=1,
    cmap=plt.cm.copper,
    edgecolors='white',
)

plt.title('Weight distribution of dataset')
plt.xlabel('BMI')
plt.ylabel('Pedigree')

plt.show()
""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""
